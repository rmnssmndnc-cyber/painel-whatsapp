"""Processo separado: mostra andamento no CMD sem travar a interface."""
import argparse
import os
import json
import sys
import traceback
from pathlib import Path
import painel_core as core


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('job', type=Path)
    parser.add_argument('--manter-aberto', action='store_true')
    args = parser.parse_args()
    result_path = args.job.with_suffix('.resultado.json')
    if sys.stdout is None:sys.stdout=open(os.devnull,'w',encoding='utf-8')
    if sys.stderr is None:sys.stderr=open(os.devnull,'w',encoding='utf-8')
    try:
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
        job = json.loads(args.job.read_text(encoding='utf-8'))
        core.atomic_json(args.job.with_suffix('.estado.json'), {'estado': 'executando'})
        if job.get('modo')=='exportar_grupo':
            result=core.group_export_worker(args.job,job)
            core.atomic_json(result_path, {'ok': True, 'grupo': result})
        else:
            summary = core.execute(job['campanha'], job['modo'], reset_stop=False)
            core.atomic_json(result_path, {'ok': True, 'resumo': summary})
    except BaseException as exc:
        message = str(exc) or type(exc).__name__
        print('\nERRO: ' + message, flush=True)
        core.atomic_json(result_path, {'ok': False, 'erro': message})
        traceback.print_exc()
    finally:
        if args.manter_aberto:
            print('\nExecução encerrada. Você já pode usar o painel novamente.', flush=True)
            try: input('Pressione Enter para fechar somente esta janela: ')
            except (EOFError, KeyboardInterrupt): pass


if __name__ == '__main__':
    main()
