import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import atualizador as up

class UpdateTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.app=self.root/'app';self.app.mkdir();(self.app/'dados').mkdir()
        (self.app/'dados'/'historico.csv').write_text('preservado')
        self.files={name:b'# novo\n' if name.endswith('.py') else b'{}' for name in up.REQUIRED-{'versao.json'}}
        for name in self.files:(self.app/name).write_bytes(b'# antigo\n')
    def tearDown(self):self.tmp.cleanup()
    def package(self,version='9.9.0',extra=None):
        files=dict(self.files)
        if extra:files.update(extra)
        info={'app':up.APP,'version':version,'files':{n:hashlib.sha256(v).hexdigest() for n,v in files.items()}}
        files['versao.json']=json.dumps(info).encode()
        path=self.root/'new.zip'
        with zipfile.ZipFile(path,'w') as z:
            for n,v in files.items():z.writestr('Painel_WhatsApp/'+n,v)
        return path
    def test_install_preserves_data_and_backups(self):
        v,backup=up.install(self.package(),self.app)
        self.assertEqual(v,'9.9.0');self.assertEqual((self.app/'painel.py').read_bytes(),b'# novo\n')
        self.assertEqual((backup/'painel.py').read_bytes(),b'# antigo\n')
        self.assertEqual((self.app/'dados'/'historico.csv').read_text(),'preservado')
    def test_reject_paths_and_data(self):
        for name in ['../outside.py','dados/historico.csv','/absolute.py']:
            with self.subTest(name=name),self.assertRaises(ValueError):up.install(self.package(extra={name:b'bad'}),self.app)
        self.assertEqual((self.app/'dados'/'historico.csv').read_text(),'preservado')
    def test_reject_older_and_same(self):
        for v in ['2.1.0',up.VERSION]:
            with self.assertRaises(ValueError):up.install(self.package(v),self.app)
    def test_mismatch_version(self):
        with self.assertRaises(ValueError):up.install(self.package(),self.app,expected='8.8.0')
    def test_incomplete_package(self):
        del self.files['painel.py']
        with self.assertRaises(ValueError):up.install(self.package(),self.app)
    def test_corrupted_hash(self):
        path=self.package()
        with zipfile.ZipFile(path) as z:parts={n:z.read(n) for n in z.namelist()}
        parts['Painel_WhatsApp/painel.py']=b'bad'
        with zipfile.ZipFile(path,'w') as z:
            for n,v in parts.items():z.writestr(n,v)
        with self.assertRaises(ValueError):up.install(path,self.app)
    def test_failed_install_restores_all_files(self):
        original=up.os.replace;calls=[0]
        def failing(src,dst):
            calls[0]+=1
            if calls[0]==3:raise OSError('arquivo ocupado')
            return original(src,dst)
        with patch.object(up.os,'replace',side_effect=failing),self.assertRaises(OSError):up.install(self.package(),self.app)
        for name in self.files:self.assertEqual((self.app/name).read_bytes(),b'# antigo\n')
        self.assertFalse((self.app/'versao.json').exists())
    def test_online_manifest_and_download_integrity(self):
        content=self.package().read_bytes()
        manifest={'app':up.APP,'version':'9.9.0','url':'https://example.org/new.zip','sha256':hashlib.sha256(content).hexdigest()}
        with patch.object(up,'fetch',return_value=json.dumps(manifest).encode()):self.assertEqual(up.check('https://example.org/latest.json'),manifest)
        with patch.object(up,'fetch',return_value=content):self.assertEqual(up.download(manifest,self.root/'downloads').read_bytes(),content)
        with patch.object(up,'fetch',return_value=b'broken'),self.assertRaises(ValueError):up.download(manifest,self.root/'downloads')
    def test_requires_https(self):
        for url in ['http://example.org','file:///tmp/update','https://user:pass@example.org']:
            with self.assertRaises(ValueError):up.https(url)

if __name__=='__main__':unittest.main()
