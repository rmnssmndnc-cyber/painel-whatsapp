"""Testes locais sem navegador e sem envios. Executar: python -m unittest test_painel -v"""
import contextlib
import io
import itertools
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import painel_core as core


class FakeTransport:
    def __init__(self): self.calls=[]; self.chats=[]; self.closed=False
    def open_chat(self,p): self.chats.append(p)
    def send(self,kind,value): self.calls.append((kind,value));return 'ENTREGUE','Transporte fictício de teste.'
    def close(self): self.closed=True


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.draft=core.new_draft();self.draft['mensagem']='Olá, {nome}!'
        self.draft['contatos']=[{'nome':f'Pessoa {i}','telefone':f'2190000000{i}'} for i in range(1,4)]
        image=self.root/'foto.jpg';image.write_bytes(b'fixture jpg')
        pdf=self.root/'material.pdf';pdf.write_bytes(b'%PDF-fixture')
        self.draft['anexos']=[str(image),str(pdf)]
    def tearDown(self):self.tmp.cleanup()
    def run_job(self,mode='enviar',transport=None,**kwargs):
        adapter=transport or FakeTransport()
        with contextlib.redirect_stdout(io.StringIO()),patch.object(core.motor.time,'monotonic',side_effect=itertools.count(0,2)):
            result=core.execute(self.draft,mode,self.root,transport_factory=lambda *_:adapter,**kwargs)
        return result,adapter
    def test_three_people_nine_items(self):
        result,adapter=self.run_job()
        self.assertEqual(len(adapter.calls),9);self.assertEqual(len(adapter.chats),3)
        self.assertEqual([v for k,v in adapter.calls if k=='texto'],['Olá, Pessoa 1!','Olá, Pessoa 2!','Olá, Pessoa 3!'])
        self.assertEqual(result['entregues_no_historico'],9);self.assertTrue(adapter.closed)
    def test_duplicate_run_does_not_send(self):
        self.run_job();result,adapter=self.run_job()
        self.assertEqual(adapter.calls,[]);self.assertEqual(result['ocorrencias_desta_execucao']['JA_PROCESSADO'],3)
    def test_simulation_does_not_open_transport(self):
        result,adapter=self.run_job('simular')
        self.assertEqual(result['simulados'],9);self.assertEqual(adapter.chats,[])
        result,adapter=self.run_job();self.assertEqual(len(adapter.calls),9)
    def test_duplicate_phone_blocks_entire_batch(self):
        self.draft['contatos'][2]['telefone']=self.draft['contatos'][0]['telefone']
        adapter=FakeTransport()
        with self.assertRaisesRegex(ValueError,'duplicado'):self.run_job(transport=adapter)
        self.assertEqual(adapter.calls,[])
    def test_missing_file_blocks_entire_batch(self):
        self.draft['anexos'].append(str(self.root/'ausente.pdf'))
        with self.assertRaisesRegex(ValueError,'não encontrado'):self.run_job()
    def test_missing_personalization_blocks(self):
        self.draft['mensagem']='Olá {nome}, turma {turma}'
        with self.assertRaisesRegex(ValueError,'não suportado'):self.run_job()
    def test_free_subject_without_personalization(self):
        self.draft['mensagem']='Convite para o culto de domingo.'
        result,adapter=self.run_job()
        self.assertEqual([v for k,v in adapter.calls if k=='texto'],[self.draft['mensagem']]*3)
    def test_legacy_contact_fields_do_not_change_message(self):
        self.run_job()
        for row in self.draft['contatos']:
            row.update(curso='Antigo',turma='A',codigo='123')
        result,adapter=self.run_job()
        self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['JA_PROCESSADO'],3)
    def test_unknown_placeholder_blocks(self):
        self.draft['mensagem']='Olá {nome.__class__}'
        with self.assertRaisesRegex(ValueError,'não suportado'):self.run_job()
    def test_changed_content_conflict(self):
        self.run_job();self.draft['mensagem']='Outro texto'
        result,adapter=self.run_job();self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['CONFLITO'],3)
    def test_uncertain_never_auto_retries(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):self.calls.append((k,v));raise RuntimeError('Sem confirmação')
        result,adapter=self.run_job(transport=Uncertain());self.assertEqual(result['incertos'],1)
        result,adapter=self.run_job();self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['BLOQUEADO'],1)
    def test_manual_received_continues_only_attachments(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):raise RuntimeError('Sem confirmação')
        self.run_job(transport=Uncertain());cfg,rows=core.prepare(self.draft)
        core.review_item(cfg['campanha'],rows[0]['telefone'],'00-texto','recebido',self.root)
        result,adapter=self.run_job();self.assertEqual([k for k,v in adapter.calls],['anexo','anexo'])
        self.assertEqual(result['entregues_no_historico'],3)
    def test_retry_unknown_result_refused(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):raise RuntimeError('Sem confirmação')
        self.run_job(transport=Uncertain());cfg,rows=core.prepare(self.draft)
        with self.assertRaises(ValueError):core.review_item(cfg['campanha'],rows[0]['telefone'],'00-texto','retomar',self.root)
    def test_stop_before_start_is_respected(self):
        (self.root/'PARAR').touch()
        result,adapter=self.run_job(reset_stop=False)
        self.assertEqual(adapter.calls,[]);self.assertTrue(result['parado']);self.assertEqual(result['pendentes'],9)
    def test_second_process_lock_denied(self):
        with core.execution_lock(self.root):
            with self.assertRaises(ValueError):
                with core.execution_lock(self.root):pass
    def test_copy_file_survives_source_removed(self):
        source=Path(self.draft['anexos'][0]);dest=core.stage_attachment(source,self.root)
        source.unlink();self.assertEqual(Path(dest).read_bytes(),b'fixture jpg')
    def test_header_mapping(self):
        m=core.parse_text('Telefone;Nome;Turma\n21900000001;Ana;A\n21900000002;Bia;B')
        header,mapping=core.suggested_mapping(m);rows=core.map_contacts(m,mapping,header)
        self.assertTrue(header);self.assertEqual(rows[0]['nome'],'Ana');self.assertEqual(set(rows[1]),{'nome','telefone'})
    def test_paste_without_header(self):
        m=core.parse_text('Ana\t21900000001\nBia\t21900000002')
        header,mapping=core.suggested_mapping(m);self.assertFalse(header)
        self.assertEqual(len(core.map_contacts(m,mapping,header)),2)
    def test_phone_normalization(self):
        self.assertEqual(core.normalize_phone('(21) 90000-0001'),'5521900000001')
        self.assertEqual(core.normalize_phone('5521900000001.0'),'5521900000001')
        self.assertEqual(core.normalize_phone('+12025550123'),'12025550123')
        with self.assertRaises(ValueError):core.normalize_phone('5.521E+12')
    def test_empty_list(self):
        self.draft['contatos']=[]
        with self.assertRaises(ValueError):core.prepare(self.draft)
    def test_new_campaign_has_unique_id(self):
        self.assertNotEqual(core.new_draft()['id'],core.new_draft()['id'])
    def test_atomic_json_roundtrip(self):
        path=self.root/'a.json';core.atomic_json(path,self.draft)
        self.assertEqual(json.loads(path.read_text()),self.draft)
    def test_xlsx_read_shared_and_inline(self):
        path=self.root/'list.xlsx';ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
        with zipfile.ZipFile(path,'w') as z:
            z.writestr('xl/workbook.xml',f'<workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Lista" r:id="r1"/></sheets></workbook>')
            z.writestr('xl/_rels/workbook.xml.rels','<Relationships><Relationship Id="r1" Target="worksheets/sheet1.xml"/></Relationships>')
            z.writestr('xl/sharedStrings.xml',f'<sst xmlns="{ns}"><si><t>Nome</t></si><si><t>Ana</t></si></sst>')
            z.writestr('xl/worksheets/sheet1.xml',f'<worksheet xmlns="{ns}"><sheetData><row><c r="A1" t="s"><v>0</v></c><c r="B1" t="inlineStr"><is><t>Telefone</t></is></c></row><row><c r="A2" t="s"><v>1</v></c><c r="B2"><v>21900000001</v></c></row></sheetData></worksheet>')
        self.assertEqual(core.file_matrix(path),['Lista'])
        m=core.file_matrix(path,'Lista');self.assertEqual(m,[['Nome','Telefone'],['Ana','21900000001']])


class ChatOpeningTests(unittest.TestCase):
    def setUp(self):
        from unittest.mock import MagicMock
        import types
        self.tmp=tempfile.TemporaryDirectory()
        self.adapter=core.motor.WhatsApp.__new__(core.motor.WhatsApp)
        self.adapter.root=Path(self.tmp.name)
        self.adapter.sel={'composer':'editor','invalid_regex':'invalid'}
        self.page=MagicMock();self.adapter.page=self.page
        self.page.is_closed.return_value=False
        self.editor=MagicMock();self.editor.count.return_value=1
        self.editor.is_visible.return_value=True
        self.bad=MagicMock();self.bad.count.return_value=0
        self.page.locator.side_effect=lambda s: self.editor if s=='editor' else self.bad
        self.bad.get_by_text.return_value=self.bad
        self.adapter.session_signals=lambda: {}
        api=types.ModuleType('playwright.sync_api');api.TimeoutError=TimeoutError
        self.modules=patch.dict('sys.modules',{'playwright':types.ModuleType('playwright'),'playwright.sync_api':api})
        self.modules.start()
    def tearDown(self):
        self.modules.stop();self.tmp.cleanup()
    def open(self):
        with contextlib.redirect_stdout(io.StringIO()),patch.object(core.motor.time,'monotonic',side_effect=itertools.count(0,30)):
            self.adapter.open_chat('5521900000001')
    def test_navigation_timeout_retries_without_using_old_editor(self):
        self.page.goto.side_effect=[None,TimeoutError(),None,None]
        self.open()
        self.assertEqual(self.page.goto.call_count,4)
        self.assertEqual(self.editor.is_visible.call_count,2)
        urls=[c.args[0] for c in self.page.goto.call_args_list]
        self.assertEqual(urls[0], 'about:blank');self.assertEqual(urls[2],'about:blank')
        self.assertEqual(urls[1],urls[3])
    def test_slow_interface_retries_then_opens(self):
        self.editor.count.side_effect=[0,0,0,1,1]
        self.open()
        self.assertEqual(self.page.goto.call_count,4)
    def test_two_timeouts_fail_without_inspecting_editor(self):
        self.page.goto.side_effect=[None,TimeoutError(),None,TimeoutError()]
        with self.assertRaisesRegex(RuntimeError,'duas tentativas'):self.open()
        self.editor.is_visible.assert_not_called()
    def test_invalid_dialog_does_not_retry(self):
        self.bad.count.return_value=1;self.bad.nth.return_value.is_visible.return_value=True
        with self.assertRaises(ValueError):self.open()
        self.assertEqual(self.page.goto.call_count,2)
    def test_stop_prevents_navigation(self):
        (self.adapter.root/'PARAR').touch()
        with self.assertRaisesRegex(RuntimeError,'Parar'):self.open()
        self.page.goto.assert_not_called()
    def test_closed_browser_prevents_navigation(self):
        self.page.is_closed.return_value=True
        with self.assertRaisesRegex(RuntimeError,'fechado'):self.open()
        self.page.goto.assert_not_called()


class AITests(unittest.TestCase):
    def test_callback_rejects_wrong_state_and_changed_client(self):
        with self.assertRaises(ValueError):core.ai_callback_values('state=bad&code=x&client_id=c','good')
        with self.assertRaises(ValueError):core.ai_callback_values('state=s&code=x&client_id=other','s','saved')
        with self.assertRaises(ValueError):core.ai_callback_values('state=s&state=s&code=x&client_id=c','s')
        with self.assertRaises(ValueError):core.ai_callback_values('state=s&code=x&client_id=dynamic_agent_client','s')
    def test_callback_reauthorization_and_denial(self):
        self.assertEqual(core.ai_callback_values('state=s&code=x','s','saved'),('x','saved'))
        with self.assertRaisesRegex(RuntimeError,'não autorizou'):
            core.ai_callback_values('state=s&error=access_denied','s')
    def stream(self,events):
        return io.BytesIO(''.join('data: '+json.dumps(e)+'\n\n' for e in events).encode())
    def test_stream_requires_completed_and_discards_partial_failure(self):
        delta={'type':'response.output_text.delta','delta':'Olá'}
        self.assertEqual(core.ai_stream_text(self.stream([delta,{'type':'response.completed'}])),'Olá')
        with self.assertRaisesRegex(RuntimeError,'interrompida'):core.ai_stream_text(self.stream([delta]))
        with self.assertRaisesRegex(RuntimeError,'Limite'):
            core.ai_stream_text(self.stream([delta,{'type':'response.failed','response':{'error':{'code':'subscription_sharing_usage_limit_exceeded'}}}]))
    def test_no_api_key_fallback_and_supported_payload(self):
        with tempfile.TemporaryDirectory() as td:
            connection=core.ChatGPTConnection(td)
            connection.credentials={'access_token':'SECRET','expires':core.time.time()+1000}
            connection.models=[{'slug':'test-model'}]
            with patch.object(core,'ai_http',return_value=self.stream([{'type':'response.output_text.delta','delta':'ok'},{'type':'response.completed'}])) as http:
                self.assertEqual(connection.ask('test-model','instructions','prompt'),'ok')
            payload=http.call_args.kwargs['payload']
            self.assertFalse(payload['store']);self.assertTrue(payload['stream'])
            self.assertNotIn('tools',payload);self.assertNotIn('max_output_tokens',payload)
            self.assertEqual(http.call_args.args[0],'https://api.openai.com/v1/responses')
            connection.disconnect()
            with patch.object(core,'ai_http') as http, self.assertRaises(RuntimeError):connection.token()
            http.assert_not_called()
            self.assertNotIn('SECRET',connection.path.read_text())
    def test_diagnostic_excludes_private_content(self):
        import csv
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'historico.csv'
            with p.open('w',newline='',encoding='utf-8-sig') as f:
                w=csv.DictWriter(f,fieldnames=['campanha','nome','telefone','status','motivo','conteudo'],delimiter=';');w.writeheader()
                w.writerow({'campanha':'target','nome':'SECRET-NAME','telefone':'5521999999999','status':'FALHA','motivo':'Conversa não abriu SECRET-REASON','conteudo':'SECRET-TEXT'})
                w.writerow({'campanha':'other','status':'ENTREGUE'})
            result=core.ai_campaign_diagnostic('target',td)
            self.assertNotIn('SECRET',result);self.assertNotIn('5521999999999',result)
            d=json.loads(result);self.assertEqual(d['registros_da_campanha'],1)
            self.assertEqual(d['categorias_de_falha'],{'abertura_conversa':1})
    def test_identity_signature_nonce_audience_and_subject(self):
        import jwt
        from cryptography.hazmat.primitives.asymmetric import rsa
        from types import SimpleNamespace
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        claims={'iss':core.AI_AUTH,'aud':'client','sub':'user','nonce':'nonce','exp':core.time.time()+300}
        token=jwt.encode(claims,key,algorithm='RS256')
        with patch('jwt.PyJWKClient.get_signing_key_from_jwt',return_value=SimpleNamespace(key=key.public_key())):
            self.assertEqual(core.ai_validate_identity(token,'client','nonce')['sub'],'user')
            for client,nonce,subject in [('wrong','nonce',None),('client','wrong',None),('client','nonce','wrong')]:
                with self.assertRaises(RuntimeError):core.ai_validate_identity(token,client,nonce,subject)
            unsigned=jwt.encode(claims,key=None,algorithm='none')
            with self.assertRaises(RuntimeError):core.ai_validate_identity(unsigned,'client','nonce')
    def test_complete_login_with_loopback_and_no_saved_credentials(self):
        import threading
        import urllib.request
        import urllib.parse
        from types import SimpleNamespace
        import jwt
        from cryptography.hazmat.primitives.asymmetric import rsa
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        seen={};threads=[]
        def browser(url):
            query=urllib.parse.parse_qs(urllib.parse.urlsplit(url).query);seen.update(query)
            callback=query['redirect_uri'][0]+'?'+urllib.parse.urlencode({'state':query['state'][0],'code':'test-code','client_id':'test-client'})
            def hit():
                with urllib.request.urlopen(callback,timeout=5) as r:r.read()
            t=threading.Thread(target=hit);t.start();threads.append(t);return True
        def token_response(url,payload,form=False):
            self.assertTrue(form);self.assertEqual(payload['client_id'],'test-client')
            self.assertEqual(payload['redirect_uri'],seen['redirect_uri'][0])
            computed=core.base64.urlsafe_b64encode(core.hashlib.sha256(payload['code_verifier'].encode()).digest()).decode().rstrip('=')
            self.assertEqual(computed,seen['code_challenge'][0])
            claims={'iss':core.AI_AUTH,'aud':'test-client','sub':'user','nonce':seen['nonce'][0],'exp':core.time.time()+300}
            return {'id_token':jwt.encode(claims,key,algorithm='RS256'),'access_token':'SECRET-TOKEN','token_type':'Bearer','scope':core.AI_SCOPES,'expires_in':1000}
        with tempfile.TemporaryDirectory() as td:
            c=core.ChatGPTConnection(td);host=c.saved['host_id']
            with patch.object(core.webbrowser,'open',side_effect=browser),patch.object(core,'ai_http',side_effect=token_response),patch('jwt.PyJWKClient.get_signing_key_from_jwt',return_value=SimpleNamespace(key=key.public_key())):
                self.assertEqual(c.login(),'Conta 1')
            for t in threads:t.join(5)
            self.assertEqual(c.token(),'SECRET-TOKEN');self.assertNotIn('SECRET-TOKEN',c.path.read_text())
            self.assertEqual(core.ChatGPTConnection(td).saved['host_id'],host)
            self.assertNotIn('offline_access',seen['scope'][0])
            self.assertIsNone(core.ChatGPTConnection(td).credentials)


if __name__=='__main__':unittest.main()
