"""Painel WhatsApp. IA opcional usa PyJWT/cryptography para validar identidade."""
from __future__ import annotations
import csv
import base64
import subprocess
import sys
import hashlib
import io
import json
import os
import posixpath
import re
import sqlite3
import unicodedata
import uuid
import zipfile
from collections import Counter
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET

import motor_whatsapp as motor

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'dados'
COLUMNS = ('nome', 'telefone')


NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
ALIASES = {
    'nome': {'nome', 'nome completo', 'contato', 'cliente', 'name'},
    'telefone': {'telefone', 'celular', 'whatsapp', 'numero', 'phone', 'telefone 1'},
}


def stamp():
    return datetime.now().astimezone().isoformat(timespec='seconds')


def new_draft():
    return {'id': 'PAINEL-' + uuid.uuid4().hex[:16].upper(), 'nome': 'Minha campanha',
            'mensagem': '', 'intervalo': 5, 'confirmacao': 60, 'contatos': [], 'anexos': []}


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


@contextmanager
def execution_lock(data=DATA, name='execucao.lock'):
    """Mesmo bloqueio do projeto Excel: uma execução por vez na pasta dados."""
    data = Path(data)
    data.mkdir(parents=True, exist_ok=True)
    handle = (data / name).open('a+b')
    try:
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise ValueError('Já existe uma execução aberta. Aguarde sua conclusão.') from exc
        yield
    finally:
        handle.close()


def normalize_header(value):
    return ''.join(c for c in unicodedata.normalize('NFD', str(value))
                   if unicodedata.category(c) != 'Mn').strip().lower().replace('_', ' ')


def suggested_mapping(matrix):
    first = [normalize_header(c) for c in (matrix[0] if matrix else [])]
    mapping = {key: next((i for i, v in enumerate(first) if v in names), None)
               for key, names in ALIASES.items()}
    header = mapping['nome'] is not None and mapping['telefone'] is not None
    if not header:
        width = max((len(row) for row in matrix), default=0)
        mapping = {key: i if i < width else None for i, key in enumerate(COLUMNS)}
    return header, mapping


def map_contacts(matrix, mapping, header=True):
    if mapping.get('nome') is None or mapping.get('telefone') is None:
        raise ValueError('Escolha as colunas Nome e Telefone.')
    selected = [i for i in mapping.values() if i is not None]
    if len(selected) != len(set(selected)):
        raise ValueError('Cada campo deve usar uma coluna diferente.')
    result = []
    for source in matrix[1 if header else 0:]:
        row = {key: str(source[i]).strip() if i is not None and i < len(source) else ''
               for key, i in mapping.items()}
        if not any(row.values()):
            continue
        result.append({key: row.get(key, '') for key in COLUMNS})
    if len(result) > 1000:
        raise ValueError('Importe no máximo 1.000 contatos por campanha.')
    return result


def parse_text(text):
    if len(text) > 4_000_000:
        raise ValueError('Conteúdo muito grande. Importe até 1.000 contatos.')
    try:
        dialect = csv.Sniffer().sniff(text[:16000], delimiters='\t;,')
        rows = list(csv.reader(io.StringIO(text), dialect))
    except csv.Error:
        rows = list(csv.reader(io.StringIO(text), delimiter='\t'))
    return [r for r in rows if any(v.strip() for v in r)]


def file_matrix(path, sheet=None):
    path = Path(path)
    if path.suffix.lower() in ('.csv', '.tsv', '.txt'):
        raw = path.read_bytes()
        try: text = raw.decode('utf-8-sig')
        except UnicodeDecodeError: text = raw.decode('cp1252')
        return parse_text(text)
    if path.suffix.lower() not in ('.xlsx', '.xlsm'):
        raise ValueError('Use XLSX, XLSM ou CSV. Para XLS antigo, copie e cole as células.')
    with zipfile.ZipFile(path) as z:
        if sum(i.file_size for i in z.infolist()) > 100 * 1024 * 1024:
            raise ValueError('Planilha muito grande. Copie apenas os contatos necessários.')
        book = ET.fromstring(z.read('xl/workbook.xml'))
        sheets = book.find('s:sheets', NS)
        names = [s.get('name') for s in sheets]
        if sheet is None:
            return names
        target_sheet = next((s for s in sheets if s.get('name') == sheet), None)
        if target_sheet is None:
            raise ValueError('Aba não encontrada.')
        rel_id = target_sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        relations = {e.get('Id'): e.get('Target') for e in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        target = relations[rel_id]
        member = target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/' + target)
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            shared = [''.join(t.text or '' for t in si.findall('.//s:t', NS))
                      for si in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        matrix = []
        for r in ET.fromstring(z.read(member)).findall('s:sheetData/s:row', NS):
            values = {}
            for cell in r.findall('s:c', NS):
                letters = re.match(r'[A-Z]+', cell.get('r', ''))
                if not letters: continue
                col = 0
                for letter in letters[0]: col = col * 26 + ord(letter) - 64
                if col > 100: continue
                raw = cell.findtext('s:v', '', NS)
                typ = cell.get('t')
                if typ == 's': value = shared[int(raw)]
                elif typ == 'inlineStr': value = ''.join(t.text or '' for t in cell.findall('.//s:t', NS))
                else: value = raw
                if cell.find('s:f', NS) is not None and not raw:
                    raise ValueError('Há fórmula sem valor salvo. Copie e cole os valores dessa aba.')
                if typ == 'e': raise ValueError('Há célula com erro na aba. Corrija antes de importar.')
                if value: values[col - 1] = value
            if values:
                matrix.append([values.get(i, '') for i in range(max(values) + 1)])
            if len(matrix) > 1001:
                raise ValueError('A aba tem mais de 1.000 linhas de dados. Copie somente a lista desejada.')
        return matrix


def normalize_phone(raw):
    value = str(raw).strip()
    # Aceita números inteiros salvos com .0, mas nunca notação científica arredondada.
    if re.fullmatch(r'\d{10,15}\.0+', value): value = value.split('.')[0]
    if not value.startswith('+') and re.fullmatch(r'[\d\s().-]+', value):
        digits = re.sub(r'\D', '', value)
        if len(digits) in (10, 11): value = '55' + digits
    return motor.phone(value)


def stage_attachment(source, data=DATA):
    source = Path(source)
    if source.suffix.lower() not in ('.jpg', '.jpeg', '.png', '.pdf'):
        raise ValueError('Escolha JPG, PNG ou PDF.')
    if not source.is_file() or not 0 < source.stat().st_size <= 15 * 1024 * 1024:
        raise ValueError('O arquivo deve existir e ter entre 1 byte e 15 MB.')
    content = source.read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    dest = Path(data) / 'arquivos_painel' / digest / source.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        temp = dest.with_name(uuid.uuid4().hex + '.tmp')
        temp.write_bytes(content); os.replace(temp, dest)
    if hashlib.sha256(dest.read_bytes()).hexdigest() != digest:
        raise ValueError('A cópia do anexo foi alterada. Selecione novamente o arquivo original.')
    return str(dest.resolve())


def prepare(draft):
    campaign = str(draft.get('id', '')).strip()
    if not campaign or len(campaign) > 100:
        raise ValueError('Campanha inválida.')
    interval, timeout = int(draft['intervalo']), int(draft['confirmacao'])
    if not 1 <= interval <= 3600 or not 10 <= timeout <= 180:
        raise ValueError('Intervalo: 1 a 3.600 segundos. Confirmação: 10 a 180 segundos.')
    attachments = draft.get('anexos', [])
    if len(attachments) > 8:
        raise ValueError('Use até oito anexos por campanha.')
    if any('|' in p for p in attachments): raise ValueError('O caminho do anexo não pode conter |.')
    cfg = {'campanha': campaign, 'modelo': str(draft.get('mensagem', '')),
           'anexos_comuns': '|'.join(attachments), 'intervalo_segundos': interval,
           'tempo_confirmacao': timeout, 'limite_contatos': 1000}
    raw_rows = draft.get('contatos', [])
    if not 1 <= len(raw_rows) <= 1000:
        raise ValueError('Adicione de 1 a 1.000 contatos à lista.')
    rows, seen = [], set()
    for i, raw in enumerate(raw_rows, 1):
        row = {key: str(raw.get(key, '')).strip() for key in COLUMNS}
        try:
            if not row['nome']: raise ValueError('Nome vazio.')
            row['telefone'] = normalize_phone(row['telefone'])
            if row['telefone'] in seen: raise ValueError('Telefone duplicado nesta lista.')
            seen.add(row['telefone'])
            # A lista exibida é a lista de destinatários que o operador escolheu enviar.
            row.update({'selecionar': 'SIM', 'autorizado': 'SIM', 'anexos': ''})
            motor.items_for(cfg, row, ROOT)
        except (ValueError, KeyError) as exc:
            raise ValueError(f'Linha {i} ({row["nome"] or "sem nome"}): {exc}') from exc
        rows.append(row)
    return cfg, rows


def result_summary(cfg, rows, report, data, mode):
    counts = Counter(r[6] for r in report)
    planned = sum(len(motor.items_for(cfg, row, ROOT)) for row in rows)
    delivered = sent = uncertain = pending = simulated = 0
    contacts_done = 0
    if mode == 'simular':
        simulated = counts.get('SIMULADO', 0)
    else:
        h = motor.History(Path(data) / 'historico.sqlite3')
        try:
            for row in rows:
                done = True
                for i, (kind, _) in enumerate(motor.items_for(cfg, row, ROOT)):
                    state = h.state(cfg['campanha'], row['telefone'], f'{i:02d}-{kind}')
                    status = state[0] if state else ''
                    if status == 'ENTREGUE': delivered += 1
                    elif status == 'ENVIADO': sent += 1
                    elif status == 'INCERTO': uncertain += 1; done = False
                    else: pending += 1; done = False
                contacts_done += int(done)
        finally: h.db.close()
    return {'modo': mode, 'contatos': len(rows), 'itens_previstos': planned,
            'entregues_no_historico': delivered, 'enviados_no_historico': sent,
            'incertos': uncertain, 'pendentes': pending, 'simulados': simulated,
            'contatos_processados': contacts_done, 'ocorrencias_desta_execucao': dict(counts),
            'parado': (Path(data) / 'PARAR').exists()}


def execute(draft, mode, data=DATA, transport_factory=motor.WhatsApp, reset_stop=True):
    if mode not in ('simular', 'enviar'): raise ValueError('Modo inválido.')
    cfg, rows = prepare(draft)  # Valida o lote inteiro antes de qualquer envio.
    with execution_lock(data):
        if reset_stop:
            (Path(data) / 'PARAR').unlink(missing_ok=True)
        print(f'Campanha: {draft.get("nome", "")} | Código: {cfg["campanha"]}', flush=True)
        print(f'Contatos: {len(rows)} | Modo: {mode} | Intervalo: {cfg["intervalo_segundos"]}s', flush=True)
        print('Todos os contatos da lista entram no lote. Não há confirmação por teclado.', flush=True)
        report = motor.run(cfg, rows, Path(data), mode, transport_factory=transport_factory, manual_review=False)
        summary = result_summary(cfg, rows, report, data, mode)
        print('\n========== RESULTADO FINAL ==========', flush=True)
        for key, label in [('contatos', 'Contatos da lista'), ('itens_previstos', 'Itens previstos'),
                           ('simulados', 'Itens simulados'), ('entregues_no_historico', 'Itens entregues na campanha'),
                           ('enviados_no_historico', 'Itens enviados, entrega ainda não confirmada'),
                           ('incertos', 'Itens incertos'), ('pendentes', 'Itens pendentes')]:
            print(f'{label}: {summary[key]}', flush=True)
        print('Ocorrências desta execução: ' + str(summary['ocorrencias_desta_execucao']), flush=True)
        if summary['parado']: print('Parada solicitada pelo operador.', flush=True)
        if summary['incertos']: print('Resultado incerto: confira a conversa. Use Revisar pendências no painel.', flush=True)
        print('Histórico preservado em dados/historico.csv.', flush=True)
        return summary


def uncertain_items(campaign, data=DATA):
    path = Path(data) / 'historico.sqlite3'
    if not path.exists(): return []
    with sqlite3.connect(path) as db:
        rows = db.execute('SELECT phone,item,time,reason FROM items WHERE campaign=? AND status=?',
                          (campaign, 'INCERTO')).fetchall()
        wanted = {(r[0], r[1]) for r in rows}
        contents = {}
        for (data_json,) in db.execute('SELECT data FROM events ORDER BY rowid DESC'):
            record = json.loads(data_json)
            key = (record[4], record[5])
            if record[1] == campaign and key in wanted and key not in contents and record[6] == 'INCERTO':
                contents[key] = record[8]
            if len(contents) == len(wanted): break
        return [(*r, contents.get((r[0], r[1]), 'Consulte o histórico da tentativa.')) for r in rows]


def review_item(campaign, phone, item, action, data=DATA):
    with execution_lock(data):
        h = motor.History(Path(data) / 'historico.sqlite3')
        try:
            if action == 'recebido': h.confirm_received(campaign, phone, item)
            elif action == 'retomar': h.release_before_send(campaign, phone, item)
            else: raise ValueError('Ação inválida.')
            motor.export_csv(Path(data) / 'historico.csv', [json.loads(r[0]) for r in h.db.execute('SELECT data FROM events')])
        finally: h.db.close()

# Integração opcional: OAuth oficial com uso do plano ChatGPT, sem chave de API.
# Tokens ficam apenas na memória desta janela. Registros persistem apenas IDs.
import secrets
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlencode, urlsplit, parse_qs
from urllib.request import Request, urlopen
from urllib.error import HTTPError

AI_AUTH = 'https://auth.openai.com'
AI_RESOURCE = 'https://api.openai.com/v1'
AI_SCOPES = 'openid profile email resource.invoke chatgpt.tokens.use.direct'


def ai_dependencies(install=False):
    try:
        import jwt
        from cryptography.hazmat.primitives.asymmetric import rsa
        return
    except ImportError:
        if not install:
            raise RuntimeError('Clique em Preparar conexão para instalar o componente de autenticação.')
    python = Path(sys.executable)
    if python.name.lower() == 'pythonw.exe':
        python = python.with_name('python.exe')
    result = subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check',
                             'PyJWT[crypto]==2.10.1'], capture_output=True, timeout=240,
                            creationflags=0x08000000 if sys.platform == 'win32' else 0)
    if result.returncode:
        raise RuntimeError('Não foi possível instalar o componente de autenticação. Confira a conexão com a internet.')
    import importlib
    importlib.invalidate_caches()
    ai_dependencies()


def ai_error(code):
    messages = {
        'subscription_sharing_usage_limit_exceeded': 'Limite do plano atingido. Confira o uso nas configurações do ChatGPT.',
        'subscription_sharing_usage_unavailable': 'Uso do plano indisponível. Confira a autorização e os limites no ChatGPT.',
        'subscription_sharing_unsupported_capability': 'Este recurso ou modelo não está disponível para esta integração.',
        'access_denied': 'Você não autorizou o uso do plano. Nenhuma análise foi feita.',
        'invalid_grant': 'A autorização expirou. Clique em Continuar com ChatGPT novamente.',
    }
    return messages.get(code, 'A OpenAI não concluiu a solicitação. Verifique a conexão, a autorização e os limites do plano.')


def ai_http(url, payload=None, token=None, form=False, stream=False):
    # Endpoints fixos; nunca aceita um endereço fornecido pelo modelo.
    parts = urlsplit(url)
    if parts.scheme != 'https' or parts.hostname not in ('auth.openai.com', 'api.openai.com'):
        raise ValueError('Endereço de autenticação não permitido.')
    headers = {'Accept': 'text/event-stream' if stream else 'application/json'}
    if token: headers['Authorization'] = 'Bearer ' + token
    data = None
    if payload is not None:
        data = (urlencode(payload) if form else json.dumps(payload)).encode()
        headers['Content-Type'] = 'application/x-www-form-urlencoded' if form else 'application/json'
    try:
        # Sem redirecionamento de credenciais para outros destinos.
        from urllib.request import build_opener, HTTPRedirectHandler
        class NoRedirect(HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs): return None
        response = build_opener(NoRedirect).open(Request(url, data=data, headers=headers), timeout=60)
        if stream: return response
        with response:
            return json.loads(response.read(4 * 1024 * 1024))
    except HTTPError as exc:
        try:
            value = json.loads(exc.read(8192)); error = value.get('error', {})
            code = error.get('code') if isinstance(error, dict) else error
        except Exception: code = ''
        raise RuntimeError(ai_error(code)) from None
    except (OSError, ValueError):
        raise RuntimeError('Não foi possível comunicar com a OpenAI. Confira a conexão e tente novamente.') from None


def ai_validate_identity(encoded, client_id, nonce, subject=None):
    ai_dependencies()
    import jwt
    try:
        key = jwt.PyJWKClient(AI_AUTH + '/.well-known/jwks.json', timeout=20).get_signing_key_from_jwt(encoded)
        claims = jwt.decode(encoded, key.key, algorithms=['RS256'], audience=client_id,
                            issuer=AI_AUTH, options={'require': ['exp', 'iss', 'aud', 'sub', 'nonce']})
        if not secrets.compare_digest(str(claims.get('nonce', '')), nonce):
            raise ValueError('nonce')
        if subject and claims['sub'] != subject: raise ValueError('subject')
        if claims.get('azp') and claims['azp'] != client_id: raise ValueError('azp')
        return claims
    except Exception:
        raise RuntimeError('Não foi possível validar a identidade da conta. A conexão não foi salva.') from None


def ai_callback_values(query, state, selected=None):
    values = parse_qs(query, keep_blank_values=True)
    if any(len(v) != 1 for v in values.values()): raise ValueError('Callback duplicado.')
    values = {k:v[0] for k,v in values.items()}
    if not secrets.compare_digest(values.get('state', ''), state): raise ValueError('Callback inválido.')
    if values.get('error'): raise RuntimeError(ai_error(values['error']))
    client = values.get('client_id') or selected
    if not client or client == 'dynamic_agent_client' or (selected and client != selected):
        raise ValueError('Registro de aplicativo inválido.')
    if not values.get('code'): raise ValueError('Código de autorização ausente.')
    return values['code'], client


def ai_stream_text(response):
    parts = []; data = []; size = 0; deadline = time.monotonic()+300
    def event(lines):
        if not lines: return None
        raw = '\n'.join(lines)
        if raw == '[DONE]': return None
        return json.loads(raw)
    with response:
        while True:
            if time.monotonic()>deadline: raise RuntimeError('A resposta demorou além do prazo. Tente novamente.')
            line = response.readline(1024 * 1024)
            if not line: break
            size += len(line)
            if size > 8 * 1024 * 1024: raise RuntimeError('Resposta excedeu o limite de leitura do painel.')
            line = line.decode('utf-8').rstrip('\r\n')
            if line.startswith('data:'): data.append(line[5:].lstrip())
            elif not line and data:
                value = event(data); data = []
                if not value: continue
                kind = value.get('type')
                if kind == 'response.output_text.delta': parts.append(value.get('delta', ''))
                elif kind == 'response.completed':
                    text = ''.join(parts).strip()
                    if not text: raise RuntimeError('A IA concluiu sem devolver texto.')
                    return text
                elif kind in ('response.failed', 'response.incomplete', 'error'):
                    error = value.get('response', {}).get('error') or value.get('error') or {}
                    raise RuntimeError(ai_error(error.get('code') if isinstance(error, dict) else ''))
    raise RuntimeError('Resposta interrompida. O painel não aplicou o texto parcial; tente novamente.')


class ChatGPTConnection:
    def __init__(self, data=DATA):
        self.path = Path(data)/'chatgpt_registros.json'
        self.saved = json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {
            'host_id': 'urn:uuid:'+str(uuid.uuid4()), 'accounts': []}
        self.credentials = None
        self.models = []
        # Sem tokens, emails, histórico de conversa ou contatos neste arquivo.
        atomic_json(self.path, self.saved)

    def login(self, selected=None, cancel=None):
        ai_dependencies()
        previous = next((a for a in self.saved['accounts'] if a['client_id']==selected), None)
        if selected and not previous: raise ValueError('Selecione uma conta registrada.')
        state = secrets.token_urlsafe(32); nonce = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
        result = {}; expires = time.monotonic()+240
        class Callback(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_GET(handler):
                parsed = urlsplit(handler.path)
                if parsed.path != '/auth/callback':
                    handler.send_error(404); return
                try:
                    result['value'] = ai_callback_values(parsed.query, state, selected)
                    status = 200; message = 'Autorizacao recebida. Volte ao Painel WhatsApp para conferir a conexao.'
                except ValueError:
                    status = 400; message = 'Retorno invalido. Continue pelo navegador usado para entrar.'
                except RuntimeError as exc:
                    result['error'] = str(exc); status = 400; message = 'Autorizacao nao concluida. Volte ao painel.'
                body = message.encode()
                handler.send_response(status); handler.send_header('Content-Type','text/plain; charset=utf-8')
                handler.send_header('Cache-Control','no-store'); handler.send_header('Content-Length',str(len(body)))
                handler.end_headers(); handler.wfile.write(body)
        with HTTPServer(('127.0.0.1',0),Callback) as server:
            server.timeout = .5
            # Limita clientes locais lentos que conectem sem terminar a requisição.
            original_get_request = server.get_request
            def get_request():
                sock, addr = original_get_request(); sock.settimeout(2); return sock, addr
            server.get_request = get_request
            redirect = f'http://127.0.0.1:{server.server_port}/auth/callback'
            query = {'client_id': selected or 'dynamic_agent_client', 'ext_agent_host_id':self.saved['host_id'],
                     'response_type':'code','redirect_uri':redirect,'scope':AI_SCOPES,'resource':AI_RESOURCE,
                     'state':state,'nonce':nonce,'code_challenge_method':'S256','code_challenge':challenge}
            if not selected: query['agent_name_hint']='Painel WhatsApp'
            if not webbrowser.open(AI_AUTH+'/api/accounts/authorize?'+urlencode(query)):
                raise RuntimeError('Não foi possível abrir o navegador para entrar no ChatGPT.')
            while not result and time.monotonic()<expires:
                if cancel and cancel.is_set(): raise RuntimeError('Conexão cancelada.')
                server.handle_request()
        if cancel and cancel.is_set(): raise RuntimeError('Conexão cancelada.')
        if not result: raise RuntimeError('O prazo para entrar terminou. Clique em Continuar com ChatGPT novamente.')
        if 'error' in result: raise RuntimeError(result['error'])
        code, client = result['value']
        tokens = ai_http(AI_AUTH+'/api/accounts/oauth/token', {
            'grant_type':'authorization_code','client_id':client,'code':code,
            'code_verifier':verifier,'redirect_uri':redirect,'resource':AI_RESOURCE}, form=True)
        claims = ai_validate_identity(tokens.get('id_token',''),client,nonce,previous['subject'] if previous else None)
        scopes = tokens.get('scope','').split()
        if not {'resource.invoke','chatgpt.tokens.use.direct'}.issubset(scopes):
            raise RuntimeError('O uso do plano não foi autorizado. Confira as permissões no ChatGPT e tente novamente.')
        if tokens.get('token_type','').lower()!='bearer' or not tokens.get('access_token'):
            raise RuntimeError('A OpenAI não retornou uma autorização utilizável.')
        record = {'client_id':client,'subject':claims['sub'], 'label':f'Conta {len(self.saved["accounts"])+1}'}
        if previous: record = previous
        else: self.saved['accounts'].append(record)
        atomic_json(self.path,self.saved)
        # Sem offline_access: exige novo login quando expira; não guarda tokens no disco.
        self.credentials = {'access_token':tokens['access_token'],'client_id':client,
                            'expires':time.time()+float(tokens.get('expires_in',3600)),
                            'label':record['label']}
        self.models=[]
        return record['label']

    def disconnect(self):
        self.credentials=None; self.models=[]

    def token(self):
        if not self.credentials or time.time()>=self.credentials['expires']-30:
            self.disconnect()
            raise RuntimeError('Clique em Continuar com ChatGPT para autorizar esta sessão.')
        return self.credentials['access_token']

    def list_models(self):
        catalog = ai_http(AI_RESOURCE+'/models', token=self.token())
        self.models = [m for m in catalog.get('models',[]) if m.get('visibility')=='list' and m.get('slug')]
        if not self.models: raise RuntimeError('Sua conta não retornou modelos disponíveis para esta integração.')
        return self.models

    def ask(self, model, instructions, prompt):
        if model not in {m['slug'] for m in self.models}: raise ValueError('Selecione um modelo disponível na sua conta.')
        if not prompt.strip() or len(prompt)>30000: raise ValueError('Use um pedido de até 30.000 caracteres.')
        response = ai_http(AI_RESOURCE+'/responses', token=self.token(), stream=True, payload={
            'model':model, 'instructions':instructions,
            'input':[{'role':'user','content':prompt}], 'store':False,'stream':True})
        return ai_stream_text(response)


def ai_campaign_diagnostic(campaign, data=DATA):
    # Só contagens e categorias pré-definidas. Nunca envia CSV, nomes, números,
    # mensagens, caminhos locais, anexos ou credenciais para a IA.
    path=Path(data)/'historico.csv'; states=Counter(); categories=Counter(); total=0
    if path.exists():
        with path.open(encoding='utf-8-sig',newline='') as handle:
            sample=handle.read(4096);handle.seek(0)
            try: dialect=csv.Sniffer().sniff(sample,delimiters=';,\t')
            except csv.Error: dialect=csv.excel
            for row in csv.DictReader(handle,dialect=dialect):
                if row.get('campanha')!=campaign: continue
                total+=1
                status=row.get('status','')
                states[status if status in {'ENTREGUE','ENVIADO','FALHA','INCERTO','SIMULADO','JA_PROCESSADO','BLOQUEADO','INVALIDO','CONFLITO','RETOMADA_AUTORIZADA'} else 'OUTRO']+=1
                if status not in ('FALHA','INCERTO','INVALIDO','BLOQUEADO','CONFLITO'): continue
                reason=row.get('motivo','').lower()
                if 'inválido' in reason or 'sem conta' in reason: category='numero_recusado'
                elif 'sessão' in reason or 'sessao' in reason: category='sessao'
                elif 'conversa' in reason: category='abertura_conversa'
                elif 'antes_do_envio' in reason: category='falha_antes_envio'
                elif 'tique' in reason or 'confirmação' in reason: category='confirmacao_incerta'
                elif 'timeout' in reason: category='prazo_esgotado'
                else: category='outra_falha'
                categories[category]+=1
    return json.dumps({'registros_da_campanha':total,'eventos_por_status':dict(states),
                       'categorias_de_falha':dict(categories),
                       'observacao':'Contagens de eventos históricos, não de pessoas ou de situação atual. Envios manuais não são detectados.'},ensure_ascii=False,indent=2)
