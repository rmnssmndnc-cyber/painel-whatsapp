"""Painel Windows: contatos, mensagem, anexos e envio em um clique."""
from __future__ import annotations
import json
import os
import subprocess
import sys
import uuid
import threading
import queue
import atualizador
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import painel_core as core

ROOT, DATA = core.ROOT, core.DATA


class Panel(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Painel WhatsApp • '+atualizador.VERSION)
        self.restart_requested = False
        self.geometry('1150x810')
        self.minsize(960, 720)
        self.configure(bg='#eef2f6')
        self.proc = self.job = None
        self.draft = core.new_draft()
        self.error_on_load = None
        if (DATA/'painel_atual.json').exists():
            try:
                d = json.loads((DATA/'painel_atual.json').read_text(encoding='utf-8'))
                if not isinstance(d.get('contatos'), list) or not re_id(d.get('id','')): raise ValueError('Rascunho inválido.')
                self.draft.update(d)
            except Exception as exc:
                self.error_on_load = str(exc)
        self.name = tk.StringVar(value=self.draft['nome'])
        self.interval = tk.StringVar(value=str(self.draft['intervalo']))
        self.timeout = tk.StringVar(value=str(self.draft['confirmacao']))
        self.status = tk.StringVar(value='Pronto. Cole seus contatos e escolha os arquivos.')
        self.count = tk.StringVar()
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('.', font=('Segoe UI', 10), background='#eef2f6')
        style.configure('TButton', padding=(12, 8))
        style.configure('Send.TButton', background='#137b4b', foreground='white', font=('Segoe UI', 11, 'bold'))
        style.map('Send.TButton', background=[('disabled','#9bb5a7'),('active','#0f633d')])
        style.configure('Treeview', rowheight=27, background='white', fieldbackground='white')
        style.configure('Treeview.Heading', font=('Segoe UI', 10, 'bold'), background='#dce5ee')
        self.build()
        self.fill()
        self.protocol('WM_DELETE_WINDOW', self.close)
        if self.error_on_load:
            self.after(200, lambda: messagebox.showwarning('Rascunho não carregado',
                'O rascunho anterior não pôde ser lido. Use Abrir campanha para recuperar uma cópia.\n'+self.error_on_load))

    def build(self):
        outer = ttk.Frame(self, padding=18); outer.pack(fill='both', expand=True)
        top = ttk.Frame(outer); top.pack(fill='x')
        ttk.Label(top, text='PAINEL WHATSAPP', font=('Segoe UI', 20, 'bold')).pack(side='left')
        for label, command in [('Abrir campanha', self.open_campaign), ('Salvar', self.save), ('Nova campanha', self.new)]:
            ttk.Button(top, text=label, command=self.guard(command)).pack(side='right', padx=3)
        ttk.Label(outer, text='Contatos, mensagem e arquivos em um só lugar.', foreground='#506078').pack(anchor='w', pady=(2,12))
        line = ttk.Frame(outer); line.pack(fill='x', pady=(0,8))
        ttk.Label(line, text='Campanha').pack(side='left')
        ttk.Entry(line, textvariable=self.name, width=38).pack(side='left', padx=8)
        ttk.Label(line, text='Intervalo (seg.)').pack(side='left', padx=(16,4))
        ttk.Spinbox(line, from_=1, to=3600, textvariable=self.interval, width=6).pack(side='left')
        ttk.Label(line, text='Prazo de confirmação (seg.)').pack(side='left', padx=(16,4))
        ttk.Spinbox(line, from_=10, to=180, textvariable=self.timeout, width=6).pack(side='left')
        self.campaign_label = ttk.Label(outer, foreground='#58667a'); self.campaign_label.pack(anchor='w')
        ttk.Button(outer, text='Atualizações', command=self.guard(self.updates)).pack(anchor='e')
        notebook = ttk.Notebook(outer); notebook.pack(fill='both', expand=True, pady=12)
        contacts = ttk.Frame(notebook, padding=12); notebook.add(contacts, text='  1. Contatos  ')
        compose = ttk.Frame(notebook, padding=12); notebook.add(compose, text='  2. Mensagem e arquivos  ')
        tools = ttk.Frame(contacts); tools.pack(fill='x')
        for label, cmd in [('Colar contatos',self.paste),('Importar planilha',self.import_file),
                           ('Adicionar',self.add_contact),('Editar',self.edit_contact),('Remover',self.remove_contacts)]:
            ttk.Button(tools,text=label,command=self.guard(cmd)).pack(side='left',padx=(0,6))
        ttk.Label(contacts,text='Todos os contatos da lista recebem. Selecionar uma linha serve apenas para editar ou remover.',
                  foreground='#506078').pack(anchor='w',pady=(10,3))
        ttk.Label(contacts,text='Telefone com DDD: acrescentamos 55 aos números brasileiros de 10 ou 11 dígitos.',
                  foreground='#506078').pack(anchor='w',pady=(0,8))
        area=ttk.Frame(contacts);area.pack(fill='both',expand=True)
        self.table=ttk.Treeview(area,columns=core.COLUMNS,show='headings',selectmode='extended')
        for col,width in zip(core.COLUMNS,[500,350]):
            self.table.heading(col,text=col.capitalize());self.table.column(col,width=width,minwidth=70)
        scroll=ttk.Scrollbar(area,orient='vertical',command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        self.table.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        self.table.bind('<Double-1>',lambda e:self.guard(self.edit_contact)())
        ttk.Label(contacts,textvariable=self.count).pack(anchor='w',pady=(8,0))
        ttk.Label(compose,text='Mensagem',font=('Segoe UI',11,'bold')).pack(anchor='w')
        self.message=tk.Text(compose,height=7,wrap='word',font=('Segoe UI',11),undo=True,relief='solid',bd=1)
        self.message.pack(fill='both',expand=True,pady=(5,5))
        ttk.Label(compose,text='Escreva sobre qualquer assunto. Use {nome} se quiser personalizar. Texto separado dos anexos.',
                  foreground='#506078').pack(anchor='w')
        ttk.Button(compose,text='Ver prévia personalizada',command=self.guard(self.preview)).pack(anchor='w',pady=6)
        filebar=ttk.Frame(compose);filebar.pack(fill='x',pady=(10,4))
        ttk.Label(filebar,text='Arquivos para todos os contatos',font=('Segoe UI',11,'bold')).pack(side='left')
        ttk.Button(filebar,text='Remover arquivo',command=self.guard(self.remove_files)).pack(side='right')
        ttk.Button(filebar,text='+ Adicionar fotos ou PDFs',command=self.guard(self.add_files)).pack(side='right',padx=6)
        self.files=tk.Listbox(compose,height=5,font=('Segoe UI',10),selectmode='extended',exportselection=False)
        self.files.pack(fill='x')
        ttk.Label(compose,text='Até 8 arquivos de 15 MB. O programa guarda uma cópia automaticamente.',
                  foreground='#506078').pack(anchor='w',pady=(4,0))
        bottom=ttk.Frame(outer);bottom.pack(fill='x')
        self.sim=ttk.Button(bottom,text='Simular sem enviar',command=lambda:self.start('simular'));self.sim.pack(side='left')
        self.send=ttk.Button(bottom,text='ENVIAR CAMPANHA',style='Send.TButton',command=lambda:self.start('enviar'));self.send.pack(side='left',padx=10)
        self.stop=ttk.Button(bottom,text='Parar',command=self.stop_run,state='disabled');self.stop.pack(side='left')
        ttk.Button(bottom,text='Revisar pendências',command=self.guard(self.review)).pack(side='right')
        ttk.Button(bottom,text='Abrir relatórios',command=self.open_reports).pack(side='right',padx=6)
        ttk.Label(outer,text='Enviar inicia imediatamente para toda a lista. Nova campanha permite enviar novamente.',
                  foreground='#506078').pack(anchor='w',pady=(10,3))
        ttk.Label(outer,textvariable=self.status,wraplength=1050,font=('Segoe UI',10,'bold')).pack(anchor='w')

    def guard(self, callback):
        def call():
            if self.job:
                messagebox.showinfo('Execução em andamento','Aguarde terminar ou clique em Parar antes de editar a campanha.');return
            try: return callback()
            except Exception as exc: messagebox.showerror('Não foi possível concluir',str(exc))
        return call

    def fill(self):
        self.name.set(self.draft['nome']);self.interval.set(str(self.draft['intervalo']));self.timeout.set(str(self.draft['confirmacao']))
        self.message.delete('1.0','end');self.message.insert('1.0',self.draft['mensagem'])
        self.table.delete(*self.table.get_children())
        for row in self.draft['contatos']:self.table.insert('','end',values=[row.get(k,'') for k in core.COLUMNS])
        self.files.delete(0,'end')
        for path in self.draft['anexos']:self.files.insert('end',Path(path).name)
        self.count.set(f'{len(self.draft["contatos"])} contato(s) na lista • limite de 1.000')
        self.campaign_label.configure(text='Identificador automático da campanha: '+self.draft['id'])

    def capture(self):
        self.draft.update(nome=self.name.get().strip(),mensagem=self.message.get('1.0','end-1c'),
                          intervalo=int(self.interval.get()),confirmacao=int(self.timeout.get()))
        return self.draft

    def save(self):
        self.capture()
        core.atomic_json(DATA/'campanhas'/f'{self.draft["id"]}.json',self.draft)
        core.atomic_json(DATA/'painel_atual.json',self.draft)
        self.status.set('Campanha salva. O histórico evita repetir envios.')

    def new(self):
        self.save()
        self.draft=core.new_draft();self.fill();self.save()
        self.status.set('Nova campanha vazia. Adicione os destinatários, a mensagem e os arquivos.')

    def open_campaign(self):
        path=filedialog.askopenfilename(title='Abrir campanha salva',initialdir=DATA/'campanhas',filetypes=[('Campanhas','*.json')])
        if not path:return
        candidate=json.loads(Path(path).read_text(encoding='utf-8'))
        if not re_id(candidate.get('id','')) or not isinstance(candidate.get('contatos'),list):raise ValueError('Arquivo de campanha inválido.')
        self.save();self.draft=core.new_draft()|candidate;self.fill();self.save()

    def paste(self):
        try: text=self.clipboard_get()
        except tk.TclError:raise ValueError('Copie primeiro as células com nomes e telefones.')
        self.mapping_dialog(core.parse_text(text))

    def import_file(self):
        path=filedialog.askopenfilename(title='Escolher lista de contatos',filetypes=[('Planilhas e listas','*.xlsx *.xlsm *.csv *.tsv'),('Todos os arquivos','*.*')])
        if not path:return
        if Path(path).suffix.lower() in ('.xlsx','.xlsm'):
            names=core.file_matrix(path)
            win=tk.Toplevel(self);win.title('Escolha a aba');win.transient(self);win.grab_set()
            ttk.Label(win,text='Qual aba contém os contatos?',padding=12).pack()
            choice=tk.StringVar(value=names[0]);ttk.Combobox(win,textvariable=choice,values=names,state='readonly',width=38).pack(padx=12)
            def chosen():
                try:matrix=core.file_matrix(path,choice.get())
                except Exception as exc:messagebox.showerror('Importação',str(exc),parent=win);return
                win.destroy();self.mapping_dialog(matrix)
            ttk.Button(win,text='Continuar',command=chosen).pack(pady=12)
        else:self.mapping_dialog(core.file_matrix(path))

    def mapping_dialog(self,matrix):
        if not matrix:raise ValueError('A lista está vazia.')
        header,mapping=core.suggested_mapping(matrix)
        win=tk.Toplevel(self);win.title('Organizar colunas');win.geometry('730x470');win.transient(self);win.grab_set()
        box=ttk.Frame(win,padding=16);box.pack(fill='both',expand=True)
        ttk.Label(box,text='Confira as colunas antes de adicionar à lista.',font=('Segoe UI',12,'bold')).pack(anchor='w')
        first_header=tk.BooleanVar(value=header)
        ttk.Checkbutton(box,text='A primeira linha contém títulos (Nome, Telefone...)',variable=first_header).pack(anchor='w',pady=8)
        width=max(map(len,matrix));options=['Não usar']+[f'Coluna {i+1}: {str(matrix[0][i])[:35] if i<len(matrix[0]) else ""}' for i in range(width)]
        combos={}
        for key in core.COLUMNS:
            row=ttk.Frame(box);row.pack(fill='x',pady=3)
            ttk.Label(row,text=key.capitalize(),width=12).pack(side='left')
            c=ttk.Combobox(row,values=options,state='readonly',width=58);c.pack(side='left')
            c.current((mapping[key]+1) if mapping[key] is not None else 0);combos[key]=c
        sample=tk.Text(box,height=6,wrap='none',font=('Consolas',9));sample.pack(fill='both',expand=True,pady=12)
        sample.insert('1.0','\n'.join(' | '.join(row) for row in matrix[:5]));sample.configure(state='disabled')
        def add():
            try:
                mapped={k:c.current()-1 if c.current()>0 else None for k,c in combos.items()}
                rows=core.map_contacts(matrix,mapped,first_header.get())
                if len(rows)+len(self.draft['contatos'])>1000:raise ValueError('A lista final excede 1.000 contatos.')
                self.capture();self.draft['contatos'].extend(rows);self.fill();self.save();win.destroy()
                self.status.set(f'{len(rows)} contatos adicionados. Confira os nomes e telefones na tabela.')
            except Exception as exc:messagebox.showerror('Importação',str(exc),parent=win)
        ttk.Button(box,text='Adicionar à lista',command=add).pack(anchor='e')

    def add_contact(self):self.contact_dialog(None)
    def edit_contact(self):
        chosen=self.table.selection()
        if len(chosen)!=1:raise ValueError('Selecione uma linha para editar.')
        self.contact_dialog(self.table.index(chosen[0]))

    def contact_dialog(self,index):
        win=tk.Toplevel(self);win.title('Contato');win.transient(self);win.grab_set()
        row=self.draft['contatos'][index] if index is not None else {}
        fields={}
        for i,key in enumerate(core.COLUMNS):
            ttk.Label(win,text=key.capitalize()).grid(row=i,column=0,padx=12,pady=7,sticky='w')
            v=tk.StringVar(value=row.get(key,''));ttk.Entry(win,textvariable=v,width=40).grid(row=i,column=1,padx=12,pady=7);fields[key]=v
        def done():
            try:
                data={k:v.get().strip() for k,v in fields.items()}
                if not data['nome']:raise ValueError('Preencha o nome.')
                data['telefone']=core.normalize_phone(data['telefone']);self.capture()
                if index is None:
                    if len(self.draft['contatos'])>=1000:raise ValueError('Limite de 1.000 contatos.')
                    self.draft['contatos'].append(data)
                else:self.draft['contatos'][index]=data
                self.fill();self.save();win.destroy()
            except Exception as exc:messagebox.showerror('Contato',str(exc),parent=win)
        ttk.Button(win,text='Salvar contato',command=done).grid(row=len(core.COLUMNS),column=1,pady=12,sticky='e',padx=12)

    def remove_contacts(self):
        indices=sorted((self.table.index(i) for i in self.table.selection()),reverse=True)
        self.capture()
        for i in indices:del self.draft['contatos'][i]
        self.fill();self.save()

    def add_files(self):
        files=filedialog.askopenfilenames(title='Escolher fotos e PDFs',filetypes=[('Fotos e PDFs','*.jpg *.jpeg *.png *.pdf')])
        if not files:return
        if len(files)+len(self.draft['anexos'])>8:raise ValueError('Use até oito anexos.')
        staged=[core.stage_attachment(path) for path in files]
        self.capture()
        for path in staged:
            if path not in self.draft['anexos']:self.draft['anexos'].append(path)
        self.fill();self.save()

    def remove_files(self):
        self.capture()
        for i in reversed(self.files.curselection()):del self.draft['anexos'][i]
        self.fill();self.save()

    def preview(self):
        cfg,rows=core.prepare(self.capture())
        win=tk.Toplevel(self);win.title('Prévia • primeiro contato');win.geometry('660x420')
        text=tk.Text(win,wrap='word',font=('Segoe UI',11));text.pack(fill='both',expand=True,padx=16,pady=16)
        text.insert('1.0',f'Para: {rows[0]["nome"]} — {rows[0]["telefone"]}\n\n'+core.motor.personalize(cfg['modelo'],rows[0])+
                    '\n\nAnexos separados:\n'+'\n'.join(Path(p).name for p in self.draft['anexos']))
        text.configure(state='disabled')

    def start(self,mode):
        if self.job:return
        try:
            self.capture();cfg,rows=core.prepare(self.draft)
            # Usa sempre a cópia persistente e telefones normalizados mostrados na tabela.
            self.draft['contatos']=[{k:r[k] for k in core.COLUMNS} for r in rows]
            self.fill();self.save()
            with core.execution_lock():
                (DATA/'PARAR').unlink(missing_ok=True)
            job=DATA/'execucoes_painel'/(uuid.uuid4().hex+'.json')
            core.atomic_json(job,{'campanha':self.draft,'modo':mode,'criado_em':core.stamp()})
            python=ROOT/'.venv'/'Scripts'/'python.exe'
            if not python.exists():python=Path(sys.executable).with_name('python.exe') if os.name=='nt' else Path(sys.executable)
            if not python.exists():raise ValueError('Python não encontrado. Use INICIAR_PAINEL.cmd na pasta do projeto.')
            flags=subprocess.CREATE_NEW_CONSOLE if os.name=='nt' else 0
            args=[str(python),'-u',str(ROOT/'painel_worker.py'),str(job)]
            if os.name=='nt':args.append('--manter-aberto')
            self.proc=subprocess.Popen(args,cwd=ROOT,creationflags=flags)
            self.job=job;self.send.configure(state='disabled');self.sim.configure(state='disabled');self.stop.configure(state='normal')
            self.status.set('Execução iniciada. Acompanhe a janela de comandos; não feche o navegador do WhatsApp.')
            self.after(500,self.poll)
        except Exception as exc:messagebox.showerror('Não foi possível iniciar',str(exc))

    def poll(self):
        if not self.job:return
        result=self.job.with_suffix('.resultado.json')
        if result.exists():
            try:
                r=json.loads(result.read_text(encoding='utf-8'))
                if not r['ok']:self.status.set('Falha: '+r['erro'])
                else:
                    s=r['resumo']
                    if s['modo']=='simular':self.status.set(f'Simulação concluída: {s["contatos"]} contatos, {s["simulados"]} itens. Nenhuma mensagem enviada.')
                    else:self.status.set(f'Execução encerrada. Campanha: {s["entregues_no_historico"]} entregues, {s["enviados_no_historico"]} enviados, {s["incertos"]} incertos, {s["pendentes"]} pendentes. Detalhes no CMD.')
            except Exception as exc:self.status.set('Não foi possível ler o resumo: '+str(exc))
            self.end_run();return
        if self.proc.poll() is not None:
            self.status.set('Processo encerrado sem resumo. Confira o CMD e as pendências antes de retomar.');self.end_run();return
        self.after(500,self.poll)

    def end_run(self):
        self.job=None;self.proc=None;self.send.configure(state='normal');self.sim.configure(state='normal');self.stop.configure(state='disabled')

    def stop_run(self):
        (DATA/'PARAR').write_text('parar',encoding='utf-8')
        self.status.set('Parada solicitada. A ação atual pode terminar antes de parar; aguarde.')

    def open_reports(self):
        path=DATA/'execucoes_painel';path.mkdir(parents=True,exist_ok=True)
        if os.name=='nt':os.startfile(str(DATA))
        else:messagebox.showinfo('Relatórios',str(DATA))

    def review(self):
        pending=core.uncertain_items(self.draft['id'])
        if not pending:messagebox.showinfo('Pendências','Esta campanha não tem itens incertos.');return
        win=tk.Toplevel(self);win.title('Revisar pendências');win.geometry('940x420');win.transient(self);win.grab_set()
        ttk.Label(win,text='Marque como recebido SOMENTE após conferir o item no WhatsApp. Esta ação não envia mensagens.',wraplength=890,padding=12).pack()
        tree=ttk.Treeview(win,columns=('telefone','item','hora','motivo','conteudo'),show='headings',selectmode='browse')
        for k in ('telefone','item','hora','motivo','conteudo'):tree.heading(k,text=k.capitalize());tree.column(k,width=150,minwidth=50)
        tree.column('item',width=70);tree.pack(fill='both',expand=True,padx=12)
        for values in pending:tree.insert('','end',values=values)
        detail=tk.StringVar(value='Selecione uma linha para ver o conteúdo exato da tentativa.')
        ttk.Label(win,textvariable=detail,wraplength=900,padding=10).pack(fill='x')
        def show_detail(event=None):
            selected=tree.selection()
            if selected:
                values=tree.item(selected[0],'values')
                detail.set('Conteúdo: '+values[4]+'\nMotivo: '+values[3])
        tree.bind('<<TreeviewSelect>>',show_detail)
        def action(kind):
            try:
                selection=tree.selection()
                if len(selection)!=1:raise ValueError('Selecione um item.')
                values=tree.item(selection[0],'values')
                core.review_item(self.draft['id'],values[0],values[1],kind)
                tree.delete(selection[0]);self.status.set('Revisão registrada. Clique em Enviar para continuar os itens pendentes.')
            except Exception as exc:messagebox.showerror('Revisão',str(exc),parent=win)
        buttons=ttk.Frame(win,padding=12);buttons.pack(fill='x')
        ttk.Button(buttons,text='Conferi no WhatsApp: este item chegou',command=lambda:action('recebido')).pack(side='left')
        ttk.Button(buttons,text='Liberar falha comprovada antes do envio',command=lambda:action('retomar')).pack(side='right')

    def updates(self):
        self.save()
        win=tk.Toplevel(self);win.title('Atualizações');win.geometry('660x410');win.transient(self);win.grab_set()
        box=ttk.Frame(win,padding=18);box.pack(fill='both',expand=True)
        ttk.Label(box,text='Versão instalada: '+atualizador.VERSION,font=('Segoe UI',13,'bold')).pack(anchor='w')
        ttk.Label(box,text='Instale novas versões sem copiar os arquivos manualmente.',wraplength=600).pack(anchor='w',pady=8)
        settings=DATA/'fonte_atualizacoes.json'
        config=json.loads(settings.read_text(encoding='utf-8')) if settings.exists() else {}
        url=tk.StringVar(value=config.get('url',''))
        ttk.Label(box,text='Endereço de publicação das atualizações:').pack(anchor='w')
        entry=ttk.Entry(box,textvariable=url);entry.pack(fill='x',pady=6)
        status=tk.StringVar(value='Sem endereço? Use Instalar ZIP recebido aqui. Escolha apenas pacotes de origem confiável.')
        ttk.Label(box,textvariable=status,wraplength=600).pack(anchor='w',pady=12)
        actions=ttk.Frame(box);actions.pack(fill='x')
        buttons=[];busy=[False];results=queue.Queue()
        def run(task,done):
            busy[0]=True
            for b in buttons:b.configure(state='disabled')
            entry.configure(state='disabled')
            def work():
                try:results.put((True,task()))
                except Exception as exc:results.put((False,str(exc)))
            threading.Thread(target=work,daemon=True).start()
            def poll():
                try:ok,value=results.get_nowait()
                except queue.Empty:win.after(100,poll);return
                busy[0]=False
                for b in buttons:b.configure(state='normal')
                entry.configure(state='normal')
                if ok:done(value)
                else:status.set('Não foi possível atualizar: '+value)
            win.after(100,poll)
        def installed(result):
            self.restart_requested=True
            messagebox.showinfo('Atualização instalada','Versão '+result[0]+' instalada. O painel será reaberto. Seus dados foram preservados.',parent=win)
            win.destroy();self.destroy()
        def install(path,expected=None):
            status.set('Validando pacote e instalando. Aguarde...')
            def task():
                with core.execution_lock(DATA):
                    return atualizador.install(path,ROOT,expected=expected)
            run(task,installed)
        def local():
            path=filedialog.askopenfilename(parent=win,title='Escolher ZIP da nova versão',filetypes=[('Atualização do painel','*.zip')])
            if path:install(path)
        def checked(manifest):
            if not manifest:status.set('Você já está na versão mais recente publicada nessa fonte.');return
            status.set('Baixando a versão '+manifest['version']+'...')
            def task():
                path=atualizador.download(manifest,DATA/'downloads_atualizacao')
                try:
                    with core.execution_lock(DATA):return atualizador.install(path,ROOT,expected=manifest['version'])
                finally:path.unlink(missing_ok=True)
            run(task,installed)
        def online():
            source=url.get().strip()
            if not source:status.set('A publicação online ainda não está configurada. Use Instalar ZIP recebido aqui.');return
            try:
                atualizador.https(source)
                core.atomic_json(settings,{'url':source})
            except Exception as exc:status.set(str(exc));return
            status.set('Verificando novas versões...')
            run(lambda:atualizador.check(source),checked)
        for label,cmd in [('Verificar e atualizar',online),('Instalar ZIP recebido aqui',local)]:
            b=ttk.Button(actions,text=label,command=cmd);b.pack(side='left',padx=4);buttons.append(b)
        ttk.Label(box,text='Ao atualizar, o painel reinicia. Contatos, histórico, sessão e anexos continuam na pasta dados. Não há custo de API.',wraplength=600).pack(anchor='w',pady=18)
        win.protocol('WM_DELETE_WINDOW',lambda:None if busy[0] else win.destroy())

    def close(self):
        if self.job:
            self.stop_run();self.status.set('Aguarde a parada terminar antes de fechar o painel.');return
        try:self.save()
        except Exception as exc:
            messagebox.showerror('Não foi possível salvar',str(exc)+'\nCorrija os campos antes de fechar.');return
        self.destroy()


def re_id(value):
    import re
    return isinstance(value,str) and re.fullmatch(r'PAINEL-[A-F0-9]{16}',value) is not None


def main():
    # Impede duas interfaces de sobrescreverem o mesmo rascunho.
    with core.execution_lock(name='painel_interface.lock'):
        with core.execution_lock(DATA):
            recovered=atualizador.recover(ROOT)
        if recovered:
            restart=True
        else:
            panel=Panel();panel.mainloop()
            restart=panel.restart_requested
    if restart:
        subprocess.Popen([sys.executable,str(ROOT/'painel.py')],cwd=ROOT)


if __name__=='__main__':
    try:main()
    except Exception as exc:
        try:
            root=tk.Tk();root.withdraw();messagebox.showerror('Painel WhatsApp',str(exc));root.destroy()
        except Exception:print(str(exc),file=sys.stderr)
