"""Atualização por pacote validado; rede somente mediante fonte HTTPS configurada."""
import ast
import hashlib
import json
import os
import re
import shutil
import tempfile
import uuid
import zipfile
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import urlopen
from datetime import datetime

VERSION = '2.4.11'
APP = 'painel-whatsapp'
ALLOWED = {'painel.py','painel_core.py','painel_worker.py','motor_whatsapp.py',
           'atualizador.py','seletores_painel.json','INICIAR_PAINEL.cmd',
           'LEIA_PRIMEIRO.html','versao.json','test_painel.py','test_atualizador.py'}
REQUIRED = {'painel.py','painel_core.py','painel_worker.py','motor_whatsapp.py',
            'atualizador.py','seletores_painel.json','versao.json'}
LIMIT = 20 * 1024 * 1024


def version(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d+\.\d+\.\d+',value):
        raise ValueError('Versão do pacote inválida.')
    return tuple(map(int,value.split('.')))


def https(url):
    p=urlparse(url)
    if p.scheme!='https' or not p.hostname or p.username or p.password:
        raise ValueError('A fonte de atualização deve ser um endereço HTTPS.')
    return url


def fetch(url,limit=LIMIT):
    with urlopen(https(url),timeout=20) as response:
        https(response.geturl())
        content=response.read(limit+1)
    if len(content)>limit: raise ValueError('Atualização excede o tamanho permitido.')
    return content


def check(url,current=VERSION):
    manifest=json.loads(fetch(url,65536))
    if manifest.get('app')!=APP: raise ValueError('A fonte não pertence ao Painel WhatsApp.')
    if version(manifest.get('version'))<=version(current): return None
    https(manifest.get('url',''))
    if not re.fullmatch('[a-f0-9]{64}',manifest.get('sha256','')):
        raise ValueError('A fonte não informou a verificação do pacote.')
    return manifest


def download(manifest,directory):
    content=fetch(manifest['url'])
    if hashlib.sha256(content).hexdigest()!=manifest['sha256']:
        raise ValueError('O download não corresponde à versão publicada. Nada foi instalado.')
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    path=directory/(uuid.uuid4().hex+'.zip');path.write_bytes(content)
    return path


def inspect_package(path,current=VERSION,expected=None):
    """Nunca extrai caminhos fornecidos pelo ZIP e nunca aceita arquivos de dados."""
    if Path(path).stat().st_size>LIMIT: raise ValueError('Pacote muito grande.')
    files={}
    with zipfile.ZipFile(path) as z:
        if sum(i.file_size for i in z.infolist())>LIMIT: raise ValueError('Pacote expandido muito grande.')
        for entry in z.infolist():
            if entry.is_dir(): continue
            name=entry.filename
            if name.startswith('Painel_WhatsApp/'):name=name[len('Painel_WhatsApp/'):]
            if name not in ALLOWED or name in files or ((entry.external_attr>>16)&0o170000)==0o120000:
                raise ValueError('Arquivo não permitido ou repetido no pacote: '+name)
            files[name]=z.read(entry)
    if not REQUIRED.issubset(files): raise ValueError('Pacote incompleto. Use o ZIP de atualização do painel.')
    info=json.loads(files['versao.json'])
    if info.get('app')!=APP: raise ValueError('Pacote de outro aplicativo.')
    if version(info.get('version'))<=version(current): raise ValueError('Esta versão já está instalada ou é mais antiga.')
    if expected and info['version']!=expected: raise ValueError('Versão diferente da anunciada.')
    hashes=info.get('files',{})
    if set(hashes)!=set(files)-{'versao.json'}: raise ValueError('Lista de arquivos incompleta.')
    for name,data in files.items():
        if name!='versao.json' and hashlib.sha256(data).hexdigest()!=hashes[name]:
            raise ValueError('Arquivo danificado: '+name)
        if name.endswith('.py'): ast.parse(data.decode('utf-8-sig'),filename=name)
    return info,files


def install(path,root,current=VERSION,expected=None):
    """O chamador deve manter os bloqueios de interface e execução durante a instalação."""
    root=Path(root).resolve()
    info,files=inspect_package(path,current,expected)
    backup=root/'dados'/'backups_atualizacao'/(datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8])
    backup.mkdir(parents=True)
    existing=set()
    for name in files:
        dest=root/name
        if dest.is_symlink(): raise ValueError('Arquivo do programa é um link: '+name)
        if dest.exists():
            if not dest.is_file():raise ValueError('Destino inválido: '+name)
            shutil.copy2(dest,backup/name);existing.add(name)
    # Journal enables recovery after power loss before another program execution.
    journal=root/'dados'/'atualizacao_pendente.json'
    journal.write_text(json.dumps({'backup':str(backup),'files':sorted(files),'existing':sorted(existing)}),encoding='utf-8')
    try:
        with tempfile.TemporaryDirectory(dir=root,prefix='atualizacao_') as temp:
            for name,data in files.items(): (Path(temp)/name).write_bytes(data)
            for name in files: os.replace(Path(temp)/name,root/name)
        journal.unlink()
    except Exception:
        recover(root)
        raise
    return info['version'],backup


def recover(root):
    root=Path(root).resolve();journal=root/'dados'/'atualizacao_pendente.json'
    if not journal.exists():return False
    data=json.loads(journal.read_text(encoding='utf-8'));backup=Path(data['backup']).resolve()
    if not backup.is_relative_to((root/'dados'/'backups_atualizacao').resolve()):raise ValueError('Backup inválido.')
    if not set(data['files']).issubset(ALLOWED):raise ValueError('Recuperação inválida.')
    for name in data['files']:
        if name in data['existing']:shutil.copy2(backup/name,root/name)
        else:(root/name).unlink(missing_ok=True)
    journal.unlink();return True
