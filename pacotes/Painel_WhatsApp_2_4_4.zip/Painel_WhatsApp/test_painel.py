"""Testes locais sem navegador e sem envios. Executar: python -m unittest test_painel -v"""
import contextlib
import io
import itertools
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import painel_core as core


class FakeTransport:
    def __init__(self): self.calls=[]; self.chats=[]; self.closed=False
    def open_chat(self,p): self.chats.append(p)
    def send(self,kind,value): self.calls.append((kind,value));return 'ENTREGUE','Transporte fictício de teste.'
    def close(self): self.closed=True


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.draft=core.new_draft();self.draft['mensagem']='Olá, {nome}!'
        self.draft['contatos']=[{'nome':f'Pessoa {i}','telefone':f'2190000000{i}'} for i in range(1,4)]
        image=self.root/'foto.jpg';image.write_bytes(b'fixture jpg')
        pdf=self.root/'material.pdf';pdf.write_bytes(b'%PDF-fixture')
        self.draft['anexos']=[str(image),str(pdf)]
    def tearDown(self):self.tmp.cleanup()
    def run_job(self,mode='enviar',transport=None,**kwargs):
        adapter=transport or FakeTransport()
        with contextlib.redirect_stdout(io.StringIO()),patch.object(core.motor.time,'monotonic',side_effect=itertools.count(0,2)):
            result=core.execute(self.draft,mode,self.root,transport_factory=lambda *_:adapter,**kwargs)
        return result,adapter
    def test_three_people_nine_items(self):
        result,adapter=self.run_job()
        self.assertEqual(len(adapter.calls),9);self.assertEqual(len(adapter.chats),3)
        self.assertEqual([v for k,v in adapter.calls if k=='texto'],['Olá, Pessoa 1!','Olá, Pessoa 2!','Olá, Pessoa 3!'])
        self.assertEqual(result['entregues_no_historico'],9);self.assertTrue(adapter.closed)
    def test_duplicate_run_does_not_send(self):
        self.run_job();result,adapter=self.run_job()
        self.assertEqual(adapter.calls,[]);self.assertEqual(result['ocorrencias_desta_execucao']['JA_PROCESSADO'],3)
    def test_simulation_does_not_open_transport(self):
        result,adapter=self.run_job('simular')
        self.assertEqual(result['simulados'],9);self.assertEqual(adapter.chats,[])
        result,adapter=self.run_job();self.assertEqual(len(adapter.calls),9)
    def test_duplicate_phone_blocks_entire_batch(self):
        self.draft['contatos'][2]['telefone']=self.draft['contatos'][0]['telefone']
        adapter=FakeTransport()
        with self.assertRaisesRegex(ValueError,'duplicado'):self.run_job(transport=adapter)
        self.assertEqual(adapter.calls,[])
    def test_missing_file_blocks_entire_batch(self):
        self.draft['anexos'].append(str(self.root/'ausente.pdf'))
        with self.assertRaisesRegex(ValueError,'não encontrado'):self.run_job()
    def test_missing_personalization_blocks(self):
        self.draft['mensagem']='Olá {nome}, turma {turma}'
        with self.assertRaisesRegex(ValueError,'não suportado'):self.run_job()
    def test_free_subject_without_personalization(self):
        self.draft['mensagem']='Convite para o culto de domingo.'
        result,adapter=self.run_job()
        self.assertEqual([v for k,v in adapter.calls if k=='texto'],[self.draft['mensagem']]*3)
    def test_legacy_contact_fields_do_not_change_message(self):
        self.run_job()
        for row in self.draft['contatos']:
            row.update(curso='Antigo',turma='A',codigo='123')
        result,adapter=self.run_job()
        self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['JA_PROCESSADO'],3)
    def test_unknown_placeholder_blocks(self):
        self.draft['mensagem']='Olá {nome.__class__}'
        with self.assertRaisesRegex(ValueError,'não suportado'):self.run_job()
    def test_changed_content_conflict(self):
        self.run_job();self.draft['mensagem']='Outro texto'
        result,adapter=self.run_job();self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['CONFLITO'],3)
    def test_uncertain_never_auto_retries(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):self.calls.append((k,v));raise RuntimeError('Sem confirmação')
        result,adapter=self.run_job(transport=Uncertain());self.assertEqual(result['incertos'],1)
        result,adapter=self.run_job();self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['BLOQUEADO'],1)
    def test_manual_received_continues_only_attachments(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):raise RuntimeError('Sem confirmação')
        self.run_job(transport=Uncertain());cfg,rows=core.prepare(self.draft)
        core.review_item(cfg['campanha'],rows[0]['telefone'],'00-texto','recebido',self.root)
        result,adapter=self.run_job();self.assertEqual([k for k,v in adapter.calls],['anexo','anexo'])
        self.assertEqual(result['entregues_no_historico'],3)
    def test_retry_unknown_result_refused(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):raise RuntimeError('Sem confirmação')
        self.run_job(transport=Uncertain());cfg,rows=core.prepare(self.draft)
        with self.assertRaises(ValueError):core.review_item(cfg['campanha'],rows[0]['telefone'],'00-texto','retomar',self.root)
    def test_stop_before_start_is_respected(self):
        (self.root/'PARAR').touch()
        result,adapter=self.run_job(reset_stop=False)
        self.assertEqual(adapter.calls,[]);self.assertTrue(result['parado']);self.assertEqual(result['pendentes'],9)
    def test_second_process_lock_denied(self):
        with core.execution_lock(self.root):
            with self.assertRaises(ValueError):
                with core.execution_lock(self.root):pass
    def test_copy_file_survives_source_removed(self):
        source=Path(self.draft['anexos'][0]);dest=core.stage_attachment(source,self.root)
        source.unlink();self.assertEqual(Path(dest).read_bytes(),b'fixture jpg')
    def test_header_mapping(self):
        m=core.parse_text('Telefone;Nome;Turma\n21900000001;Ana;A\n21900000002;Bia;B')
        header,mapping=core.suggested_mapping(m);rows=core.map_contacts(m,mapping,header)
        self.assertTrue(header);self.assertEqual(rows[0]['nome'],'Ana');self.assertEqual(set(rows[1]),{'nome','telefone'})
    def test_paste_without_header(self):
        m=core.parse_text('Ana\t21900000001\nBia\t21900000002')
        header,mapping=core.suggested_mapping(m);self.assertFalse(header)
        self.assertEqual(len(core.map_contacts(m,mapping,header)),2)
    def test_phone_normalization(self):
        self.assertEqual(core.normalize_phone('(21) 90000-0001'),'5521900000001')
        self.assertEqual(core.normalize_phone('5521900000001.0'),'5521900000001')
        self.assertEqual(core.normalize_phone('+12025550123'),'12025550123')
        with self.assertRaises(ValueError):core.normalize_phone('5.521E+12')
    def test_empty_list(self):
        self.draft['contatos']=[]
        with self.assertRaises(ValueError):core.prepare(self.draft)
    def test_new_campaign_has_unique_id(self):
        self.assertNotEqual(core.new_draft()['id'],core.new_draft()['id'])
    def test_atomic_json_roundtrip(self):
        path=self.root/'a.json';core.atomic_json(path,self.draft)
        self.assertEqual(json.loads(path.read_text()),self.draft)
    def test_xlsx_read_shared_and_inline(self):
        path=self.root/'list.xlsx';ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
        with zipfile.ZipFile(path,'w') as z:
            z.writestr('xl/workbook.xml',f'<workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Lista" r:id="r1"/></sheets></workbook>')
            z.writestr('xl/_rels/workbook.xml.rels','<Relationships><Relationship Id="r1" Target="worksheets/sheet1.xml"/></Relationships>')
            z.writestr('xl/sharedStrings.xml',f'<sst xmlns="{ns}"><si><t>Nome</t></si><si><t>Ana</t></si></sst>')
            z.writestr('xl/worksheets/sheet1.xml',f'<worksheet xmlns="{ns}"><sheetData><row><c r="A1" t="s"><v>0</v></c><c r="B1" t="inlineStr"><is><t>Telefone</t></is></c></row><row><c r="A2" t="s"><v>1</v></c><c r="B2"><v>21900000001</v></c></row></sheetData></worksheet>')
        self.assertEqual(core.file_matrix(path),['Lista'])
        m=core.file_matrix(path,'Lista');self.assertEqual(m,[['Nome','Telefone'],['Ana','21900000001']])


class ChatOpeningTests(unittest.TestCase):
    def setUp(self):
        from unittest.mock import MagicMock
        import types
        self.tmp=tempfile.TemporaryDirectory()
        self.adapter=core.motor.WhatsApp.__new__(core.motor.WhatsApp)
        self.adapter.root=Path(self.tmp.name)
        self.adapter.sel={'composer':'editor','invalid_regex':'invalid'}
        self.page=MagicMock();self.adapter.page=self.page
        self.page.is_closed.return_value=False
        self.editor=MagicMock();self.editor.count.return_value=1
        self.editor.is_visible.return_value=True
        self.bad=MagicMock();self.bad.count.return_value=0
        self.page.locator.side_effect=lambda s: self.editor if s=='editor' else self.bad
        self.bad.get_by_text.return_value=self.bad
        self.adapter.session_signals=lambda: {}
        api=types.ModuleType('playwright.sync_api');api.TimeoutError=TimeoutError
        self.modules=patch.dict('sys.modules',{'playwright':types.ModuleType('playwright'),'playwright.sync_api':api})
        self.modules.start()
    def tearDown(self):
        self.modules.stop();self.tmp.cleanup()
    def open(self):
        with contextlib.redirect_stdout(io.StringIO()),patch.object(core.motor.time,'monotonic',side_effect=itertools.count(0,30)):
            self.adapter.open_chat('5521900000001')
    def test_navigation_timeout_retries_without_using_old_editor(self):
        self.page.goto.side_effect=[None,TimeoutError(),None,None]
        self.open()
        self.assertEqual(self.page.goto.call_count,4)
        self.assertEqual(self.editor.is_visible.call_count,2)
        urls=[c.args[0] for c in self.page.goto.call_args_list]
        self.assertEqual(urls[0], 'about:blank');self.assertEqual(urls[2],'about:blank')
        self.assertEqual(urls[1],urls[3])
    def test_slow_interface_retries_then_opens(self):
        self.editor.count.side_effect=[0,0,0,1,1]
        self.open()
        self.assertEqual(self.page.goto.call_count,4)
    def test_two_timeouts_fail_without_inspecting_editor(self):
        self.page.goto.side_effect=[None,TimeoutError(),None,TimeoutError()]
        with self.assertRaisesRegex(RuntimeError,'duas tentativas'):self.open()
        self.editor.is_visible.assert_not_called()
    def test_invalid_dialog_does_not_retry(self):
        self.bad.count.return_value=1;self.bad.nth.return_value.is_visible.return_value=True
        with self.assertRaises(ValueError):self.open()
        self.assertEqual(self.page.goto.call_count,2)
    def test_stop_prevents_navigation(self):
        (self.adapter.root/'PARAR').touch()
        with self.assertRaisesRegex(RuntimeError,'Parar'):self.open()
        self.page.goto.assert_not_called()
    def test_closed_browser_prevents_navigation(self):
        self.page.is_closed.return_value=True
        with self.assertRaisesRegex(RuntimeError,'fechado'):self.open()
        self.page.goto.assert_not_called()


class AITests(unittest.TestCase):
    def test_callback_rejects_wrong_state_and_changed_client(self):
        with self.assertRaises(ValueError):core.ai_callback_values('state=bad&code=x&client_id=c','good')
        with self.assertRaises(ValueError):core.ai_callback_values('state=s&code=x&client_id=other','s','saved')
        with self.assertRaises(ValueError):core.ai_callback_values('state=s&state=s&code=x&client_id=c','s')
        with self.assertRaises(ValueError):core.ai_callback_values('state=s&code=x&client_id=dynamic_agent_client','s')
    def test_callback_reauthorization_and_denial(self):
        self.assertEqual(core.ai_callback_values('state=s&code=x','s','saved'),('x','saved'))
        with self.assertRaisesRegex(RuntimeError,'não autorizou'):
            core.ai_callback_values('state=s&error=access_denied','s')
    def stream(self,events):
        return io.BytesIO(''.join('data: '+json.dumps(e)+'\n\n' for e in events).encode())
    def test_stream_requires_completed_and_discards_partial_failure(self):
        delta={'type':'response.output_text.delta','delta':'Olá'}
        self.assertEqual(core.ai_stream_text(self.stream([delta,{'type':'response.completed'}])),'Olá')
        with self.assertRaisesRegex(RuntimeError,'interrompida'):core.ai_stream_text(self.stream([delta]))
        with self.assertRaisesRegex(RuntimeError,'Limite'):
            core.ai_stream_text(self.stream([delta,{'type':'response.failed','response':{'error':{'code':'subscription_sharing_usage_limit_exceeded'}}}]))
    def test_no_api_key_fallback_and_supported_payload(self):
        with tempfile.TemporaryDirectory() as td:
            connection=core.ChatGPTConnection(td)
            connection.credentials={'access_token':'SECRET','expires':core.time.time()+1000}
            connection.models=[{'slug':'test-model'}]
            with patch.object(core,'ai_http',return_value=self.stream([{'type':'response.output_text.delta','delta':'ok'},{'type':'response.completed'}])) as http:
                self.assertEqual(connection.ask('test-model','instructions','prompt'),'ok')
            payload=http.call_args.kwargs['payload']
            self.assertFalse(payload['store']);self.assertTrue(payload['stream'])
            self.assertNotIn('tools',payload);self.assertNotIn('max_output_tokens',payload)
            self.assertEqual(http.call_args.args[0],'https://api.openai.com/v1/responses')
            connection.disconnect()
            with patch.object(core,'ai_http') as http, self.assertRaises(RuntimeError):connection.token()
            http.assert_not_called()
            self.assertNotIn('SECRET',connection.path.read_text())
    def test_diagnostic_excludes_private_content(self):
        import csv
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'historico.csv'
            with p.open('w',newline='',encoding='utf-8-sig') as f:
                w=csv.DictWriter(f,fieldnames=['campanha','nome','telefone','status','motivo','conteudo'],delimiter=';');w.writeheader()
                w.writerow({'campanha':'target','nome':'SECRET-NAME','telefone':'5521999999999','status':'FALHA','motivo':'Conversa não abriu SECRET-REASON','conteudo':'SECRET-TEXT'})
                w.writerow({'campanha':'other','status':'ENTREGUE'})
            result=core.ai_campaign_diagnostic('target',td)
            self.assertNotIn('SECRET',result);self.assertNotIn('5521999999999',result)
            d=json.loads(result);self.assertEqual(d['registros_da_campanha'],1)
            self.assertEqual(d['categorias_de_falha'],{'abertura_conversa':1})
    def test_identity_signature_nonce_audience_and_subject(self):
        import jwt
        from cryptography.hazmat.primitives.asymmetric import rsa
        from types import SimpleNamespace
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        claims={'iss':core.AI_AUTH,'aud':'client','sub':'user','nonce':'nonce','exp':core.time.time()+300}
        token=jwt.encode(claims,key,algorithm='RS256')
        with patch('jwt.PyJWKClient.get_signing_key_from_jwt',return_value=SimpleNamespace(key=key.public_key())):
            self.assertEqual(core.ai_validate_identity(token,'client','nonce')['sub'],'user')
            for client,nonce,subject in [('wrong','nonce',None),('client','wrong',None),('client','nonce','wrong')]:
                with self.assertRaises(RuntimeError):core.ai_validate_identity(token,client,nonce,subject)
            unsigned=jwt.encode(claims,key=None,algorithm='none')
            with self.assertRaises(RuntimeError):core.ai_validate_identity(unsigned,'client','nonce')
    def test_complete_login_with_loopback_and_no_saved_credentials(self):
        import threading
        import urllib.request
        import urllib.parse
        from types import SimpleNamespace
        import jwt
        from cryptography.hazmat.primitives.asymmetric import rsa
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        seen={};threads=[]
        def browser(url):
            query=urllib.parse.parse_qs(urllib.parse.urlsplit(url).query);seen.update(query)
            callback=query['redirect_uri'][0]+'?'+urllib.parse.urlencode({'state':query['state'][0],'code':'test-code','client_id':'test-client'})
            def hit():
                with urllib.request.urlopen(callback,timeout=5) as r:r.read()
            t=threading.Thread(target=hit);t.start();threads.append(t);return True
        def token_response(url,payload,form=False):
            self.assertTrue(form);self.assertEqual(payload['client_id'],'test-client')
            self.assertEqual(payload['redirect_uri'],seen['redirect_uri'][0])
            computed=core.base64.urlsafe_b64encode(core.hashlib.sha256(payload['code_verifier'].encode()).digest()).decode().rstrip('=')
            self.assertEqual(computed,seen['code_challenge'][0])
            claims={'iss':core.AI_AUTH,'aud':'test-client','sub':'user','nonce':seen['nonce'][0],'exp':core.time.time()+300}
            return {'id_token':jwt.encode(claims,key,algorithm='RS256'),'access_token':'SECRET-TOKEN','token_type':'Bearer','scope':core.AI_SCOPES,'expires_in':1000}
        with tempfile.TemporaryDirectory() as td:
            c=core.ChatGPTConnection(td);host=c.saved['host_id']
            with patch.object(core.webbrowser,'open',side_effect=browser),patch.object(core,'ai_http',side_effect=token_response),patch('jwt.PyJWKClient.get_signing_key_from_jwt',return_value=SimpleNamespace(key=key.public_key())):
                self.assertEqual(c.login(),'Conta 1')
            for t in threads:t.join(5)
            self.assertEqual(c.token(),'SECRET-TOKEN');self.assertNotIn('SECRET-TOKEN',c.path.read_text())
            self.assertEqual(core.ChatGPTConnection(td).saved['host_id'],host)
            self.assertNotIn('offline_access',seen['scope'][0])
            self.assertIsNone(core.ChatGPTConnection(td).credentials)


class GroupExportTests(unittest.TestCase):
    def test_full_phone_preserved_no_number_from_about(self):
        self.assertEqual(core.group_row({'lines':['+55 21 99999-0001','Recado: ligar para 21999990000']})['nome'],'Não identificado')
        self.assertEqual(core.group_row({'lines':['+55 21 99999-0001','~Ana']})['nome'],'Ana')
        self.assertEqual(core.group_row({'lines':['Ana','Recado: 5521999990001']})['telefone'],'')
        self.assertEqual(core.group_row({'lines':['Ana','21999990001']})['telefone'],'')
        self.assertEqual(core.group_row({'lines':['Ana','+1 (202) 555-0101']})['telefone'],'+12025550101')
    def test_conflicting_numbers_are_not_guessed(self):
        row=core.group_row({'lines':['Ana','+55 21 99999-0001','+55 21 99999-0002']})
        self.assertEqual(row['telefone'],'');self.assertIn('Mais de um',row['observacao'])
    def test_actions_not_exported(self):
        for text in ['Adicionar membros','Convidar via link','Ver todos','Você']:
            self.assertIsNone(core.group_row({'lines':[text]}))
    def test_duplicates_and_homonyms(self):
        acc=core.GroupRows()
        acc.add({'lines':['+55 21 99999-0001'],'position':0})
        acc.add({'lines':['Ana','+55 21 99999-0001'],'position':70})
        self.assertEqual(len(acc.rows),1);self.assertEqual(acc.rows[0]['nome'],'Ana')
        for pos in [140,140,210]:acc.add({'lines':['João'],'position':pos})
        self.assertEqual(len(acc.rows),3)
    def test_collect_virtual_pages_and_stable_bottom(self):
        class Page:
            def __init__(self):self.i=0
            def evaluate(self,script,advance):
                if advance:self.i=min(self.i+1,2);return {}
                return {'selected':True,'top':self.i*60,'max':120,'bottom':self.i==2,
                        'rows':[{'lines':['Pessoa '+str(self.i),'+55 21 99999-000'+str(self.i)],'position':self.i*60}]}
            def wait_for_timeout(self,n):pass
        counts=[];result=core.collect_group(Page(),lambda:False,counts.append)
        self.assertEqual(result['total_linhas'],3);self.assertEqual(result['sem_telefone'],0)
        self.assertIn('não confirma',result['observacao'])
        stopped=core.collect_group(Page(),lambda:True,lambda n:None)
        self.assertEqual(stopped['contatos'],[]);self.assertIn('interrompida',stopped['observacao'])
    def test_xlsx_literal_text_phone_and_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            result={'contatos':[{'nome':'=HYPERLINK("https://example.org")','telefone':'+5521999990001','observacao':'A & B < C'}],
                    'grupo':'Maximus','coletado_em':'2026-10-30','total_informado':2,'observacao':'Parcial'}
            path=Path(td)/'grupo.xlsx';core.save_group_xlsx(path,result)
            matrix=core.file_matrix(path,'Participantes')
            self.assertEqual(matrix[1],['=HYPERLINK("https://example.org")','+5521999990001','A & B < C'])
            with zipfile.ZipFile(path) as z:
                xml=z.read('xl/worksheets/sheet1.xml').decode()
                self.assertNotIn('<f>',xml);self.assertIn('inlineStr',xml)
                self.assertIn('autoFilter',xml)
            self.assertEqual(core.file_matrix(path),['Participantes','Sobre a coleta'])
    def test_worker_never_sends_or_changes_campaign_history(self):
        class Page:
            def is_closed(self):return False
            def evaluate(self,script,*args):return {'selected':True}
            def wait_for_timeout(self,n):pass
        class Adapter:
            page=Page();closed=False
            def close(self):self.closed=True
            def send(self,*args):raise AssertionError('Não pode enviar')
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);job=root/'job.json';job.write_text('{}')
            history=root/'historico.csv';history.write_text('original')
            core.atomic_json(job.with_suffix('.comando.json'),{'acao':'selecionar'})
            adapter=Adapter()
            with patch.object(core,'collect_group',return_value={'contatos':[]}):
                core.group_export_worker(job,{'grupo':'Teste'},root,lambda *_:adapter)
            self.assertTrue(adapter.closed);self.assertEqual(history.read_text(),'original')
            self.assertFalse((root/'historico.sqlite3').exists())


class AtomicJsonTests(unittest.TestCase):
    def test_transient_lock_keeps_old_json_until_success(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'estado.json'
            core.atomic_json(path,{'estado':'anterior'})
            replace=core.os.replace
            attempts=[]
            def blocked_then_replace(src,dst):
                self.assertEqual(json.loads(path.read_text()),{'estado':'anterior'})
                attempts.append(1)
                if len(attempts)<4:raise PermissionError(13,'Acesso negado')
                replace(src,dst)
            with patch.object(core.os,'replace',side_effect=blocked_then_replace),patch.object(core.time,'sleep'):
                core.atomic_json(path,{'estado':'novo'})
            self.assertEqual(len(attempts),4)
            self.assertEqual(json.loads(path.read_text()),{'estado':'novo'})
            self.assertEqual(list(Path(folder).glob('*.tmp')),[])

    def test_permanent_lock_preserves_data_and_reports_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'estado.json';core.atomic_json(path,{'original':True})
            with patch.object(core.os,'replace',side_effect=PermissionError(13,'bloqueado')) as replace,patch.object(core.time,'sleep'):
                with self.assertRaisesRegex(PermissionError,'continua bloqueado'):
                    core.atomic_json(path,{'original':False})
            self.assertEqual(replace.call_count,9)
            self.assertEqual(json.loads(path.read_text()),{'original':True})
            self.assertEqual(list(Path(folder).glob('*.tmp')),[])

    def test_other_io_errors_are_not_retried(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(core.os,'replace',side_effect=OSError(28,'disco cheio')) as replace,patch.object(core.time,'sleep') as sleep:
                with self.assertRaises(OSError):core.atomic_json(Path(folder)/'estado.json',{})
            self.assertEqual(replace.call_count,1);sleep.assert_not_called()

    def test_cleanup_failure_does_not_mask_original_error(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(core.os,'replace',side_effect=OSError(28,'disco cheio')),patch.object(Path,'unlink',side_effect=PermissionError('limpeza')):
                with self.assertRaisesRegex(OSError,'disco cheio'):
                    core.atomic_json(Path(folder)/'estado.json',{})


class GroupClickTests(unittest.TestCase):
    def run_dom(self, scenario):
        import shutil,subprocess
        if not shutil.which('node'):self.skipTest('Node e jsdom necessários para teste DOM')
        if subprocess.run(['node','-e',"require('jsdom')"],capture_output=True).returncode:
            self.skipTest('jsdom necessário para teste DOM')
        harness=r"""
const assert=require('assert');const {JSDOM}=require('jsdom');
const dom=new JSDOM('<body><div id="app"><div id="side"><div role="listitem" id="chat">Conversa</div></div><div id="main"></div></div></body>',{runScripts:'outside-only',pretendToBeVisual:true});
const w=dom.window,d=w.document;
w.HTMLElement.prototype.getBoundingClientRect=function(){let top=Number(this.dataset.top||0);return {width:500,height:this.getAttribute('role')==='listitem'?72:300,top,bottom:top+300};};
Object.defineProperty(w.HTMLElement.prototype,'innerText',{get(){return this.textContent;}});
function row(name,id='member'){return `<div role="listitem" data-testid="list-item-0" id="${id}" style="height:72px;transform:translateY(0px)"><div role="button" tabindex="-1"><div data-testid="cell-frame-container"><div data-testid="cell-frame-title"><span title="${name}">${name}</span></div><div data-testid="cell-frame-primary-detail"><div data-testid="group-admin-marker">Admin do grupo</div></div><div data-testid="cell-frame-secondary"><button>Adicionar etiqueta de membro</button></div></div></div></div>`;}
function setup(title='Dados do grupo',count='240 membros'){
 d.querySelector('#main').innerHTML=`<header><span>${title}</span></header><div id="scroll" style="overflow-y:auto"><span>${count}</span><div role="button" id="add">Adicionar membro</div><div role="list">${row('Você')}${row('Pessoa Teste','second')}</div></div>`;
 const scroll=d.querySelector('#scroll');Object.defineProperty(scroll,'clientHeight',{value:300});Object.defineProperty(scroll,'scrollHeight',{value:900});
 w.eval('('+SELECT+')()');return scroll;
}
function click(selector){const e=new w.MouseEvent('click',{bubbles:true,cancelable:true});d.querySelector(selector).dispatchEvent(e);return e.defaultPrevented;}
SCENARIO
"""
        script=harness.replace('SELECT',json.dumps(core.GROUP_SELECT_JS)).replace('SCENARIO',scenario.replace('READ_SCRIPT',json.dumps(core.GROUP_READ_JS)))
        proc=subprocess.run(['node','-e',script],capture_output=True,text=True)
        self.assertEqual(proc.returncode,0,proc.stderr)

    def test_group_inside_main_selected_and_read(self):
        self.run_dom(r"""
const scroll=setup();let opened=false;d.querySelector('#member').addEventListener('click',()=>opened=true);
assert.equal(click('#member span'),true);assert.equal(opened,false);assert.equal(w.__painelGrupo.selected,true);
const result=w.eval('('+READ_SCRIPT+')(false)');assert.equal(result.rows.length,2);assert.equal(result.rows[0].titles[0],'Você');
w.eval('('+READ_SCRIPT+')(true)');assert.ok(scroll.scrollTop>0);
d.querySelector('#main header').remove();assert.ok(w.eval('('+READ_SCRIPT+')(false)').error);
""")

    def test_navigation_actions_and_chat_list_not_selected(self):
        self.run_dom(r"""
setup();assert.equal(click('#main header span'),false);assert.equal(click('#add'),false);assert.equal(click('#member button'),false);
assert.equal(click('#chat'),false);assert.equal(w.__painelGrupo.selected,false);
""")

    def test_message_with_group_labels_is_not_selected(self):
        self.run_dom(r"""
setup();d.querySelector('#main').innerHTML='<div class="message-in" data-id="test"><span>Dados do grupo</span><span>240 membros</span>'+row('Mensagem')+'</div>';
assert.equal(click('#member span'),false);assert.equal(w.__painelGrupo.selected,false);
""")

    def test_contact_details_and_missing_count_rejected(self):
        self.run_dom(r"""
setup('Dados do contato');assert.equal(click('#member span'),false);assert.equal(w.__painelGrupo.selected,false);
setup('Dados do grupo','');assert.equal(click('#member span'),false);assert.equal(w.__painelGrupo.selected,false);
""")

    def test_group_outside_main_supported(self):
        self.run_dom(r"""
setup();d.querySelector('#main').id='group-panel';assert.equal(click('#second span'),true);assert.equal(w.__painelGrupo.selected,true);
""")

    def test_labeled_members_in_pane_side_without_group_header(self):
        self.run_dom(r"""
setup();d.querySelector('#main').innerHTML='<div id="pane-side"><div role="list"><div><div aria-label="Lista de membros: 240 membros">'+row('Você')+row('Pessoa Teste','second')+'</div></div></div></div>';
const pane=d.querySelector('#main #pane-side');pane.style.overflowY='auto';Object.defineProperty(pane,'clientHeight',{value:300});Object.defineProperty(pane,'scrollHeight',{value:720});
assert.equal(click('#second span'),true);assert.equal(w.__painelGrupo.selected,true);
assert.equal(w.__painelGrupo.root.getAttribute('aria-label'),'Lista de membros: 240 membros');
const result=w.eval('('+READ_SCRIPT+')(false)');assert.equal(result.rows.length,2);
assert.equal(result.rows[1].titles[0],'Pessoa Teste');
""")

    def test_unlabeled_pane_side_still_rejected(self):
        self.run_dom(r"""
setup();d.querySelector('#main').innerHTML='<div id="pane-side"><div role="list">'+row('Conversa')+'</div></div>';
assert.equal(click('#member span'),false);assert.equal(w.__painelGrupo.selected,false);
""")

    def test_self_label_not_exported_as_name(self):
        self.assertIsNone(core.group_row({'lines':['Você','Admin do grupo','Adicionar etiqueta de membro'],'titles':['Você']}))


if __name__=='__main__':unittest.main()
