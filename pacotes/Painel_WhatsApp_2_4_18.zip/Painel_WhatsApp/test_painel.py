"""Testes locais sem navegador e sem envios. Executar: python -m unittest test_painel -v"""
import contextlib
import io
import itertools
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import painel_core as core


class FakeTransport:
    def __init__(self): self.calls=[]; self.chats=[]; self.closed=False
    def open_chat(self,p): self.chats.append(p)
    def send(self,kind,value): self.calls.append((kind,value));return 'ENTREGUE','Transporte fictício de teste.'
    def close(self): self.closed=True


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.draft=core.new_draft();self.draft['mensagem']='Olá, {nome}!'
        self.draft['contatos']=[{'nome':f'Pessoa {i}','telefone':f'2190000000{i}'} for i in range(1,4)]
        image=self.root/'foto.jpg';image.write_bytes(b'fixture jpg')
        pdf=self.root/'material.pdf';pdf.write_bytes(b'%PDF-fixture')
        self.draft['anexos']=[str(image),str(pdf)]
    def tearDown(self):self.tmp.cleanup()
    def run_job(self,mode='enviar',transport=None,**kwargs):
        adapter=transport or FakeTransport()
        with contextlib.redirect_stdout(io.StringIO()),patch.object(core.motor.time,'monotonic',side_effect=itertools.count(0,2)):
            result=core.execute(self.draft,mode,self.root,transport_factory=lambda *_:adapter,**kwargs)
        return result,adapter
    def test_three_people_nine_items(self):
        result,adapter=self.run_job()
        self.assertEqual(len(adapter.calls),9);self.assertEqual(len(adapter.chats),3)
        self.assertEqual([v for k,v in adapter.calls if k=='texto'],['Olá, Pessoa 1!','Olá, Pessoa 2!','Olá, Pessoa 3!'])
        self.assertEqual(result['entregues_no_historico'],9);self.assertTrue(adapter.closed)
    def test_duplicate_run_does_not_send(self):
        self.run_job();result,adapter=self.run_job()
        self.assertEqual(adapter.calls,[]);self.assertEqual(result['ocorrencias_desta_execucao']['JA_PROCESSADO'],3)
    def test_simulation_does_not_open_transport(self):
        result,adapter=self.run_job('simular')
        self.assertEqual(result['simulados'],9);self.assertEqual(adapter.chats,[])
        result,adapter=self.run_job();self.assertEqual(len(adapter.calls),9)
    def test_duplicate_phone_blocks_entire_batch(self):
        self.draft['contatos'][2]['telefone']=self.draft['contatos'][0]['telefone']
        adapter=FakeTransport()
        with self.assertRaisesRegex(ValueError,'duplicado'):self.run_job(transport=adapter)
        self.assertEqual(adapter.calls,[])
    def test_missing_file_blocks_entire_batch(self):
        self.draft['anexos'].append(str(self.root/'ausente.pdf'))
        with self.assertRaisesRegex(ValueError,'não encontrado'):self.run_job()
    def test_missing_personalization_blocks(self):
        self.draft['mensagem']='Olá {nome}, turma {turma}'
        with self.assertRaisesRegex(ValueError,'não suportado'):self.run_job()
    def test_free_subject_without_personalization(self):
        self.draft['mensagem']='Convite para o culto de domingo.'
        result,adapter=self.run_job()
        self.assertEqual([v for k,v in adapter.calls if k=='texto'],[self.draft['mensagem']]*3)
    def test_legacy_contact_fields_do_not_change_message(self):
        self.run_job()
        for row in self.draft['contatos']:
            row.update(curso='Antigo',turma='A',codigo='123')
        result,adapter=self.run_job()
        self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['JA_PROCESSADO'],3)
    def test_unknown_placeholder_blocks(self):
        self.draft['mensagem']='Olá {nome.__class__}'
        with self.assertRaisesRegex(ValueError,'não suportado'):self.run_job()
    def test_changed_content_conflict(self):
        self.run_job();self.draft['mensagem']='Outro texto'
        result,adapter=self.run_job();self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['CONFLITO'],3)
    def test_uncertain_never_auto_retries(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):self.calls.append((k,v));raise RuntimeError('Sem confirmação')
        result,adapter=self.run_job(transport=Uncertain());self.assertEqual(result['incertos'],1)
        result,adapter=self.run_job();self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['BLOQUEADO'],1)
    def test_manual_received_continues_only_attachments(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):raise RuntimeError('Sem confirmação')
        self.run_job(transport=Uncertain());cfg,rows=core.prepare(self.draft)
        core.review_item(cfg['campanha'],rows[0]['telefone'],'00-texto','recebido',self.root)
        result,adapter=self.run_job();self.assertEqual([k for k,v in adapter.calls],['anexo','anexo'])
        self.assertEqual(result['entregues_no_historico'],3)
    def test_retry_unknown_result_refused(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):raise RuntimeError('Sem confirmação')
        self.run_job(transport=Uncertain());cfg,rows=core.prepare(self.draft)
        with self.assertRaises(ValueError):core.review_item(cfg['campanha'],rows[0]['telefone'],'00-texto','retomar',self.root)
    def test_stop_before_start_is_respected(self):
        (self.root/'PARAR').touch()
        result,adapter=self.run_job(reset_stop=False)
        self.assertEqual(adapter.calls,[]);self.assertTrue(result['parado']);self.assertEqual(result['pendentes'],9)
    def test_second_process_lock_denied(self):
        with core.execution_lock(self.root):
            with self.assertRaises(ValueError):
                with core.execution_lock(self.root):pass
    def test_copy_file_survives_source_removed(self):
        source=Path(self.draft['anexos'][0]);dest=core.stage_attachment(source,self.root)
        source.unlink();self.assertEqual(Path(dest).read_bytes(),b'fixture jpg')
    def test_header_mapping(self):
        m=core.parse_text('Telefone;Nome;Turma\n21900000001;Ana;A\n21900000002;Bia;B')
        header,mapping=core.suggested_mapping(m);rows=core.map_contacts(m,mapping,header)
        self.assertTrue(header);self.assertEqual(rows[0]['nome'],'Ana');self.assertEqual(set(rows[1]),{'nome','telefone'})
    def test_paste_without_header(self):
        m=core.parse_text('Ana\t21900000001\nBia\t21900000002')
        header,mapping=core.suggested_mapping(m);self.assertFalse(header)
        self.assertEqual(len(core.map_contacts(m,mapping,header)),2)
    def test_phone_normalization(self):
        self.assertEqual(core.normalize_phone('(21) 90000-0001'),'5521900000001')
        self.assertEqual(core.normalize_phone('5521900000001.0'),'5521900000001')
        self.assertEqual(core.normalize_phone('+12025550123'),'12025550123')
        with self.assertRaises(ValueError):core.normalize_phone('5.521E+12')
    def test_empty_list(self):
        self.draft['contatos']=[]
        with self.assertRaises(ValueError):core.prepare(self.draft)
    def test_new_campaign_has_unique_id(self):
        self.assertNotEqual(core.new_draft()['id'],core.new_draft()['id'])
    def test_atomic_json_roundtrip(self):
        path=self.root/'a.json';core.atomic_json(path,self.draft)
        self.assertEqual(json.loads(path.read_text()),self.draft)
    def test_xlsx_read_shared_and_inline(self):
        path=self.root/'list.xlsx';ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
        with zipfile.ZipFile(path,'w') as z:
            z.writestr('xl/workbook.xml',f'<workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Lista" r:id="r1"/></sheets></workbook>')
            z.writestr('xl/_rels/workbook.xml.rels','<Relationships><Relationship Id="r1" Target="worksheets/sheet1.xml"/></Relationships>')
            z.writestr('xl/sharedStrings.xml',f'<sst xmlns="{ns}"><si><t>Nome</t></si><si><t>Ana</t></si></sst>')
            z.writestr('xl/worksheets/sheet1.xml',f'<worksheet xmlns="{ns}"><sheetData><row><c r="A1" t="s"><v>0</v></c><c r="B1" t="inlineStr"><is><t>Telefone</t></is></c></row><row><c r="A2" t="s"><v>1</v></c><c r="B2"><v>21900000001</v></c></row></sheetData></worksheet>')
        self.assertEqual(core.file_matrix(path),['Lista'])
        m=core.file_matrix(path,'Lista');self.assertEqual(m,[['Nome','Telefone'],['Ana','21900000001']])


class ChatOpeningTests(unittest.TestCase):
    def setUp(self):
        from unittest.mock import MagicMock
        import types
        self.tmp=tempfile.TemporaryDirectory()
        self.adapter=core.motor.WhatsApp.__new__(core.motor.WhatsApp)
        self.adapter.root=Path(self.tmp.name)
        self.adapter.sel={'composer':'editor','invalid_regex':'invalid'}
        self.page=MagicMock();self.adapter.page=self.page
        self.page.is_closed.return_value=False
        self.editor=MagicMock();self.editor.count.return_value=1
        self.editor.is_visible.return_value=True
        self.bad=MagicMock();self.bad.count.return_value=0
        self.page.locator.side_effect=lambda s: self.editor if s=='editor' else self.bad
        self.bad.get_by_text.return_value=self.bad
        self.adapter.session_signals=lambda: {}
        api=types.ModuleType('playwright.sync_api');api.TimeoutError=TimeoutError
        self.modules=patch.dict('sys.modules',{'playwright':types.ModuleType('playwright'),'playwright.sync_api':api})
        self.modules.start()
    def tearDown(self):
        self.modules.stop();self.tmp.cleanup()
    def open(self):
        with contextlib.redirect_stdout(io.StringIO()),patch.object(core.motor.time,'monotonic',side_effect=itertools.count(0,30)):
            self.adapter.open_chat('5521900000001')
    def test_navigation_timeout_retries_without_using_old_editor(self):
        self.page.goto.side_effect=[None,TimeoutError(),None,None]
        self.open()
        self.assertEqual(self.page.goto.call_count,4)
        self.assertEqual(self.editor.is_visible.call_count,2)
        urls=[c.args[0] for c in self.page.goto.call_args_list]
        self.assertEqual(urls[0], 'about:blank');self.assertEqual(urls[2],'about:blank')
        self.assertEqual(urls[1],urls[3])
    def test_slow_interface_retries_then_opens(self):
        self.editor.count.side_effect=[0,0,0,1,1]
        self.open()
        self.assertEqual(self.page.goto.call_count,4)
    def test_two_timeouts_fail_without_inspecting_editor(self):
        self.page.goto.side_effect=[None,TimeoutError(),None,TimeoutError()]
        with self.assertRaisesRegex(RuntimeError,'duas tentativas'):self.open()
        self.editor.is_visible.assert_not_called()
    def test_invalid_dialog_does_not_retry(self):
        self.bad.count.return_value=1;self.bad.nth.return_value.is_visible.return_value=True
        with self.assertRaises(ValueError):self.open()
        self.assertEqual(self.page.goto.call_count,2)
    def test_stop_prevents_navigation(self):
        (self.adapter.root/'PARAR').touch()
        with self.assertRaisesRegex(RuntimeError,'Parar'):self.open()
        self.page.goto.assert_not_called()
    def test_closed_browser_prevents_navigation(self):
        self.page.is_closed.return_value=True
        with self.assertRaisesRegex(RuntimeError,'fechado'):self.open()
        self.page.goto.assert_not_called()


class AITests(unittest.TestCase):
    def test_callback_rejects_wrong_state_and_changed_client(self):
        with self.assertRaises(ValueError):core.ai_callback_values('state=bad&code=x&client_id=c','good')
        with self.assertRaises(ValueError):core.ai_callback_values('state=s&code=x&client_id=other','s','saved')
        with self.assertRaises(ValueError):core.ai_callback_values('state=s&state=s&code=x&client_id=c','s')
        with self.assertRaises(ValueError):core.ai_callback_values('state=s&code=x&client_id=dynamic_agent_client','s')
    def test_callback_reauthorization_and_denial(self):
        self.assertEqual(core.ai_callback_values('state=s&code=x','s','saved'),('x','saved'))
        with self.assertRaisesRegex(RuntimeError,'não autorizou'):
            core.ai_callback_values('state=s&error=access_denied','s')
    def stream(self,events):
        return io.BytesIO(''.join('data: '+json.dumps(e)+'\n\n' for e in events).encode())
    def test_stream_requires_completed_and_discards_partial_failure(self):
        delta={'type':'response.output_text.delta','delta':'Olá'}
        self.assertEqual(core.ai_stream_text(self.stream([delta,{'type':'response.completed'}])),'Olá')
        with self.assertRaisesRegex(RuntimeError,'interrompida'):core.ai_stream_text(self.stream([delta]))
        with self.assertRaisesRegex(RuntimeError,'Limite'):
            core.ai_stream_text(self.stream([delta,{'type':'response.failed','response':{'error':{'code':'subscription_sharing_usage_limit_exceeded'}}}]))
    def test_no_api_key_fallback_and_supported_payload(self):
        with tempfile.TemporaryDirectory() as td:
            connection=core.ChatGPTConnection(td)
            connection.credentials={'access_token':'SECRET','expires':core.time.time()+1000}
            connection.models=[{'slug':'test-model'}]
            with patch.object(core,'ai_http',return_value=self.stream([{'type':'response.output_text.delta','delta':'ok'},{'type':'response.completed'}])) as http:
                self.assertEqual(connection.ask('test-model','instructions','prompt'),'ok')
            payload=http.call_args.kwargs['payload']
            self.assertFalse(payload['store']);self.assertTrue(payload['stream'])
            self.assertNotIn('tools',payload);self.assertNotIn('max_output_tokens',payload)
            self.assertEqual(http.call_args.args[0],'https://api.openai.com/v1/responses')
            connection.disconnect()
            with patch.object(core,'ai_http') as http, self.assertRaises(RuntimeError):connection.token()
            http.assert_not_called()
            self.assertNotIn('SECRET',connection.path.read_text())
    def test_diagnostic_excludes_private_content(self):
        import csv
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'historico.csv'
            with p.open('w',newline='',encoding='utf-8-sig') as f:
                w=csv.DictWriter(f,fieldnames=['campanha','nome','telefone','status','motivo','conteudo'],delimiter=';');w.writeheader()
                w.writerow({'campanha':'target','nome':'SECRET-NAME','telefone':'5521999999999','status':'FALHA','motivo':'Conversa não abriu SECRET-REASON','conteudo':'SECRET-TEXT'})
                w.writerow({'campanha':'other','status':'ENTREGUE'})
            result=core.ai_campaign_diagnostic('target',td)
            self.assertNotIn('SECRET',result);self.assertNotIn('5521999999999',result)
            d=json.loads(result);self.assertEqual(d['registros_da_campanha'],1)
            self.assertEqual(d['categorias_de_falha'],{'abertura_conversa':1})
    def test_identity_signature_nonce_audience_and_subject(self):
        import jwt
        from cryptography.hazmat.primitives.asymmetric import rsa
        from types import SimpleNamespace
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        claims={'iss':core.AI_AUTH,'aud':'client','sub':'user','nonce':'nonce','exp':core.time.time()+300}
        token=jwt.encode(claims,key,algorithm='RS256')
        with patch('jwt.PyJWKClient.get_signing_key_from_jwt',return_value=SimpleNamespace(key=key.public_key())):
            self.assertEqual(core.ai_validate_identity(token,'client','nonce')['sub'],'user')
            for client,nonce,subject in [('wrong','nonce',None),('client','wrong',None),('client','nonce','wrong')]:
                with self.assertRaises(RuntimeError):core.ai_validate_identity(token,client,nonce,subject)
            unsigned=jwt.encode(claims,key=None,algorithm='none')
            with self.assertRaises(RuntimeError):core.ai_validate_identity(unsigned,'client','nonce')
    def test_complete_login_with_loopback_and_no_saved_credentials(self):
        import threading
        import urllib.request
        import urllib.parse
        from types import SimpleNamespace
        import jwt
        from cryptography.hazmat.primitives.asymmetric import rsa
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        seen={};threads=[]
        def browser(url):
            query=urllib.parse.parse_qs(urllib.parse.urlsplit(url).query);seen.update(query)
            callback=query['redirect_uri'][0]+'?'+urllib.parse.urlencode({'state':query['state'][0],'code':'test-code','client_id':'test-client'})
            def hit():
                with urllib.request.urlopen(callback,timeout=5) as r:r.read()
            t=threading.Thread(target=hit);t.start();threads.append(t);return True
        def token_response(url,payload,form=False):
            self.assertTrue(form);self.assertEqual(payload['client_id'],'test-client')
            self.assertEqual(payload['redirect_uri'],seen['redirect_uri'][0])
            computed=core.base64.urlsafe_b64encode(core.hashlib.sha256(payload['code_verifier'].encode()).digest()).decode().rstrip('=')
            self.assertEqual(computed,seen['code_challenge'][0])
            claims={'iss':core.AI_AUTH,'aud':'test-client','sub':'user','nonce':seen['nonce'][0],'exp':core.time.time()+300}
            return {'id_token':jwt.encode(claims,key,algorithm='RS256'),'access_token':'SECRET-TOKEN','token_type':'Bearer','scope':core.AI_SCOPES,'expires_in':1000}
        with tempfile.TemporaryDirectory() as td:
            c=core.ChatGPTConnection(td);host=c.saved['host_id']
            with patch.object(core.webbrowser,'open',side_effect=browser),patch.object(core,'ai_http',side_effect=token_response),patch('jwt.PyJWKClient.get_signing_key_from_jwt',return_value=SimpleNamespace(key=key.public_key())):
                self.assertEqual(c.login(),'Conta 1')
            for t in threads:t.join(5)
            self.assertEqual(c.token(),'SECRET-TOKEN');self.assertNotIn('SECRET-TOKEN',c.path.read_text())
            self.assertEqual(core.ChatGPTConnection(td).saved['host_id'],host)
            self.assertNotIn('offline_access',seen['scope'][0])
            self.assertIsNone(core.ChatGPTConnection(td).credentials)


class GroupExportTests(unittest.TestCase):
    def test_full_phone_preserved_no_number_from_about(self):
        self.assertEqual(core.group_row({'lines':['+55 21 99999-0001','Recado: ligar para 21999990000']})['nome'],'Não identificado')
        self.assertEqual(core.group_row({'lines':['+55 21 99999-0001','~Ana']})['nome'],'Ana')
        self.assertEqual(core.group_row({'lines':['Ana','Recado: 5521999990001']})['telefone'],'')
        self.assertEqual(core.group_row({'lines':['Ana','21999990001']})['telefone'],'')
        self.assertEqual(core.group_row({'lines':['Ana','+1 (202) 555-0101']})['telefone'],'+12025550101')
    def test_conflicting_numbers_are_not_guessed(self):
        row=core.group_row({'lines':['Ana','+55 21 99999-0001','+55 21 99999-0002']})
        self.assertEqual(row['telefone'],'');self.assertIn('Mais de um',row['observacao'])
    def test_actions_not_exported(self):
        for text in ['Adicionar membros','Convidar via link','Ver todos','Você']:
            self.assertIsNone(core.group_row({'lines':[text]}))
    def test_duplicates_and_homonyms(self):
        acc=core.GroupRows()
        acc.add({'lines':['+55 21 99999-0001'],'position':0})
        acc.add({'lines':['Ana','+55 21 99999-0001'],'position':70})
        self.assertEqual(len(acc.rows),1);self.assertEqual(acc.rows[0]['nome'],'Ana')
        for pos in [140,140,210]:acc.add({'lines':['João'],'position':pos})
        self.assertEqual(len(acc.rows),3)
    def test_row_identity_survives_scroll_geometry_changes(self):
        acc=core.GroupRows()
        for pos in [100,105,110]:
            acc.add({'key':'list-item-5','position':pos,'lines':['João']})
        acc.add({'key':'list-item-6','position':110,'lines':['João']})
        self.assertEqual(len(acc.rows),2)

    def test_structured_long_name_preserved(self):
        name='Nome comprido '+('Sobrenome '*20)
        row=core.group_row({'structured':True,'lines':[name],'titles':[name]})
        self.assertEqual(row['nome'],name.strip())

    def test_collect_virtual_pages_and_stable_bottom(self):
        class Page:
            def __init__(self):self.i=0
            def evaluate(self,script,advance):
                if advance:self.i=min(self.i+1,2);return {}
                return {'selected':True,'top':self.i*60,'max':120,'bottom':self.i==2,
                        'rows':[{'lines':['Pessoa '+str(self.i),'+55 21 99999-000'+str(self.i)],'position':self.i*60}]}
            def wait_for_timeout(self,n):pass
        counts=[];result=core.collect_group(Page(),lambda:False,counts.append)
        self.assertEqual(result['total_linhas'],3);self.assertEqual(result['sem_telefone'],0)
        self.assertIn('não confirma',result['observacao'])
        stopped=core.collect_group(Page(),lambda:True,lambda n:None)
        self.assertEqual(stopped['contatos'],[]);self.assertIn('interrompida',stopped['observacao'])
    def test_xlsx_literal_text_phone_and_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            result={'contatos':[{'nome':'=HYPERLINK("https://example.org")','telefone':'+5521999990001','observacao':'A & B < C'}],
                    'grupo':'Maximus','coletado_em':'2026-10-30','total_informado':2,'observacao':'Parcial'}
            path=Path(td)/'grupo.xlsx';core.save_group_xlsx(path,result)
            matrix=core.file_matrix(path,'Participantes')
            self.assertEqual(matrix[1],['=HYPERLINK("https://example.org")','+5521999990001','A & B < C'])
            with zipfile.ZipFile(path) as z:
                xml=z.read('xl/worksheets/sheet1.xml').decode()
                self.assertNotIn('<f>',xml);self.assertIn('inlineStr',xml)
                self.assertIn('autoFilter',xml)
            self.assertEqual(core.file_matrix(path),['Participantes','Sobre a coleta'])
    def test_worker_never_sends_or_changes_campaign_history(self):
        class Page:
            def is_closed(self):return False
            def evaluate(self,script,*args):return {'selected':True}
            def wait_for_timeout(self,n):pass
        class Adapter:
            page=Page();closed=False
            def close(self):self.closed=True
            def send(self,*args):raise AssertionError('Não pode enviar')
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);job=root/'job.json';job.write_text('{}')
            history=root/'historico.csv';history.write_text('original')
            core.atomic_json(job.with_suffix('.comando.json'),{'acao':'selecionar'})
            adapter=Adapter()
            with patch.object(core,'collect_group',return_value={'contatos':[]}):
                core.group_export_worker(job,{'grupo':'Teste'},root,lambda *_:adapter)
            self.assertTrue(adapter.closed);self.assertEqual(history.read_text(),'original')
            self.assertFalse((root/'historico.sqlite3').exists())


class AtomicJsonTests(unittest.TestCase):
    def test_transient_lock_keeps_old_json_until_success(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'estado.json'
            core.atomic_json(path,{'estado':'anterior'})
            replace=core.os.replace
            attempts=[]
            def blocked_then_replace(src,dst):
                self.assertEqual(json.loads(path.read_text()),{'estado':'anterior'})
                attempts.append(1)
                if len(attempts)<4:raise PermissionError(13,'Acesso negado')
                replace(src,dst)
            with patch.object(core.os,'replace',side_effect=blocked_then_replace),patch.object(core.time,'sleep'):
                core.atomic_json(path,{'estado':'novo'})
            self.assertEqual(len(attempts),4)
            self.assertEqual(json.loads(path.read_text()),{'estado':'novo'})
            self.assertEqual(list(Path(folder).glob('*.tmp')),[])

    def test_permanent_lock_preserves_data_and_reports_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'estado.json';core.atomic_json(path,{'original':True})
            with patch.object(core.os,'replace',side_effect=PermissionError(13,'bloqueado')) as replace,patch.object(core.time,'sleep'):
                with self.assertRaisesRegex(PermissionError,'continua bloqueado'):
                    core.atomic_json(path,{'original':False})
            self.assertEqual(replace.call_count,9)
            self.assertEqual(json.loads(path.read_text()),{'original':True})
            self.assertEqual(list(Path(folder).glob('*.tmp')),[])

    def test_other_io_errors_are_not_retried(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(core.os,'replace',side_effect=OSError(28,'disco cheio')) as replace,patch.object(core.time,'sleep') as sleep:
                with self.assertRaises(OSError):core.atomic_json(Path(folder)/'estado.json',{})
            self.assertEqual(replace.call_count,1);sleep.assert_not_called()

    def test_cleanup_failure_does_not_mask_original_error(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(core.os,'replace',side_effect=OSError(28,'disco cheio')),patch.object(Path,'unlink',side_effect=PermissionError('limpeza')):
                with self.assertRaisesRegex(OSError,'disco cheio'):
                    core.atomic_json(Path(folder)/'estado.json',{})


class GroupClickTests(unittest.TestCase):
    def run_dom(self, scenario):
        import shutil,subprocess
        if not shutil.which('node'):self.skipTest('Node e jsdom necessários para teste DOM')
        if subprocess.run(['node','-e',"require('jsdom')"],capture_output=True).returncode:
            self.skipTest('jsdom necessário para teste DOM')
        harness=r"""
const assert=require('assert');const {JSDOM}=require('jsdom');
const dom=new JSDOM('<body><div id="app"><div id="side"><div role="listitem" id="chat">Conversa</div></div><div id="main"></div></div></body>',{runScripts:'outside-only',pretendToBeVisual:true});
const w=dom.window,d=w.document;
w.HTMLElement.prototype.getBoundingClientRect=function(){let top=Number(this.dataset.top||0);return {width:500,height:this.getAttribute('role')==='listitem'?72:300,top,bottom:top+300};};
Object.defineProperty(w.HTMLElement.prototype,'innerText',{get(){return this.textContent;}});
function row(name,id='member'){return `<div role="listitem" data-testid="list-item-0" id="${id}" style="height:72px;transform:translateY(0px)"><div role="button" tabindex="-1"><div data-testid="cell-frame-container"><div data-testid="cell-frame-title"><span title="${name}">${name}</span></div><div data-testid="cell-frame-primary-detail"><div data-testid="group-admin-marker">Admin do grupo</div></div><div data-testid="cell-frame-secondary"><button>Adicionar etiqueta de membro</button></div></div></div></div>`;}
function setup(title='Dados do grupo',count='240 membros'){
 d.querySelector('#main').innerHTML=`<header><span>${title}</span></header><div id="scroll" style="overflow-y:auto"><span>${count}</span><div role="button" id="add">Adicionar membro</div><div role="list">${row('Você')}${row('Pessoa Teste','second')}</div></div>`;
 const scroll=d.querySelector('#scroll');Object.defineProperty(scroll,'clientHeight',{value:300});Object.defineProperty(scroll,'scrollHeight',{value:900});
 w.eval('('+SELECT+')()');return scroll;
}
function click(selector){const e=new w.MouseEvent('click',{bubbles:true,cancelable:true});d.querySelector(selector).dispatchEvent(e);return e.defaultPrevented;}
SCENARIO
"""
        script=harness.replace('SELECT',json.dumps(core.GROUP_SELECT_JS)).replace('SCENARIO',scenario.replace('READ_SCRIPT',json.dumps(core.GROUP_READ_JS)).replace('PROFILE_SCRIPT',json.dumps(core.GROUP_PROFILE_JS)))
        proc=subprocess.run(['node','-e',script],capture_output=True,text=True)
        self.assertEqual(proc.returncode,0,proc.stderr)


    def test_unsaved_member_tilde_matches_name_without_weakening_identity(self):
        self.run_dom(r"""
setup();click('#second span');
const title=d.querySelector('#second [title]');title.textContent='~Pessoa Teste';title.title='~Pessoa Teste';
const profile=w.eval('('+PROFILE_SCRIPT+')');
assert.ok(profile({op:'open',key:'list-item-0',name:'Other Person'}).error);
assert.ok(profile({op:'open',key:'different-key',name:'Pessoa Teste'}).error);
assert.ok(profile({op:'open',key:'list-item-0',name:'Pessoa Teste'}).opened);
const panel=d.createElement('section');panel.innerHTML='<div><span data-testid="contact-info-subtitle selectable-text">~Pessoa Teste</span><span data-testid="selectable-text">+55 21 90000-0000</span></div>';d.body.appendChild(panel);
assert.equal(profile({op:'read'}).phone,'+55 21 90000-0000');
assert.equal(profile({op:'read'}).name,'Pessoa Teste');
panel.querySelector('[data-testid~="contact-info-subtitle"]').textContent='Pessoa Teste';
assert.equal(profile({op:'read'}).phone,'+55 21 90000-0000');
panel.querySelector('[data-testid~="contact-info-subtitle"]').textContent='Pessoa Diferente';
assert.ok(profile({op:'read'}).error);
""")

    def test_unsaved_profile_phone_title_and_sibling_name(self):
        self.run_dom(r"""
setup();click('#second span');
const profile=w.eval('('+PROFILE_SCRIPT+')');
assert.ok(profile({op:'open',key:'list-item-0',name:'Pessoa Teste'}).opened);
const panel=d.createElement('section');
panel.innerHTML='<header><h2>Dados do contato</h2><button aria-label="Voltar">Voltar</button></header><div id="card"><span><div><div><span data-testid="contact-info-subtitle selectable-text">+55 21 90000-0000</span></div></div></span><div><span id="identity" data-testid="selectable-text"><span>~Pessoa Teste</span></span></div><div><div></div></div></div><section id="about"><span data-testid="selectable-text">~Pessoa Teste</span><span data-testid="selectable-text">+55 21 91111-1111</span></section>';
d.body.appendChild(panel);
assert.equal(profile({op:'read'}).phone,'+55 21 90000-0000');
assert.equal(profile({op:'read'}).name,'Pessoa Teste');
assert.equal(profile({op:'back'}).click,'back');
const label=panel.querySelector('#identity');
label.textContent='~Outra Pessoa';assert.ok(profile({op:'read'}).error);
label.textContent='~Pessoa Teste';
const duplicate=label.cloneNode(true);label.parentElement.appendChild(duplicate);
assert.ok(profile({op:'read'}).error);duplicate.remove();
label.remove();assert.ok(profile({op:'read'}).error);
""")

    def test_unsaved_member_phone_uses_trailing_cell_not_about_text(self):
        self.run_dom(r"""
setup();click('#second span');
const title=d.querySelector('#second [title]');title.textContent='~Pessoa Teste';title.title='~Pessoa Teste';
d.querySelector('#second [data-testid="cell-frame-secondary"]').innerHTML='<div id="about">+55 21 91111-1111</div><div role="gridcell" aria-colindex="1">+55 21 90000-0000</div>';
const read=w.eval('('+READ_SCRIPT+')');
let item=read(false).rows.find(r=>r.titles.includes('~Pessoa Teste'));
assert.ok(item.lines.includes('+55 21 90000-0000'));
assert.ok(!item.lines.includes('+55 21 91111-1111'));
d.querySelector('#second [aria-colindex="1"]').textContent='Recado com 123456789';
item=read(false).rows.find(r=>r.titles.includes('~Pessoa Teste'));
assert.ok(!item.lines.some(t=>t.includes('123456789')));
""")

    def test_business_profile_phone_identity_and_return(self):
        self.run_dom(r"""
const scroll=setup();click('#second span');scroll.scrollTop=180;
const action=w.eval('('+PROFILE_SCRIPT+')');
const profile=args=>{const result=action(args);if(result.click)d.querySelector('[data-painel-group-action="'+result.click+'"]').click();return result;};
d.querySelector('#second [role="button"]').onclick=()=>{
 const panel=d.createElement('div');panel.id='business';panel.dataset.testid='chat-info-drawer';
 panel.innerHTML='<header><h2>Dados do contato</h2><button aria-label="Voltar">Voltar</button></header><section><div id="names"><div data-testid="business-top-card-name-title"><div><span data-testid="selectable-text">Empresa Teste</span></div></div><div><span id="saved-name" data-testid="selectable-text">Pessoa Teste</span></div></div><div id="catalog"><span data-testid="selectable-text">+55 21 91111-1111</span></div><div id="phone-block"><div data-testid="section-about-and-phone-number">Recado e número de telefone</div><div><span data-testid="selectable-text">+55 21 90000-0000</span></div></div></section>';
 d.body.appendChild(panel);panel.querySelector('button').onclick=()=>panel.remove();
};
assert.ok(profile({op:'open',key:'list-item-0',name:'Pessoa Teste'}).opened);
assert.equal(profile({op:'read'}).phone,'+55 21 90000-0000');
assert.equal(profile({op:'read'}).name,'Pessoa Teste');
d.querySelector('#saved-name').textContent='Outro Contato';
assert.ok(profile({op:'read'}).error);
d.querySelector('#saved-name').textContent='Pessoa Teste';
d.querySelector('#phone-block').insertAdjacentHTML('beforeend','<span data-testid="selectable-text">+55 21 92222-2222</span>');
assert.ok(profile({op:'read'}).error);
d.querySelector('#phone-block').remove();
assert.ok(profile({op:'read'}).contact);
assert.ok(profile({op:'back'}).back);
assert.ok(profile({op:'restore'}).restored);
assert.equal(scroll.scrollTop,180);
""")

    def test_profile_name_phone_back_and_restore(self):
        self.run_dom(r"""
const scroll=setup();click('#second span');scroll.scrollTop=180;
const action=w.eval('('+PROFILE_SCRIPT+')');const profile=args=>{const result=action(args);if(result.click)d.querySelector('[data-painel-group-action="'+result.click+'"]').click();return result;};
const person=d.querySelector('#second [role="button"]');
person.onclick=()=>{
 const panel=d.createElement('section');panel.id='profile';
 panel.innerHTML='<header><span>Dados do contato</span><button aria-label="Voltar">Voltar</button></header><div><span><div><div><span data-testid="contact-info-subtitle selectable-text">Pessoa Teste</span></div></div></span><div><span data-testid="selectable-text"><span>+55 21 90000-0000</span></span></div></div><div data-testid="selectable-text">+55 21 91111-1111</div><button id="call">Ligar</button>';
 d.body.appendChild(panel);panel.querySelector('[aria-label="Voltar"]').onclick=()=>panel.remove();
 panel.querySelector('#call').onclick=()=>{throw Error('Cannot call')};
};
assert.ok(profile({op:'open',key:'list-item-0',name:'Pessoa Teste'}).opened);
assert.equal(profile({op:'read'}).phone,'+55 21 90000-0000');
assert.ok(profile({op:'back'}).back);assert.ok(profile({op:'restore'}).restored);
assert.equal(scroll.scrollTop,180);
assert.ok(profile({op:'open',key:'list-item-0',name:'Wrong'}).error);
""")


    def test_participant_menu_opens_only_contact_details_then_reads_phone(self):
        self.run_dom(r"""
const scroll=setup();click('#second span');scroll.scrollTop=180;
const action=w.eval('('+PROFILE_SCRIPT+')');let chosen=[];
function profile(args){const r=action(args);if(r.click)d.querySelector('[data-painel-group-action="'+r.click+'"]').click();return r;}
d.querySelector('#second [role="button"]').onclick=()=>{
 const m=d.createElement('div');m.id='context';m.setAttribute('role','menu');
 m.innerHTML=['Promover a admin do grupo','Remover','Dados do contato','Código de segurança','Conversar com Pessoa Teste'].map(t=>'<div role="menuitem"><span>'+t+'</span></div>').join('');d.body.appendChild(m);
 for(const item of m.children)item.onclick=()=>{
   chosen.push(item.textContent);assert.equal(item.textContent,'Dados do contato');m.remove();
   const p=d.createElement('section');p.id='profile';p.innerHTML='<header><span>Dados do contato</span><button aria-label="Voltar">Voltar</button></header><div><span data-testid="contact-info-subtitle selectable-text">Pessoa Teste</span><div><span data-testid="selectable-text">+55 21 90000-0000</span></div></div>';d.body.appendChild(p);
   p.querySelector('button').onclick=()=>p.remove();
 };
};
profile({op:'open',key:'list-item-0',name:'Pessoa Teste'});
assert.equal(profile({op:'read'}).click,'details');
assert.equal(profile({op:'read'}).phone,'+55 21 90000-0000');
profile({op:'back'});assert.ok(profile({op:'restore'}).restored);
assert.deepEqual(chosen,['Dados do contato']);assert.equal(scroll.scrollTop,180);
""")

    def test_details_label_outside_menu_not_clicked(self):
        self.run_dom(r"""
setup();click('#second span');const profile=w.eval('('+PROFILE_SCRIPT+')');
profile({op:'open',key:'list-item-0',name:'Pessoa Teste'});
d.body.insertAdjacentHTML('beforeend','<div><span>Dados do contato</span></div>');
assert.equal(profile({op:'read'}).click,undefined);
""")

    def test_details_menu_requested_once(self):
        self.run_dom(r"""
setup();click('#second span');const profile=w.eval('('+PROFILE_SCRIPT+')');
profile({op:'open',key:'list-item-0',name:'Pessoa Teste'});
d.body.insertAdjacentHTML('beforeend','<div role="menu"><div role="menuitem"><span>Dados do contato</span></div><div>Código de segurança</div><div>Conversar com Pessoa Teste</div></div>');
assert.equal(profile({op:'read'}).click,'details');assert.equal(profile({op:'read'}).click,undefined);
""")

    def test_profile_mismatch_and_ambiguous_phone_rejected(self):
        self.run_dom(r"""
setup();click('#second span');const action=w.eval('('+PROFILE_SCRIPT+')');const profile=args=>{const result=action(args);if(result.click)d.querySelector('[data-painel-group-action="'+result.click+'"]').click();return result;};
d.querySelector('#second [role="button"]').onclick=()=>{
 const div=d.createElement('section');div.id='profile';div.innerHTML='<div><span data-testid="contact-info-subtitle selectable-text">Other Person</span><span data-testid="selectable-text">+55 21 90000-0000</span></div>';d.body.appendChild(div);
};
profile({op:'open',key:'list-item-0',name:'Pessoa Teste'});
assert.ok(profile({op:'read'}).error);
d.querySelector('[data-testid~="contact-info-subtitle"]').textContent='Pessoa Teste';
d.querySelector('#profile div').insertAdjacentHTML('beforeend','<span data-testid="selectable-text">+55 21 92222-2222</span>');
assert.ok(profile({op:'read'}).error);assert.ok(profile({op:'back'}).error);
""")

    def test_profile_restores_recreated_full_modal(self):
        self.run_dom(r"""
function modal(){
 const p=d.createElement('section');p.setAttribute('role','dialog');p.setAttribute('aria-label','Pesquisar membros');
 p.innerHTML='<input value=""><div id="ms" style="overflow-y:auto">'+row('Pessoa Teste','person')+'</div>';d.body.appendChild(p);
 const sc=p.querySelector('#ms');Object.defineProperty(sc,'clientHeight',{value:300});Object.defineProperty(sc,'scrollHeight',{value:900});return p;
}
const first=modal();w.eval('('+JSON_SELECT+')()');click('#person span');w.__painelGrupo.scroll.scrollTop=210;
const action=w.eval('('+PROFILE_SCRIPT+')');const profile=args=>{const result=action(args);if(result.click)d.querySelector('[data-painel-group-action="'+result.click+'"]').click();return result;};
d.querySelector('#person [role="button"]').onclick=()=>first.remove();
assert.ok(profile({op:'open',key:'list-item-0',name:'Pessoa Teste'}).opened);
modal();assert.ok(profile({op:'restore'}).pending);assert.ok(profile({op:'restore'}).pending);assert.ok(profile({op:'restore'}).restored);assert.equal(w.__painelGrupo.scroll.scrollTop,210);
assert.ok(w.eval('('+READ_SCRIPT+')(false)').selected);
""".replace('JSON_SELECT',json.dumps(core.GROUP_SELECT_JS)))

    def test_restore_uses_fresh_participant_section_and_preserves_position(self):
        self.run_dom(r"""
function modal(){
 const p=d.createElement('section');p.setAttribute('role','dialog');p.setAttribute('aria-label','Pesquisar membros');
 p.innerHTML='<input value=""><div style="overflow-y:auto">'+row('Pessoa Teste','person')+'</div>';d.body.appendChild(p);
 const sc=p.querySelector('div');Object.defineProperty(sc,'clientHeight',{value:300});Object.defineProperty(sc,'scrollHeight',{value:1500});return p;
}
function drawer(){
 const p=d.createElement('section');p.dataset.testid='chat-info-drawer';
 p.innerHTML='<button id="search">Pesquisar</button><div data-testid="group-info-participants-entrance"><div role="button" id="expand">Ver tudo (mais 230)</div></div>';
 d.body.appendChild(p);p.querySelector('#search').onclick=()=>assert.fail('Message search must never be clicked');return p;
}
const original=drawer(),first=modal();w.eval('('+JSON_SELECT+')()');click('#person span');w.__painelGrupo.scroll.scrollTop=720;
const action=w.eval('('+PROFILE_SCRIPT+')');
const profile=args=>{const result=action(args);if(result.click)d.querySelector('[data-painel-group-action="'+result.click+'"]').click();return result;};
d.querySelector('#person [role="button"]').onclick=()=>{first.remove();original.remove();};
assert.ok(profile({op:'open',key:'list-item-0',name:'Pessoa Teste'}).opened);
const fresh=drawer();let clicks=0;fresh.querySelector('#expand').onclick=()=>{clicks++;modal();};
assert.equal(profile({op:'restore'}).click,'expand');assert.equal(clicks,1);
assert.ok(profile({op:'restore'}).pending);assert.ok(profile({op:'restore'}).pending);assert.ok(profile({op:'restore'}).restored);assert.equal(w.__painelGrupo.scroll.scrollTop,720);
assert.ok(w.eval('('+READ_SCRIPT+')(false)').selected);
""".replace('JSON_SELECT',json.dumps(core.GROUP_SELECT_JS)))

    def test_restore_waits_for_virtual_rows_and_recovers_scroll_reset(self):
        self.run_dom(r"""
const p=d.createElement('section');p.setAttribute('role','dialog');p.setAttribute('aria-label','Pesquisar membros');
p.innerHTML='<input><div id="ms" style="overflow-y:auto">'+row('Pessoa Teste','person')+'</div>';d.body.appendChild(p);
const sc=p.querySelector('#ms');Object.defineProperty(sc,'clientHeight',{value:300});Object.defineProperty(sc,'scrollHeight',{value:1800});
w.eval('('+JSON_SELECT+')()');click('#person span');sc.scrollTop=720;
const profile=w.eval('('+PROFILE_SCRIPT+')');
assert.ok(profile({op:'open',key:'list-item-0',name:'Pessoa Teste'}).opened);
sc.scrollTop=0;const title=p.querySelector('[title]');title.title='Outro Participante';title.textContent='Outro Participante';
assert.ok(profile({op:'restore'}).pending);assert.equal(sc.scrollTop,720);
assert.ok(profile({op:'restore'}).pending);assert.ok(w.__painelGrupo.profileLookup);
title.title='Pessoa Teste';title.textContent='Pessoa Teste';
assert.ok(profile({op:'restore'}).pending);
sc.scrollTop=0;assert.ok(profile({op:'restore'}).pending);assert.equal(sc.scrollTop,720);
assert.ok(profile({op:'restore'}).pending);assert.ok(profile({op:'restore'}).restored);
assert.ok(!w.__painelGrupo.profileLookup);
""".replace('JSON_SELECT',json.dumps(core.GROUP_SELECT_JS)))

    def test_restore_does_not_use_unrelated_expand_or_search(self):
        self.run_dom(r"""
setup();click('#second span');
w.__painelGrupo.profileLookup={name:'Pessoa Teste',top:0,modal:true};
d.querySelector('#main').innerHTML='<button>Pesquisar</button><button>Ver tudo (mais 230)</button>';
const action=w.eval('('+PROFILE_SCRIPT+')');
assert.ok(action({op:'restore'}).pending);
assert.equal(d.querySelectorAll('[data-painel-group-action]').length,0);
""")

    def test_group_inside_main_selected_and_read(self):
        self.run_dom(r"""
const scroll=setup();let opened=false;d.querySelector('#member').addEventListener('click',()=>opened=true);
assert.equal(click('#member span'),true);assert.equal(opened,false);assert.equal(w.__painelGrupo.selected,true);
const result=w.eval('('+READ_SCRIPT+')(false)');assert.equal(result.rows.length,2);assert.equal(result.rows[0].titles[0],'Você');
w.eval('('+READ_SCRIPT+')(true)');assert.ok(scroll.scrollTop>0);
d.querySelector('#main header').remove();assert.ok(w.eval('('+READ_SCRIPT+')(false)').error);
""")

    def test_navigation_actions_and_chat_list_not_selected(self):
        self.run_dom(r"""
setup();assert.equal(click('#main header span'),false);assert.equal(click('#add'),false);assert.equal(click('#member button'),false);
assert.equal(click('#chat'),false);assert.equal(w.__painelGrupo.selected,false);
""")

    def test_message_with_group_labels_is_not_selected(self):
        self.run_dom(r"""
setup();d.querySelector('#main').innerHTML='<div class="message-in" data-id="test"><span>Dados do grupo</span><span>240 membros</span>'+row('Mensagem')+'</div>';
assert.equal(click('#member span'),false);assert.equal(w.__painelGrupo.selected,false);
""")

    def test_contact_details_and_missing_count_rejected(self):
        self.run_dom(r"""
setup('Dados do contato');assert.equal(click('#member span'),false);assert.equal(w.__painelGrupo.selected,false);
setup('Dados do grupo','');assert.equal(click('#member span'),false);assert.equal(w.__painelGrupo.selected,false);
""")

    def test_group_outside_main_supported(self):
        self.run_dom(r"""
setup();d.querySelector('#main').id='group-panel';assert.equal(click('#second span'),true);assert.equal(w.__painelGrupo.selected,true);
""")

    def test_labeled_members_in_pane_side_without_group_header(self):
        self.run_dom(r"""
setup();d.querySelector('#main').innerHTML='<div id="pane-side"><div role="list"><div><div aria-label="Lista de membros: 240 membros">'+row('Você')+row('Pessoa Teste','second')+'</div></div></div></div>';
const pane=d.querySelector('#main #pane-side');pane.style.overflowY='auto';Object.defineProperty(pane,'clientHeight',{value:300});Object.defineProperty(pane,'scrollHeight',{value:720});
assert.equal(click('#second span'),true);assert.equal(w.__painelGrupo.selected,true);
assert.equal(w.__painelGrupo.root.getAttribute('aria-label'),'Lista de membros: 240 membros');
const result=w.eval('('+READ_SCRIPT+')(false)');assert.equal(result.rows.length,2);
assert.equal(result.rows[1].titles[0],'Pessoa Teste');
""")

    def test_unlabeled_pane_side_still_rejected(self):
        self.run_dom(r"""
setup();d.querySelector('#main').innerHTML='<div id="pane-side"><div role="list">'+row('Conversa')+'</div></div>';
assert.equal(click('#member span'),false);assert.equal(w.__painelGrupo.selected,false);
""")

    def test_virtual_members_scroll_above_non_scrolling_pane(self):
        self.run_dom(r"""
setup();d.querySelector('#main').innerHTML='<div data-testid="drawer-right"><div id="outer" style="overflow-y:auto"><div data-testid="chat-info-drawer"><div id="pane-side" style="overflow-y:auto"><div role="list"><div aria-label="Lista de membros: 240 membros" id="members"></div></div></div></div></div></div>';
const outer=d.querySelector('#outer'),pane=d.querySelector('#pane-side'),members=d.querySelector('#members');
Object.defineProperty(outer,'clientHeight',{value:360});Object.defineProperty(outer,'scrollHeight',{value:240*72});
Object.defineProperty(pane,'clientHeight',{value:360});Object.defineProperty(pane,'scrollHeight',{value:360});
let position=0;
function render(){const start=Math.floor(position/72);members.innerHTML=Array.from({length:Math.min(6,240-start)},(_,j)=>row('Pessoa '+(start+j),'p'+(start+j))).join('');
 for(const n of members.children){const index=Number(n.id.slice(1));n.getBoundingClientRect=()=>({width:500,height:72,top:index*72-position,bottom:index*72-position+72});}}
Object.defineProperty(outer,'scrollTop',{get:()=>position,set:v=>{position=Math.max(0,Math.min(240*72-360,v));render();}});render();
assert.equal(click('#p0 span'),true);assert.equal(w.__painelGrupo.scroll,outer);
const found=new Set();let frame;
for(let i=0;i<150;i++){frame=w.eval('('+READ_SCRIPT+')(false)');for(const r of frame.rows)found.add(r.titles[0]);if(frame.bottom)break;w.eval('('+READ_SCRIPT+')(true)');}
assert.equal(frame.expected,240);assert.equal(frame.bottom,true);assert.equal(found.size,240);
""")

    def test_stalled_scroll_returns_partial_without_losing_rows(self):
        class Page:
            def evaluate(self, script, advance):
                return {'selected':True,'top':0,'max':10000,'bottom':False,'expected':240,
                        'rows':[{'titles':['Pessoa Teste'],'lines':['Pessoa Teste'],'position':0}]}
            def wait_for_timeout(self, timeout):pass
        result=core.collect_group(Page(),lambda:False,lambda n:None)
        self.assertEqual(result['total_linhas'],1)
        self.assertIn('não avançou',result['observacao'])

    def test_false_bottom_reports_missing_members(self):
        class Page:
            def evaluate(self, script, advance):
                return {'selected':True,'top':0,'max':0,'bottom':True,'expected':240,
                        'rows':[{'titles':['Pessoa Teste'],'lines':['Pessoa Teste'],'position':0}]}
            def wait_for_timeout(self, timeout):pass
        result=core.collect_group(Page(),lambda:False,lambda n:None)
        self.assertIn('1 de 240',result['observacao'])
        self.assertIn('Leitura parcial',result['observacao'])

    def test_members_dialog_without_count_and_without_list_role(self):
        self.run_dom(r"""
setup();const main=d.querySelector('#main');main.innerHTML='<div role="dialog" aria-label="Pesquisar membros"><header>Pesquisar membros</header><input value=""><div id="viewport" style="overflow-y:auto"><div><div id="virtual" style="height:19368px"></div></div></div></div>';
const viewport=d.querySelector('#viewport'),list=d.querySelector('#virtual');
Object.defineProperty(viewport,'clientHeight',{value:360});Object.defineProperty(viewport,'scrollHeight',{value:269*72});
let top=0;
function render(){const start=Math.floor(top/72);list.innerHTML=Array.from({length:Math.min(7,269-start)},(_,j)=>{const n=start+j;return n%10===0?'<div role="listitem" data-testid="section-header">A</div>':row('Pessoa '+n,'p'+n);}).join('');
 for(const n of list.children){const index=n.id?Number(n.id.slice(1)):0;n.getBoundingClientRect=()=>({width:500,height:72,top:index*72-top,bottom:index*72-top+72});}}
Object.defineProperty(viewport,'scrollTop',{get:()=>top,set:v=>{top=Math.max(0,Math.min(269*72-360,v));render();}});render();
assert.equal(click('#p1 span'),true);assert.equal(w.__painelGrupo.scroll,viewport);
const names=new Set();let r;
for(let i=0;i<150;i++){r=w.eval('('+READ_SCRIPT+')(false)');for(const item of r.rows)names.add(item.titles[0]);if(r.bottom)break;w.eval('('+READ_SCRIPT+')(true)');}
assert.equal(names.size,242);assert.equal(r.bottom,true);assert.ok(!names.has('A'));
d.querySelector('input').value='teste';assert.ok(w.eval('('+READ_SCRIPT+')(false)').error);
""")

    def test_generic_contacts_dialog_not_accepted(self):
        self.run_dom(r"""
setup();d.querySelector('#main').innerHTML='<div role="dialog" aria-label="Contatos"><header>Contatos</header>'+row('Pessoa Teste')+'</div>';
assert.equal(click('#member span'),false);assert.equal(w.__painelGrupo.selected,false);
""")

    def test_member_title_excludes_status_and_preserves_initial_name(self):
        self.run_dom(r"""
setup();const second=d.querySelector('#second');second.querySelector('[data-testid="cell-frame-title"]').innerHTML='<span title="B">B</span>';
second.querySelector('[data-testid="cell-frame-secondary"]').innerHTML='<span title="Outro nome">Recado +55 21 99999-0001</span>';
assert.equal(click('#second span'),true);
const result=w.eval('('+READ_SCRIPT+')(false)');const item=result.rows.find(x=>x.titles[0]==='B');
assert.ok(item);assert.deepEqual(Array.from(item.titles),['B']);assert.ok(!item.lines.join(' ').includes('99999'));
""")

    def test_self_label_not_exported_as_name(self):
        self.assertIsNone(core.group_row({'lines':['Você','Admin do grupo','Adicionar etiqueta de membro'],'titles':['Você']}))




class GroupProfileFlowTests(unittest.TestCase):
    raw={'key':'list-item-4','structured':True,'titles':['Pessoa Teste'],'lines':['Pessoa Teste'],'position':72}
    class Page:
        def __init__(self,responses):self.responses=iter(responses);self.ops=[]
        def evaluate(self,script,args):self.ops.append(args['op']);return next(self.responses)
        def wait_for_timeout(self,ms):pass
    def test_number_added_only_after_successful_return(self):
        page=self.Page([{'opened':True},{'name':'Pessoa Teste','phone':'+55 21 90000-0000'},{'back':True},{'restored':True}])
        result=core.read_group_phone(page,self.raw,lambda:False)
        self.assertEqual(core.group_row(result)['telefone'],'+5521900000000')
        self.assertEqual(page.ops,['open','read','back','restore'])
        self.assertEqual(self.raw['lines'],['Pessoa Teste'])
    def test_profile_name_spacing_preserves_verified_number_and_original_name(self):
        for name in ['Pessoa  Teste','Pessoa\u00a0\u00a0Teste','Pessoa\tTeste']:
            with self.subTest(name=name):
                raw={**self.raw,'lines':[name],'titles':[name]}
                page=self.Page([{'opened':True},{'name':'Pessoa Teste','phone':'+55 21 90000-0000'},{'back':True},{'restored':True}])
                metrics={};result=core.read_group_phone(page,raw,lambda:False,metrics)
                self.assertEqual(core.group_row(result)['telefone'],'+5521900000000')
                self.assertEqual(core.group_row(result)['nome'],name)
                self.assertEqual(set(metrics),{'segundos_open','segundos_read','segundos_back','segundos_restore'})
        self.assertNotEqual(core.group_member_name('Pessoa Teste'),core.group_member_name('Pessoa Outra'))
        self.assertNotEqual(core.group_member_name('José'),core.group_member_name('Jose'))

    def test_direct_numbers_do_not_trigger_profile_or_repeated_batch_reads(self):
        class Page:
            reads=0
            def evaluate(self,script,advance):
                if not advance:self.reads+=1
                return {'selected':True,'top':0,'max':0,'bottom':True,'rows':[
                    {'key':str(i),'titles':['Pessoa '+str(i)],'lines':['Pessoa '+str(i),'+55 21 90000-00'+str(i).zfill(2)]} for i in range(20)]}
            def wait_for_timeout(self,ms):pass
        page=Page();metrics={}
        with patch.object(core,'read_group_phone',side_effect=AssertionError('No profile needed')):
            result=core.collect_group(page,lambda:False,lambda n:None,lookup_phones=True,metrics=metrics)
        self.assertEqual(result['total_linhas'],20)
        self.assertEqual(page.reads,4)
        self.assertEqual(metrics['consultas_perfil'],0)
        self.assertIn('segundos_total',result['desempenho'])
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'result.xlsx';core.save_group_xlsx(path,result)
            info=core.file_matrix(path,'Sobre a coleta')
            self.assertTrue(any(r[0]=='Duração da coleta (segundos)' for r in info))
    def test_collect_refreshes_virtual_rows_after_every_profile(self):
        def raw(name,key):
            return {'key':key,'structured':True,'titles':[name],'lines':[name],'position':72}
        first=raw('Pessoa A','list-item-1')
        stale=raw('Pessoa B','list-item-2')
        current=raw('Pessoa B','list-item-3')
        class Page:
            generation=0
            def evaluate(self,script,advance):
                rows=[first,stale] if self.generation==0 else [first,current]
                return {'selected':True,'rows':rows,'top':0,'max':0,'bottom':True}
            def wait_for_timeout(self,ms):pass
        page=Page();opened=[]
        def read(page,row,cancelled):
            if row['titles']==['Pessoa B']:
                self.assertEqual(row['key'],'list-item-3','must not use stale virtual row')
            opened.append(row['titles'][0]);page.generation+=1
            phone='+55 21 90000-000'+str(len(opened))
            return {**row,'lines':[row['titles'][0],phone]}
        with patch.object(core,'read_group_phone',side_effect=read):
            result=core.collect_group(page,lambda:False,lambda n:None,lookup_phones=True)
        self.assertEqual(opened,['Pessoa A','Pessoa B'])
        self.assertEqual(result['total_linhas'],2)
        self.assertEqual(result['sem_telefone'],0)

    def test_recognized_contact_without_phone_returns_without_aborting(self):
        page=self.Page([{'opened':True}]+[{'pending':True,'contact':True}]*32+[{'back':True},{'restored':True}])
        result=core.read_group_phone(page,self.raw,lambda:False)
        self.assertEqual(result,self.raw)
        self.assertEqual(page.ops[-2:],['back','restore'])
        self.assertEqual(core.group_row(result)['telefone'],'')
    def test_return_failure_preserves_verified_number(self):
        page=self.Page([{'opened':True},{'name':'Pessoa Teste','phone':'+55 21 90000-0000'},{'error':'Voltar ausente'}])
        with self.assertRaisesRegex(core.GroupReturnError,'Voltar ausente') as caught:
            core.read_group_phone(page,self.raw,lambda:False)
        self.assertEqual(core.group_row(caught.exception.row)['telefone'],'+5521900000000')
        self.assertEqual(self.raw['lines'],['Pessoa Teste'])
    def test_collect_preserves_verified_phone_and_stops_after_return_failure(self):
        page=self.Page([])
        page.evaluate=lambda *args:{'selected':True,'rows':[self.raw],'top':0,'max':500,'bottom':False}
        enriched={**self.raw,'lines':['Pessoa Teste','+55 21 90000-0000']}
        with patch.object(core,'read_group_phone',side_effect=core.GroupReturnError('Falha ao retornar',enriched)) as read:
            result=core.collect_group(page,lambda:False,lambda n:None,lookup_phones=True)
        self.assertEqual(read.call_count,1)
        self.assertEqual(result['contatos'][0]['telefone'],'+5521900000000')
        self.assertIn('Falha ao retornar',result['observacao'])
    def test_cancelled_after_open_stops_without_another_click(self):
        page=self.Page([{'opened':True},{'back':True},{'restored':True}]);calls=iter([False,True])
        with self.assertRaisesRegex(RuntimeError,'interrompida'):core.read_group_phone(page,self.raw,lambda:next(calls))
        self.assertEqual(page.ops,['open'])


class GroupDiagnosticTests(unittest.TestCase):
    def test_screenshot_is_saved_locally_with_chat_list_masked(self):
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as tmp:
            page=Mock();page.locator.return_value.count.return_value=0;result=core.save_group_diagnostic(page,tmp)
            self.assertIn('ultimo_erro.png',result)
            args=page.screenshot.call_args.kwargs
            self.assertEqual(args['path'],str(Path(tmp)/'diagnosticos_grupos'/'ultimo_erro.png'))
            self.assertFalse(args['full_page'])
            self.assertEqual(args['mask'],[page.locator.return_value])
            page.locator.assert_any_call('#side')
    def test_screenshot_failure_does_not_destroy_partial_result(self):
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as tmp:
            page=Mock();page.locator.return_value.count.return_value=0;page.screenshot.side_effect=RuntimeError('closed')
            self.assertIn('Não foi possível salvar',core.save_group_diagnostic(page,tmp))


class GroupBrowserClickTests(unittest.TestCase):
    def test_browser_click_is_not_forced_or_retried(self):
        from unittest.mock import Mock
        page=Mock();page.evaluate.return_value={'click':'open'}
        core.group_profile_action(page,{'op':'open'})
        page.locator.assert_called_once_with('[data-painel-group-action="open"]')
        page.locator.return_value.click.assert_called_once_with(timeout=5000)
        page.locator.return_value.click.side_effect=RuntimeError('covered')
        with self.assertRaisesRegex(RuntimeError,'Não foi possível clicar'):
            core.group_profile_action(page,{'op':'open'})
    def test_click_error_identifies_action_and_browser_reason(self):
        from unittest.mock import Mock
        page=Mock();page.evaluate.return_value={'click':'expand'}
        page.locator.return_value.click.side_effect=RuntimeError('Element was detached')
        with self.assertRaisesRegex(RuntimeError,'reabrir Ver tudo.*Element was detached'):
            core.group_profile_action(page,{'op':'restore'})
        page.locator.return_value.click.assert_called_once_with(timeout=5000)

    def test_no_contact_does_not_attempt_back(self):
        page=GroupProfileFlowTests.Page([{'opened':True}]+[{'pending':True}]*32)
        with self.assertRaisesRegex(RuntimeError,'O clique não abriu'):
            core.read_group_phone(page,GroupProfileFlowTests.raw,lambda:False)
        self.assertNotIn('back',page.ops)
    def test_dialog_capture_has_no_overlapping_mask(self):
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as tmp:
            page=Mock();page.locator.return_value.count.return_value=1
            self.assertIn('Captura salva',core.save_group_diagnostic(page,tmp))
            page.screenshot.assert_not_called()
            args=page.locator.return_value.screenshot.call_args.kwargs
            self.assertNotIn('mask',args)
            self.assertEqual(args['path'],str(Path(tmp)/'diagnosticos_grupos'/'ultimo_erro.png'))


class GroupRealBrowserTests(unittest.TestCase):
    def test_trusted_click_profile_and_recreated_modal(self):
        import os,shutil
        if os.environ.get('PAINEL_TEST_BROWSER')!='1':self.skipTest('Defina PAINEL_TEST_BROWSER=1 em ambiente com Chromium permitido')
        chrome=shutil.which('chromium')
        if not chrome:self.skipTest('Chromium local necessário')
        try:from playwright.sync_api import sync_playwright
        except ImportError:self.skipTest('Playwright necessário')
        html=r"""<style>.viewport{height:300px;overflow-y:auto;width:500px}.row{height:72px;width:480px}.virtual{height:900px}</style>
        <main id="app"></main><script>
        window.trustedClicks=[];
        function members(){
          document.querySelector('#app').innerHTML=`<section role="dialog" aria-label="Pesquisar membros"><header>Pesquisar membros</header><input value=""><div class="viewport"><div class="virtual"><div class="row" role="listitem" data-testid="list-item-4"><div role="button" style="height:72px"><div data-testid="cell-frame-title"><span title="Pessoa Teste">Pessoa Teste</span></div></div></div></div></div></section>`;
          document.querySelector('[role="button"]').onclick=e=>{if(!e.isTrusted)return;trustedClicks.push('open');contact();};
        }
        function contact(){
          document.querySelector('#app').innerHTML=`<section><header><span>Dados do contato</span><button aria-label="Voltar">Voltar</button></header><div><span><div><div><span data-testid="contact-info-subtitle selectable-text">Pessoa Teste</span></div></div></span><div><span data-testid="selectable-text">+55 21 90000-0000</span></div></div></section>`;
          document.querySelector('button').onclick=e=>{if(!e.isTrusted)return;trustedClicks.push('back');members();};
        }
        members();</script>"""
        with sync_playwright() as pw:
            browser=pw.chromium.launch(executable_path=chrome,headless=True,args=['--no-sandbox'])
            try:
                page=browser.new_page();page.set_content(html)
                page.evaluate(core.GROUP_SELECT_JS)
                page.locator('[data-testid="cell-frame-title"]').click()
                self.assertTrue(page.evaluate(core.GROUP_READ_JS,False)['selected'])
                result=core.read_group_phone(page,GroupProfileFlowTests.raw,lambda:False)
                self.assertEqual(core.group_row(result)['telefone'],'+5521900000000')
                self.assertEqual(page.evaluate('window.trustedClicks'),['open','back'])
                self.assertTrue(page.evaluate(core.GROUP_READ_JS,False)['selected'])
            finally:browser.close()


if __name__=='__main__':unittest.main()
