"""Testes locais sem navegador e sem envios. Executar: python -m unittest test_painel -v"""
import contextlib
import io
import itertools
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import painel_core as core


class FakeTransport:
    def __init__(self): self.calls=[]; self.chats=[]; self.closed=False
    def open_chat(self,p): self.chats.append(p)
    def send(self,kind,value): self.calls.append((kind,value));return 'ENTREGUE','Transporte fictício de teste.'
    def close(self): self.closed=True


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.draft=core.new_draft();self.draft['mensagem']='Olá, {nome}!'
        self.draft['contatos']=[{'nome':f'Pessoa {i}','telefone':f'2190000000{i}'} for i in range(1,4)]
        image=self.root/'foto.jpg';image.write_bytes(b'fixture jpg')
        pdf=self.root/'material.pdf';pdf.write_bytes(b'%PDF-fixture')
        self.draft['anexos']=[str(image),str(pdf)]
    def tearDown(self):self.tmp.cleanup()
    def run_job(self,mode='enviar',transport=None,**kwargs):
        adapter=transport or FakeTransport()
        with contextlib.redirect_stdout(io.StringIO()),patch.object(core.motor.time,'monotonic',side_effect=itertools.count(0,2)):
            result=core.execute(self.draft,mode,self.root,transport_factory=lambda *_:adapter,**kwargs)
        return result,adapter
    def test_three_people_nine_items(self):
        result,adapter=self.run_job()
        self.assertEqual(len(adapter.calls),9);self.assertEqual(len(adapter.chats),3)
        self.assertEqual([v for k,v in adapter.calls if k=='texto'],['Olá, Pessoa 1!','Olá, Pessoa 2!','Olá, Pessoa 3!'])
        self.assertEqual(result['entregues_no_historico'],9);self.assertTrue(adapter.closed)
    def test_duplicate_run_does_not_send(self):
        self.run_job();result,adapter=self.run_job()
        self.assertEqual(adapter.calls,[]);self.assertEqual(result['ocorrencias_desta_execucao']['JA_PROCESSADO'],3)
    def test_simulation_does_not_open_transport(self):
        result,adapter=self.run_job('simular')
        self.assertEqual(result['simulados'],9);self.assertEqual(adapter.chats,[])
        result,adapter=self.run_job();self.assertEqual(len(adapter.calls),9)
    def test_duplicate_phone_blocks_entire_batch(self):
        self.draft['contatos'][2]['telefone']=self.draft['contatos'][0]['telefone']
        adapter=FakeTransport()
        with self.assertRaisesRegex(ValueError,'duplicado'):self.run_job(transport=adapter)
        self.assertEqual(adapter.calls,[])
    def test_missing_file_blocks_entire_batch(self):
        self.draft['anexos'].append(str(self.root/'ausente.pdf'))
        with self.assertRaisesRegex(ValueError,'não encontrado'):self.run_job()
    def test_missing_personalization_blocks(self):
        self.draft['mensagem']='Olá {nome}, turma {turma}'
        with self.assertRaisesRegex(ValueError,'não suportado'):self.run_job()
    def test_free_subject_without_personalization(self):
        self.draft['mensagem']='Convite para o culto de domingo.'
        result,adapter=self.run_job()
        self.assertEqual([v for k,v in adapter.calls if k=='texto'],[self.draft['mensagem']]*3)
    def test_legacy_contact_fields_do_not_change_message(self):
        self.run_job()
        for row in self.draft['contatos']:
            row.update(curso='Antigo',turma='A',codigo='123')
        result,adapter=self.run_job()
        self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['JA_PROCESSADO'],3)
    def test_unknown_placeholder_blocks(self):
        self.draft['mensagem']='Olá {nome.__class__}'
        with self.assertRaisesRegex(ValueError,'não suportado'):self.run_job()
    def test_changed_content_conflict(self):
        self.run_job();self.draft['mensagem']='Outro texto'
        result,adapter=self.run_job();self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['CONFLITO'],3)
    def test_uncertain_never_auto_retries(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):self.calls.append((k,v));raise RuntimeError('Sem confirmação')
        result,adapter=self.run_job(transport=Uncertain());self.assertEqual(result['incertos'],1)
        result,adapter=self.run_job();self.assertEqual(adapter.calls,[])
        self.assertEqual(result['ocorrencias_desta_execucao']['BLOQUEADO'],1)
    def test_manual_received_continues_only_attachments(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):raise RuntimeError('Sem confirmação')
        self.run_job(transport=Uncertain());cfg,rows=core.prepare(self.draft)
        core.review_item(cfg['campanha'],rows[0]['telefone'],'00-texto','recebido',self.root)
        result,adapter=self.run_job();self.assertEqual([k for k,v in adapter.calls],['anexo','anexo'])
        self.assertEqual(result['entregues_no_historico'],3)
    def test_retry_unknown_result_refused(self):
        self.draft['contatos']=self.draft['contatos'][:1]
        class Uncertain(FakeTransport):
            def send(self,k,v):raise RuntimeError('Sem confirmação')
        self.run_job(transport=Uncertain());cfg,rows=core.prepare(self.draft)
        with self.assertRaises(ValueError):core.review_item(cfg['campanha'],rows[0]['telefone'],'00-texto','retomar',self.root)
    def test_stop_before_start_is_respected(self):
        (self.root/'PARAR').touch()
        result,adapter=self.run_job(reset_stop=False)
        self.assertEqual(adapter.calls,[]);self.assertTrue(result['parado']);self.assertEqual(result['pendentes'],9)
    def test_second_process_lock_denied(self):
        with core.execution_lock(self.root):
            with self.assertRaises(ValueError):
                with core.execution_lock(self.root):pass
    def test_copy_file_survives_source_removed(self):
        source=Path(self.draft['anexos'][0]);dest=core.stage_attachment(source,self.root)
        source.unlink();self.assertEqual(Path(dest).read_bytes(),b'fixture jpg')
    def test_header_mapping(self):
        m=core.parse_text('Telefone;Nome;Turma\n21900000001;Ana;A\n21900000002;Bia;B')
        header,mapping=core.suggested_mapping(m);rows=core.map_contacts(m,mapping,header)
        self.assertTrue(header);self.assertEqual(rows[0]['nome'],'Ana');self.assertEqual(set(rows[1]),{'nome','telefone'})
    def test_paste_without_header(self):
        m=core.parse_text('Ana\t21900000001\nBia\t21900000002')
        header,mapping=core.suggested_mapping(m);self.assertFalse(header)
        self.assertEqual(len(core.map_contacts(m,mapping,header)),2)
    def test_phone_normalization(self):
        self.assertEqual(core.normalize_phone('(21) 90000-0001'),'5521900000001')
        self.assertEqual(core.normalize_phone('5521900000001.0'),'5521900000001')
        self.assertEqual(core.normalize_phone('+12025550123'),'12025550123')
        with self.assertRaises(ValueError):core.normalize_phone('5.521E+12')
    def test_empty_list(self):
        self.draft['contatos']=[]
        with self.assertRaises(ValueError):core.prepare(self.draft)
    def test_new_campaign_has_unique_id(self):
        self.assertNotEqual(core.new_draft()['id'],core.new_draft()['id'])
    def test_atomic_json_roundtrip(self):
        path=self.root/'a.json';core.atomic_json(path,self.draft)
        self.assertEqual(json.loads(path.read_text()),self.draft)
    def test_xlsx_read_shared_and_inline(self):
        path=self.root/'list.xlsx';ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
        with zipfile.ZipFile(path,'w') as z:
            z.writestr('xl/workbook.xml',f'<workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Lista" r:id="r1"/></sheets></workbook>')
            z.writestr('xl/_rels/workbook.xml.rels','<Relationships><Relationship Id="r1" Target="worksheets/sheet1.xml"/></Relationships>')
            z.writestr('xl/sharedStrings.xml',f'<sst xmlns="{ns}"><si><t>Nome</t></si><si><t>Ana</t></si></sst>')
            z.writestr('xl/worksheets/sheet1.xml',f'<worksheet xmlns="{ns}"><sheetData><row><c r="A1" t="s"><v>0</v></c><c r="B1" t="inlineStr"><is><t>Telefone</t></is></c></row><row><c r="A2" t="s"><v>1</v></c><c r="B2"><v>21900000001</v></c></row></sheetData></worksheet>')
        self.assertEqual(core.file_matrix(path),['Lista'])
        m=core.file_matrix(path,'Lista');self.assertEqual(m,[['Nome','Telefone'],['Ana','21900000001']])


class ChatOpeningTests(unittest.TestCase):
    def setUp(self):
        from unittest.mock import MagicMock
        import types
        self.tmp=tempfile.TemporaryDirectory()
        self.adapter=core.motor.WhatsApp.__new__(core.motor.WhatsApp)
        self.adapter.root=Path(self.tmp.name)
        self.adapter.sel={'composer':'editor','invalid_regex':'invalid'}
        self.page=MagicMock();self.adapter.page=self.page
        self.page.is_closed.return_value=False
        self.editor=MagicMock();self.editor.count.return_value=1
        self.editor.is_visible.return_value=True
        self.bad=MagicMock();self.bad.count.return_value=0
        self.page.locator.side_effect=lambda s: self.editor if s=='editor' else self.bad
        self.bad.get_by_text.return_value=self.bad
        self.adapter.session_signals=lambda: {}
        api=types.ModuleType('playwright.sync_api');api.TimeoutError=TimeoutError
        self.modules=patch.dict('sys.modules',{'playwright':types.ModuleType('playwright'),'playwright.sync_api':api})
        self.modules.start()
    def tearDown(self):
        self.modules.stop();self.tmp.cleanup()
    def open(self):
        with contextlib.redirect_stdout(io.StringIO()),patch.object(core.motor.time,'monotonic',side_effect=itertools.count(0,30)):
            self.adapter.open_chat('5521900000001')
    def test_navigation_timeout_retries_without_using_old_editor(self):
        self.page.goto.side_effect=[None,TimeoutError(),None,None]
        self.open()
        self.assertEqual(self.page.goto.call_count,4)
        self.assertEqual(self.editor.is_visible.call_count,2)
        urls=[c.args[0] for c in self.page.goto.call_args_list]
        self.assertEqual(urls[0], 'about:blank');self.assertEqual(urls[2],'about:blank')
        self.assertEqual(urls[1],urls[3])
    def test_slow_interface_retries_then_opens(self):
        self.editor.count.side_effect=[0,0,0,1,1]
        self.open()
        self.assertEqual(self.page.goto.call_count,4)
    def test_two_timeouts_fail_without_inspecting_editor(self):
        self.page.goto.side_effect=[None,TimeoutError(),None,TimeoutError()]
        with self.assertRaisesRegex(RuntimeError,'duas tentativas'):self.open()
        self.editor.is_visible.assert_not_called()
    def test_invalid_dialog_does_not_retry(self):
        self.bad.count.return_value=1;self.bad.nth.return_value.is_visible.return_value=True
        with self.assertRaises(ValueError):self.open()
        self.assertEqual(self.page.goto.call_count,2)
    def test_stop_prevents_navigation(self):
        (self.adapter.root/'PARAR').touch()
        with self.assertRaisesRegex(RuntimeError,'Parar'):self.open()
        self.page.goto.assert_not_called()
    def test_closed_browser_prevents_navigation(self):
        self.page.is_closed.return_value=True
        with self.assertRaisesRegex(RuntimeError,'fechado'):self.open()
        self.page.goto.assert_not_called()


class ShortcutTests(unittest.TestCase):
    def test_shortcut_uses_pythonw_and_quotes_paths(self):
        import base64
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory(prefix="Painel d' teste ") as td:
            root=Path(td);exe=root/'.venv'/'Scripts'/'pythonw.exe';exe.parent.mkdir(parents=True);exe.touch()
            (root/'painel.py').touch()
            with patch.object(core.sys,'platform','win32'),patch.object(core.subprocess,'run',return_value=SimpleNamespace(returncode=0)) as run:
                core.create_desktop_shortcut(root)
            args=run.call_args.args[0]
            script=base64.b64decode(args[-1]).decode('utf-16le')
            self.assertIn(str(exe).replace("'","''"),script)
            self.assertIn('"'+str(root/'painel.py').replace("'","''")+'"',script)
            self.assertIn("SpecialFolders.Item('Desktop')",script)
            self.assertIn('$link.WorkingDirectory',script)
            self.assertNotIn('-ExecutionPolicy',args)
    def test_missing_pythonw_does_not_create_shortcut(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/'painel.py').touch()
            with patch.object(core.sys,'platform','win32'),patch.object(core.sys,'executable',str(root/'python.exe')),patch.object(core.subprocess,'run') as run:
                with self.assertRaisesRegex(RuntimeError,'pythonw.exe'):core.create_desktop_shortcut(root)
                run.assert_not_called()


if __name__=='__main__':unittest.main()
