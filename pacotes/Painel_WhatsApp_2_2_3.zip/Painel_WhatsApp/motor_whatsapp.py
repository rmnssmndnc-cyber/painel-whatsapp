"""Projeto acadêmico: Excel -> fila persistente -> WhatsApp Web.
Python 3.11+. Simulação não importa Playwright nem abre navegador.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, os, re, sqlite3, sys, time, zipfile
from pathlib import Path
from datetime import datetime
from string import Formatter
from urllib.parse import urlencode
from xml.etree import ElementTree as ET

BASE = Path(__file__).resolve().parent
VERSION = '1.4.1'
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
HEADERS = ['data_hora','campanha','codigo','nome','telefone','item','status','motivo','conteudo','modo']

def now():
    return datetime.now().astimezone().isoformat(timespec='seconds')

def sheet_cells(path, name):
    """Leitura OOXML somente; a escrita/edição da planilha ocorre no Excel."""
    with zipfile.ZipFile(path) as z:
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            shared = [''.join(si.itertext()) for si in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        book = ET.fromstring(z.read('xl/workbook.xml'))
        rels = {e.attrib['Id']: e.attrib['Target'] for e in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        entry = next(s for s in book.find('s:sheets', NS) if s.attrib['name'] == name)
        rid = entry.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
        target = rels[rid]
        member = target.lstrip('/') if target.startswith('/') else 'xl/' + target
        result = {}
        for cell in ET.fromstring(z.read(member)).findall('.//s:sheetData/s:row/s:c', NS):
            ref = cell.attrib['r']
            if cell.find('s:f', NS) is not None:
                raise ValueError(f'{name}!{ref}: use valores, não fórmulas, nas entradas.')
            typ = cell.attrib.get('t')
            raw = cell.findtext('s:v', '', NS)
            value = shared[int(raw)] if typ == 's' else ''.join(cell.find('s:is', NS).itertext()) if typ == 'inlineStr' else raw
            result[ref] = value
        return result

def load_book(path):
    cells = sheet_cells(path, 'Mensagem')
    cfg = {cells.get(f'A{r}', ''): cells.get(f'B{r}', '') for r in range(5, 11)}
    if not cfg.get('campanha', '').strip():
        raise ValueError('Preencha o identificador da campanha em Mensagem!B5.')
    for key, low, high in [('intervalo_segundos',1,3600),('tempo_confirmacao',10,180),('limite_contatos',1,1000)]:
        cfg[key] = int(cfg[key])
        if not low <= cfg[key] <= high:
            raise ValueError(f'{key}: informe um inteiro entre {low} e {high}.')
    cells = sheet_cells(path, 'Contatos')
    headers = [cells.get(f'{c}4', '') for c in 'ABCDEFGH']
    if headers != ['selecionar','codigo','nome','telefone','curso','turma','anexos','autorizado']:
        raise ValueError('Cabeçalhos de Contatos foram alterados. Restaure a linha 4.')
    if any(int(re.search(r'\d+', ref)[0]) > 1004 and val for ref,val in cells.items()):
        raise ValueError('Há dados depois da linha 1004. Divida em lotes de até 1.000 contatos.')
    rows = [dict(zip(headers,[cells.get(f'{c}{r}', '') for c in 'ABCDEFGH'])) for r in range(5,1005)]
    return cfg, [r for r in rows if r['selecionar'].strip().upper() == 'SIM']

def phone(value):
    if not re.fullmatch(r'[+\d\s().-]+', value.strip()):
        raise ValueError('Telefone contém caracteres inválidos.')
    p = re.sub(r'\D', '', value)
    if not re.fullmatch(r'[1-9]\d{7,14}', p):
        raise ValueError('Informe DDI + DDD + número, de 8 a 15 dígitos.')
    if p.startswith('55') and len(p) not in (12,13):
        raise ValueError('Telefone brasileiro deve ter 12 ou 13 dígitos com DDI 55.')
    if not p.startswith('55') and not value.strip().startswith('+'):
        raise ValueError('Para Brasil, informe 55 + DDD + número. Para outros países, comece com +DDI.')
    return p

def personalize(template, row):
    allowed = {'nome'}
    for _, field, spec, conv in Formatter().parse(template):
        if field is not None and (field not in allowed or spec or conv):
            raise ValueError(f'Campo não suportado na mensagem: {field}.')
        if field is not None and not row.get(field,'').strip():
            raise ValueError(f'Campo obrigatório vazio: {field}.')
    text = template.format_map(row).strip()
    if len(text) > 4000:
        raise ValueError('Modelo do projeto limitado a 4.000 caracteres.')
    return text

def items_for(cfg, row, root):
    text = personalize(cfg.get('modelo',''), row)
    items = [('texto', text)] if text else []
    seen = set()
    for entry in (cfg.get('anexos_comuns','') + '|' + row.get('anexos','')).split('|'):
        if not entry.strip():
            continue
        path = Path(entry.strip().strip('"'))
        path = (root / path).resolve() if not path.is_absolute() else path.resolve()
        if path in seen:
            continue
        seen.add(path)
        if not path.is_file():
            raise ValueError(f'Anexo não encontrado: {path}')
        if path.suffix.lower() not in {'.pdf','.png','.jpg','.jpeg'}:
            raise ValueError(f'Formato não suportado: {path.name}. Use PDF, PNG ou JPG.')
        if not 0 < path.stat().st_size <= 15*1024*1024:
            raise ValueError(f'{path.name}: arquivo vazio ou acima do limite do projeto (15 MB).')
        items.append(('anexo', str(path)))
    if sum(kind=='anexo' for kind,_ in items)>8:
        raise ValueError('Limite do projeto: oito anexos por contato.')
    if not items:
        raise ValueError('Preencha uma mensagem ou um anexo.')
    return items

def fingerprint(items):
    h = hashlib.sha256()
    for kind, value in items:
        h.update(json.dumps([kind,value],ensure_ascii=False).encode())
        if kind == 'anexo':
            h.update(Path(value).read_bytes())
    return h.hexdigest()

class BeforeSendError(RuntimeError):
    """Falha comprovadamente anterior ao clique/Enter de envio."""


def safe_to_retry(state, item):
    if not state or state[0] != 'INCERTO':
        return False
    reason = state[2]
    if reason.startswith('ANTES_DO_ENVIO: '):
        return True
    # Migração estrita da falha de anexação da versão anterior.
    old = 'locator("#main footer [data-icon=\'plus-rounded\'], #main footer [data-icon=\'plus\']")'
    return item.endswith('-anexo') and reason.startswith('Locator.click: Timeout ') and old in reason

class History:
    def __init__(self, path):
        self.path=Path(path)
        self.db = sqlite3.connect(path)
        self.db.execute('CREATE TABLE IF NOT EXISTS recipients(campaign TEXT, phone TEXT, fingerprint TEXT, PRIMARY KEY(campaign,phone))')
        self.db.execute('CREATE TABLE IF NOT EXISTS items(campaign TEXT, phone TEXT, item TEXT, status TEXT, time TEXT, reason TEXT, PRIMARY KEY(campaign,phone,item))')
        self.db.execute('CREATE TABLE IF NOT EXISTS events(data TEXT)')
        self.db.commit()

    def bind(self,campaign,p,digest):
        old=self.db.execute('SELECT fingerprint FROM recipients WHERE campaign=? AND phone=?',(campaign,p)).fetchone()
        if old and old[0]!=digest:
            raise ValueError('Conteúdo alterado na mesma campanha. Restaure o original ou crie outra campanha após revisar o histórico.')
        self.db.execute('INSERT OR IGNORE INTO recipients VALUES(?,?,?)',(campaign,p,digest));self.db.commit()

    def claim(self,campaign,p,item):
        try:
            self.db.execute('INSERT INTO items VALUES(?,?,?,?,?,?)',(campaign,p,item,'INCERTO',now(),'Reservado antes da ação. Se interrompido, conferir no WhatsApp.'))
            self.db.commit();return True
        except sqlite3.IntegrityError:
            return False

    def state(self,campaign,p,item):
        return self.db.execute('SELECT status,time,reason FROM items WHERE campaign=? AND phone=? AND item=?',(campaign,p,item)).fetchone()

    def finish(self,campaign,p,item,status,reason):
        self.db.execute('UPDATE items SET status=?,time=?,reason=? WHERE campaign=? AND phone=? AND item=?',(status,now(),reason,campaign,p,item));self.db.commit()

    def event(self,row):
        self.db.execute('INSERT INTO events VALUES(?)',(json.dumps(row,ensure_ascii=False),));self.db.commit()

    def release_before_send(self,campaign,p,item):
        state=self.state(campaign,p,item)
        if not safe_to_retry(state,item):
            raise ValueError('Esta tentativa não pode ser liberada com segurança.')
        backup=self.path.with_name('historico_backup_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite3')
        with sqlite3.connect(backup) as dest:self.db.backup(dest)
        with self.db:
            self.db.execute('DELETE FROM items WHERE campaign=? AND phone=? AND item=? AND status=?',
                            (campaign,p,item,'INCERTO'))
            self.db.execute('INSERT INTO events VALUES(?)',(json.dumps(
                [now(),campaign,'','',p,item,'RETOMADA_AUTORIZADA',
                 'Falha antes do envio; operador autorizou nova tentativa. Registro anterior preservado nos eventos.',
                 '', 'revisao_manual'],ensure_ascii=False),))

    def confirm_received(self,campaign,p,item):
        """Somente após conferência humana explícita; nunca libera um reenvio."""
        state=self.state(campaign,p,item)
        if not state or state[0]!='INCERTO':
            raise ValueError('Somente um item INCERTO pode receber esta confirmação.')
        backup=self.path.with_name('historico_backup_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite3')
        with sqlite3.connect(backup) as dest:self.db.backup(dest)
        with self.db:
            stamp=now();reason='Recebimento confirmado MANUALMENTE pelo operador após conferir a conversa; sem reenvio.'
            self.db.execute('UPDATE items SET status=?,time=?,reason=? WHERE campaign=? AND phone=? AND item=? AND status=?',('ENTREGUE',stamp,reason,campaign,p,item,'INCERTO'))
            self.db.execute('INSERT INTO events VALUES(?)',(json.dumps([stamp,campaign,'','',p,item,'ENTREGUE',reason,'','revisao_manual'],ensure_ascii=False),))

def normalized(text):
    return re.sub(r'\s+',' ',text.replace('\u200e','').replace('\u200f','').replace('\u200b','')).strip()

def detect_ack(messages,before,kind,value):
    for msg in messages:
        if not msg.get('id') or msg['id'] in before:continue
        text=normalized(msg.get('text',''))
        if kind=='texto' and normalized(value) not in text:continue
        if kind=='anexo':
            if Path(value).suffix.lower()=='.pdf' and Path(value).name not in text:continue
            if Path(value).suffix.lower()!='.pdf' and not msg.get('image'):continue
        icons=set(msg.get('icons',[]))
        labels={normalized(v).casefold() for v in msg.get('status_labels',[])}
        if icons & {'wds-ic-read','wds-ic-delivered'} or labels & {'lida','lido','read','entregue','delivered'}:
            return 'ENTREGUE','Confirmação de entrega/leitura observada no status da nova mensagem.'
        if icons & {'msg-dblcheck','msg-dblcheck-ack','status-dblcheck','wds-ic-double-check'}:
            return 'ENTREGUE','Dois tiques observados em nova mensagem; leitura não verificada.'
        if icons & {'msg-check','status-check','wds-ic-checkmark'}:
            return 'ENVIADO','Um tique observado em nova mensagem; entrega não confirmada.'
    return None

SNAPSHOT_JS = """() => {
  const output=new Map();
  const candidates=document.querySelectorAll(
    '[data-testid^="conv-msg-"][data-id], #main .message-out, #main [data-id^="true_"]');
  for(const node of candidates){
    const owner=node.closest('[data-id]') || node.querySelector('[data-id]');
    const id=owner?.getAttribute('data-id');
    if(!id) continue;
    const bubble=owner.querySelector('[data-testid="msg-container"]') ||
      (node.matches('.message-out') ? node : (node.querySelector('.message-out') || node));
    const meta=bubble.querySelector('[data-testid="msg-meta"]');
    const status=meta || bubble;
    const icons=Array.from(status.querySelectorAll('[data-icon]'),e=>e.getAttribute('data-icon'));
    // SVG title é usado pela interface atual, sem atributo data-icon.
    if(meta) icons.push(...Array.from(meta.querySelectorAll('svg title'),e=>e.textContent.trim()));
    const labels=meta ? Array.from(meta.querySelectorAll('[aria-label]'),e=>e.getAttribute('aria-label').trim()) : [];
    const knownAck=icons.some(i=>['wds-ic-read','wds-ic-delivered','msg-check','msg-dblcheck','msg-dblcheck-ack',
      'status-check','status-dblcheck','wds-ic-checkmark','wds-ic-double-check'].includes(i));
    const outgoing=id.startsWith('true_') || node.matches('.message-out') ||
      !!bubble.querySelector('[data-testid="tail-out"], [data-icon="tail-out"], [aria-label="Você:"], [aria-label="You:"]') || knownAck;
    if(!outgoing) continue;
    const data={id,text:bubble.innerText||'',
      image:!bubble.querySelector('[data-testid="document-thumb"]') && !!bubble.querySelector('img[src]'),
      icons:[...new Set(icons)],status_labels:labels};
    const old=output.get(id);
    if(!old || data.icons.length>old.icons.length)output.set(id,data);
  }
  return Array.from(output.values());
}"""

def safe_csv(value):
    value=str(value)
    return "'"+value if value.lstrip().startswith(('=','+','-','@')) else value

def export_csv(path, rows):
    temp=path.with_suffix('.tmp')
    with temp.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f,delimiter=';');writer.writerow(HEADERS)
        writer.writerows([[safe_csv(v) for v in row] for row in rows])
    os.replace(temp,path)

class WhatsApp:
    """Adaptador de interface. Seletores isolados em seletores.json."""
    def __init__(self, root, timeout, session_timeout=300, diagnostic=False):
        from playwright.sync_api import sync_playwright
        selector_file=BASE/'seletores_painel.json'
        self.sel=json.loads(selector_file.read_text(encoding='utf-8-sig')) if selector_file.exists() else {}
        if not diagnostic and not self.sel:
            raise ValueError('seletores.json não encontrado. Coloque app.py na pasta original do projeto.')
        self.root=Path(root)
        self.diagnostic=diagnostic
        self.timeout=timeout
        self.pw=sync_playwright().start()
        self.context=None
        try:
            self.context=self.pw.chromium.launch_persistent_context(str(root/'sessao'),headless=False)
            self.page=self.context.pages[0] if self.context.pages else self.context.new_page()
            self.page.set_default_timeout(20000)
            self.page.goto('https://web.whatsapp.com/',wait_until='commit',timeout=60000)
            self.page.bring_to_front()
            print('Usando a sessão salva em dados/sessao. Se aparecer QR code, conecte pelo celular.',flush=True)
            self.wait_ready(session_timeout)
        except BaseException:
            try:
                if self.context:self.context.close()
            finally:self.pw.stop()
            raise

    def session_signals(self):
        # Somente sinais estruturais: não coleta mensagens, telefones nem QR codes.
        selectors = {
            'painel_original': '#pane-side',
            'lista_conversas': '#side [role="grid"]',
            'lista_identificada': '[data-testid="chat-list"]',
            'editor_conversa': '#main footer [contenteditable="true"][role="textbox"]',
            'qr_code': '[data-ref] canvas',
            'carregando': '[role="progressbar"]',
        }
        if self.sel.get('ready'):
            selectors['configurado'] = self.sel['ready']
        signals = {}
        for name, selector in selectors.items():
            try:
                nodes = self.page.locator(selector)
                signals[name] = any(nodes.nth(i).is_visible() for i in range(min(nodes.count(), 20)))
            except Exception:
                signals[name] = False
        return signals

    def save_session_diagnostic(self, status, signals):
        self.root.mkdir(parents=True, exist_ok=True)
        result = {'versao': VERSION, 'estado': status, 'sinais': signals,
                  'modo': 'conexao' if self.diagnostic else 'enviar'}
        (self.root/'diagnostico_sessao.json').write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')

    def wait_ready(self, seconds):
        end = time.monotonic() + seconds
        previous = None
        signals = {}
        stable = 0
        while time.monotonic() < end:
            if self.page.is_closed():
                self.save_session_diagnostic('NAVEGADOR_FECHADO', signals)
                raise RuntimeError('O navegador foi fechado antes de reconhecer a sessão.')
            if (self.root/'PARAR').exists():
                self.save_session_diagnostic('INTERROMPIDO', signals)
                raise RuntimeError('Teste interrompido pelo comando Parar.')
            signals = self.session_signals()
            ready = any(signals.get(k) for k in (
                'painel_original', 'lista_conversas', 'lista_identificada',
                'editor_conversa', 'configurado'))
            stable = stable + 1 if ready and not signals.get('qr_code') else 0
            if stable >= 2:
                self.save_session_diagnostic('CONECTADO', signals)
                print('CONECTADO — interface de conversas reconhecida.', flush=True)
                return
            state = 'QR code: conecte pelo celular.' if signals.get('qr_code') else 'Aguardando a interface de conversas carregar...'
            if state != previous:
                print(state, flush=True)
                previous = state
            self.page.wait_for_timeout(1000)
        self.save_session_diagnostic('TEMPO_ESGOTADO', signals)
        visible = ', '.join(k for k,v in signals.items() if v) or 'nenhum'
        raise RuntimeError('Sessão não reconhecida no prazo. Sinais: '+visible+
                           '. Diagnóstico: dados/diagnostico_sessao.json. Não apague a sessão nem o histórico.')

    def open_chat(self,p):
        # Só repete a abertura, nunca o envio. Um documento vazio elimina o
        # editor da conversa anterior antes de navegar para o número solicitado.
        from playwright.sync_api import TimeoutError as NavigationTimeout
        url='https://web.whatsapp.com/send?'+urlencode({'phone':p})
        reason='INTERFACE_NAO_RECONHECIDA'
        for attempt in range(1,3):
            self.check_chat_stop()
            print(f'Abrindo conversa: tentativa {attempt}/2. Nenhuma mensagem enviada nesta etapa.',flush=True)
            try:
                self.page.goto('about:blank',wait_until='commit',timeout=20000)
                self.page.goto(url,wait_until='commit',timeout=60000)
            except NavigationTimeout:
                reason='TEMPO_DE_NAVEGACAO_ESGOTADO'
                self.save_chat_diagnostic(reason,attempt)
                continue
            end=time.monotonic()+120
            stable=0
            while time.monotonic()<end:
                self.check_chat_stop()
                # Restringe a avisos: uma mensagem antiga com esse texto não
                # deve classificar o contato como inválido.
                bad=self.page.locator('[role="dialog"], [role="alert"]').get_by_text(
                    re.compile(self.sel['invalid_regex'],re.I))
                if any(bad.nth(i).is_visible() for i in range(bad.count())):
                    self.save_chat_diagnostic('NUMERO_RECUSADO_PELO_WHATSAPP',attempt)
                    raise ValueError('WhatsApp informou número inválido ou sem conta.')
                composer=self.page.locator(self.sel['composer'])
                ready=composer.count()==1 and composer.is_visible()
                stable=stable+1 if ready else 0
                if stable>=2:
                    self.save_chat_diagnostic('CONVERSA_ABERTA',attempt)
                    return
                self.page.wait_for_timeout(500)
            reason='INTERFACE_NAO_RECONHECIDA'
            self.save_chat_diagnostic(reason,attempt)
        raise RuntimeError('Conversa não abriu após duas tentativas, antes de qualquer envio. '
                           'Isso não confirma número inválido. Diagnóstico: dados/diagnostico_conversa.json ('+reason+').')

    def check_chat_stop(self):
        if (self.root/'PARAR').exists():
            raise RuntimeError('Abertura interrompida pelo comando Parar, antes do envio.')
        if self.page.is_closed():
            raise RuntimeError('Navegador fechado antes de abrir a conversa.')

    def save_chat_diagnostic(self,state,attempt):
        self.root.mkdir(parents=True,exist_ok=True)
        # Sem telefone, texto de mensagens ou QR code.
        result={'data_hora':now(),'estado':state,'tentativa':attempt,
                'sinais':self.session_signals()}
        (self.root/'diagnostico_conversa.json').write_text(
            json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')

    def send(self,kind,value):
        page=self.page
        before={msg['id'] for msg in page.evaluate(SNAPSHOT_JS)}
        if kind=='texto':
            editor=page.locator(self.sel['composer'])
            editor.fill(value)
            editor.press('Enter')
        else:
            try:
                # Localizar apenas um controle visível na barra da conversa.
                selectors = [self.sel.get('attach',''),
                    '#main footer [data-icon="plus-rounded"]',
                    '#main footer [data-icon="plus"]',
                    '#main footer [data-icon="wds-ic-plus-rounded"]',
                    '#main footer [data-icon="clip"]',
                    '#main footer button[aria-label="Anexar"]',
                    '#main footer [role="button"][aria-label="Anexar"]',
                    '#main footer button[aria-label="Attach"]',
                    '#main footer [role="button"][aria-label="Attach"]',
                    '#main footer [title="Anexar"]',
                    '#main footer [title="Attach"]']
                plus=None
                deadline=time.monotonic()+20
                while time.monotonic()<deadline and plus is None:
                    for selector in selectors:
                        if not selector:continue
                        matches=page.locator(selector)
                        visible=[matches.nth(i) for i in range(matches.count()) if matches.nth(i).is_visible()]
                        if len(visible)==1:
                            plus=visible[0];break
                    if plus is None:page.wait_for_timeout(250)
                if plus is None:
                    # Inventário somente de atributos de controles, sem conteúdo de conversas.
                    controls=page.locator('#main footer').evaluate_all("""nodes => nodes.flatMap(n =>
                        Array.from(n.querySelectorAll('button,[role="button"],[data-icon]'), e => ({
                          tag:e.tagName, icon:e.getAttribute('data-icon'),
                          label:e.getAttribute('aria-label'), title:e.getAttribute('title')})))""")
                    (self.root/'diagnostico_anexar.json').write_text(
                        json.dumps({'versao':VERSION,'controles':controls},ensure_ascii=False,indent=2),encoding='utf-8')
                    raise RuntimeError('Botão de anexar não identificado. Envie dados/diagnostico_anexar.json para análise.')
                plus.click()
                label=self.sel['photo_regex'] if Path(value).suffix.lower()!='.pdf' else self.sel['document_regex']
                with page.expect_file_chooser() as chooser:
                    page.get_by_text(re.compile(label,re.I),exact=True).click()
                chooser.value.set_files(value)
                send=page.locator(self.sel['send_preview'])
                send.wait_for(state='visible')
                if send.count()!=1:
                    raise RuntimeError('Não foi possível identificar um único botão de envio do anexo.')
            except Exception as e:
                raise BeforeSendError('ANTES_DO_ENVIO: '+str(e)) from e
            # A partir deste clique, qualquer falha volta a ser resultado desconhecido.
            send.click()
        end=time.monotonic()+self.timeout
        latest=[]
        while time.monotonic()<end:
            latest=page.evaluate(SNAPSHOT_JS)
            result=detect_ack(latest,before,kind,value)
            if result:return result
            page.wait_for_timeout(250)
        # Diagnóstico estrutural, sem textos, telefones, imagens ou IDs de mensagens.
        diag={'versao':VERSION,'tipo':kind,'mensagens_antes':len(before),'mensagens_depois':len(latest),
              'novas':[{'icones':m.get('icons',[]),'imagem':m.get('image',False),'status':m.get('status_labels',[])} for m in latest if m['id'] not in before]}
        (BASE/'dados'/'diagnostico_confirmacao.json').write_text(json.dumps(diag,ensure_ascii=False,indent=2),encoding='utf-8')
        raise RuntimeError('Sem confirmação por tique no prazo. Confira antes de qualquer reenvio.')

    def close(self):
        try:self.context.close()
        except Exception:pass
        finally:self.pw.stop()

def run(cfg,rows,root,mode,transport_factory=WhatsApp,manual_review=False):
    root.mkdir(parents=True,exist_ok=True)
    history=History(root/'historico.sqlite3')
    report=[];seen=set();adapter=None
    campaign=cfg['campanha'].strip()
    def log(row,p,item,status,reason,content=''):
        record=[now(),campaign,row.get('codigo',''),row.get('nome',''),p,item,status,reason,content,mode]
        report.append(record);history.event(record)
        export_csv(root/'resultados.csv',report)
        print(f'{record[0]} | {row.get("nome","")} | {item} | {status} | {reason}',flush=True)
    try:
        if len(rows)>cfg['limite_contatos']:
            raise ValueError('Selecionados excedem limite_contatos. Ajuste o limite ou a seleção; nenhum envio foi iniciado.')
        prepared=[]
        for row in rows:
            p=row.get('telefone','')
            try:
                p=phone(p)
                if p in seen:
                    raise ValueError('Número repetido neste lote. Selecione uma única linha por número.')
                seen.add(p)
                if row.get('autorizado','').upper().strip()!='SIM':
                    raise ValueError('Contato não marcado como autorizado.')
                items=items_for(cfg,row,BASE)
                prepared.append((row,p,items,fingerprint(items)))
            except ValueError as e:
                log(row,p,'validacao','INVALIDO',str(e))
        for row,p,items,digest in prepared:
            if (root/'PARAR').exists():
                break
            if mode=='simular':
                for i,(kind,value) in enumerate(items):
                    log(row,p,f'{i:02d}-{kind}','SIMULADO','Nenhuma mensagem enviada.',value)
                continue
            try:
                history.bind(campaign,p,digest)
            except ValueError as e:
                log(row,p,'validacao','CONFLITO',str(e));continue
            pending=False;uncertain=False
            for i,(kind,value) in enumerate(items):
                state=history.state(campaign,p,f'{i:02d}-{kind}')
                if not state: pending=True
                elif state[0]=='INCERTO': uncertain=True
            if uncertain:
                if manual_review:
                    for i,(kind,value) in enumerate(items):
                        item=f'{i:02d}-{kind}';state=history.state(campaign,p,item)
                        if not state or state[0]!='INCERTO':continue
                        print(f'\nREVISÃO: {campaign} | {row.get("nome","")} | {p} | {item}\nTentativa: {state[1]}\nConteúdo: {value}',flush=True)
                        if safe_to_retry(state,item):
                            answer=input('Falha registrada ANTES do envio. Digite RETOMAR para tentar este item; Enter mantém bloqueado: ').strip().upper()
                            if answer=='RETOMAR':
                                history.release_before_send(campaign,p,item)
                            continue
                        answer=input('Confira ESTA tentativa na conversa. Se o destinatário recebeu ESTE item, digite RECEBIDO. Enter mantém bloqueado: ').strip().upper()
                        if answer=='RECEBIDO':
                            history.confirm_received(campaign,p,item)
                            log(row,p,item,'ENTREGUE','Recebimento confirmado MANUALMENTE pelo operador; sem reenvio.',value)
                    uncertain=any((history.state(campaign,p,f'{i:02d}-{kind}') or ('',))[0]=='INCERTO' for i,(kind,_) in enumerate(items))
                if uncertain:
                    log(row,p,'historico','BLOQUEADO','Há item incerto nesta campanha. Confira no WhatsApp; não haverá reenvio automático.');continue
            pending=any(history.state(campaign,p,f'{i:02d}-{kind}') is None for i,(kind,_) in enumerate(items))
            if not pending:
                log(row,p,'historico','JA_PROCESSADO','Todos os itens constam no histórico; envio não repetido.');continue
            if adapter is None:
                try:
                    adapter=transport_factory(root,cfg['tempo_confirmacao'])
                except Exception as e:
                    log(row,p,'sessao','FALHA',f'Não foi possível iniciar a sessão: {e}');break
            try:
                adapter.open_chat(p)
            except ValueError as e:
                log(row,p,'conversa','FALHA',str(e));continue
            except Exception as e:
                log(row,p,'conversa','FALHA',str(e));break
            for i,(kind,value) in enumerate(items):
                if (root/'PARAR').exists():break
                item=f'{i:02d}-{kind}'
                if not history.claim(campaign,p,item):
                    state=history.state(campaign,p,item)
                    log(row,p,item,'JA_PROCESSADO',f'{state[0]} em {state[1]}',value);continue
                try:
                    if fingerprint(items)!=digest:
                        raise RuntimeError('Anexo alterado durante a execução. Conferir e restaurar antes de retomar.')
                    status,reason=adapter.send(kind,value)
                except BaseException as e:
                    history.finish(campaign,p,item,'INCERTO',str(e) or type(e).__name__)
                    log(row,p,item,'INCERTO',str(e) or type(e).__name__,value)
                    return report  # parar lote; não adivinhar se houve envio
                history.finish(campaign,p,item,status,reason)
                log(row,p,item,status,reason,value)
                end=time.monotonic()+cfg['intervalo_segundos']
                while time.monotonic()<end and not (root/'PARAR').exists():time.sleep(.1)
        if not report:
            export_csv(root/'resultados.csv',report)
        return report
    finally:
        export_csv(root/'historico.csv',[json.loads(r[0]) for r in history.db.execute('SELECT data FROM events')])
        history.db.close()
        if adapter:adapter.close()

def main():
    parser=argparse.ArgumentParser(description='Projeto Excel + WhatsApp')
    parser.add_argument('--arquivo',type=Path,default=BASE/'Controle_WhatsApp.xlsx')
    parser.add_argument('--modo',choices=['simular','enviar','conexao','verificar'],default='simular')
    parser.add_argument('--pausar',action='store_true')
    parser.add_argument('--tempo-sessao',type=int,default=300)
    args=parser.parse_args()
    if not 30 <= args.tempo_sessao <= 900:
        parser.error('--tempo-sessao deve estar entre 30 e 900 segundos.')
    data=BASE/'dados';data.mkdir(exist_ok=True)
    # Bloqueio de sistema operacional: liberado mesmo se o processo cair.
    lock=(data/'execucao.lock').open('a+b');lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0)
    try:
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError:
        raise SystemExit('Já existe uma execução ativa. Aguarde ou use PARAR.cmd.')
    try:
        (data/'PARAR').unlink(missing_ok=True)
        if args.modo in ('conexao','verificar'):
            print('Versão '+VERSION+' — TESTE DE CONEXÃO. Nenhuma mensagem será enviada.',flush=True)
            adapter=WhatsApp(data,30,session_timeout=args.tempo_sessao,diagnostic=True)
            try:
                if args.modo=='verificar':
                    input('No navegador, abra a conversa de teste e deixe o PDF recebido visível. Depois pressione Enter AQUI: ')
                    messages=adapter.page.evaluate(SNAPSHOT_JS)
                    icons=sorted({icon for m in messages for icon in m.get('icons',[])})
                    print(f'Mensagens de saída reconhecidas: {len(messages)}',flush=True)
                    print('Ícones de status encontrados: '+(', '.join(icons) or 'nenhum'),flush=True)
                    diagnostic={'versao':VERSION,'mensagens':len(messages),'icones':icons}
                    (data/'diagnostico_leitura.json').write_text(json.dumps(diagnostic,ensure_ascii=False,indent=2),encoding='utf-8')
                    print('Verificação sem envios e sem alterações no histórico.',flush=True)
                print('Teste concluído. Sessão salva para uso no projeto; histórico não alterado.',flush=True)
                input('Confira as conversas no navegador. Pressione Enter aqui para fechar: ')
            finally:adapter.close()
            return
        cfg,rows=load_book(args.arquivo)
        print(f'Campanha: {cfg["campanha"]} | Selecionados: {len(rows)} | Modo: {args.modo}',flush=True)
        if args.modo=='enviar':
            print('Versão '+VERSION+' — permite revisar recebimentos incertos antes de retomar.')
            confirm=input('Envio REAL. Digite ENVIAR para iniciar: ').strip().upper()
            if confirm!='ENVIAR':
                print('Cancelado. Nenhuma mensagem enviada.');return
        run(cfg,rows,data,args.modo,transport_factory=lambda root, timeout: WhatsApp(root,timeout,session_timeout=args.tempo_sessao),manual_review=True)
        print('Finalizado. Atualize os resultados no Excel. Histórico em dados/historico.csv.')
    finally:
        lock.close()

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Interrompido. Confira itens incertos no histórico.');sys.exit(130)
    except Exception as e:print(f'ERRO: {e}',file=sys.stderr);sys.exit(1)
    finally:
        if '--pausar' in sys.argv:
            try:input('Pressione Enter para fechar...')
            except (EOFError,KeyboardInterrupt):pass
