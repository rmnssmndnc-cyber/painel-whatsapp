"""Importação, validação e execução do Painel WhatsApp. Somente biblioteca padrão."""
from __future__ import annotations
import csv
import base64
import subprocess
import sys
import hashlib
import io
import json
import os
import posixpath
import re
import sqlite3
import unicodedata
import uuid
import zipfile
from collections import Counter
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET

import motor_whatsapp as motor

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'dados'
COLUMNS = ('nome', 'telefone')


def create_desktop_shortcut(root=ROOT):
    """Cria um .lnk no Desktop real do usuário, inclusive quando redirecionado."""
    if sys.platform != 'win32':
        raise RuntimeError('O atalho da Área de Trabalho está disponível no Windows.')
    root = Path(root).resolve()
    python = root / '.venv' / 'Scripts' / 'pythonw.exe'
    if not python.is_file():
        python = Path(sys.executable).with_name('pythonw.exe')
    if not python.is_file() or not (root / 'painel.py').is_file():
        raise RuntimeError('Não encontrei pythonw.exe ou painel.py. Mantenha o painel na pasta do projeto.')
    def literal(value):
        return "'" + str(value).replace("'", "''") + "'"
    script = """$ErrorActionPreference = 'Stop'
$shell = New-Object -ComObject WScript.Shell
$desktop = $shell.SpecialFolders.Item('Desktop')
if (-not $desktop -or -not (Test-Path -LiteralPath $desktop)) { throw 'Area de Trabalho nao encontrada.' }
$path = Join-Path $desktop 'Painel WhatsApp.lnk'
$link = $shell.CreateShortcut($path)
"""
    script += '$target = ' + literal(python) + '\n'
    script += '$arguments = ' + literal('"' + str(root / 'painel.py') + '"') + '\n'
    script += """if ((Test-Path -LiteralPath $path) -and ($link.Description -ne 'Painel WhatsApp - abrir painel')) {
    throw 'Ja existe outro atalho chamado Painel WhatsApp. Renomeie esse atalho e tente novamente.'
}
$link.TargetPath = $target
$link.Arguments = $arguments
"""
    script += '$link.WorkingDirectory = ' + literal(root) + '\n'
    script += """$link.Description = 'Painel WhatsApp - abrir painel'
$link.IconLocation = $target + ',0'
$link.WindowStyle = 1
$link.Save()
if (-not (Test-Path -LiteralPath $path)) { throw 'O atalho nao foi salvo.' }
"""
    powershell = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32' / 'WindowsPowerShell' / 'v1.0' / 'powershell.exe'
    encoded = base64.b64encode(script.encode('utf-16le')).decode('ascii')
    result = subprocess.run([str(powershell), '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded],
                            capture_output=True, timeout=20, creationflags=0x08000000)
    if result.returncode:
        raise RuntimeError('O Windows não conseguiu criar o atalho. Confira se a Área de Trabalho permite salvar arquivos e se já existe um atalho com esse nome.')
    return 'Painel WhatsApp'

NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
ALIASES = {
    'nome': {'nome', 'nome completo', 'contato', 'cliente', 'name'},
    'telefone': {'telefone', 'celular', 'whatsapp', 'numero', 'phone', 'telefone 1'},
}


def stamp():
    return datetime.now().astimezone().isoformat(timespec='seconds')


def new_draft():
    return {'id': 'PAINEL-' + uuid.uuid4().hex[:16].upper(), 'nome': 'Minha campanha',
            'mensagem': '', 'intervalo': 5, 'confirmacao': 60, 'contatos': [], 'anexos': []}


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


@contextmanager
def execution_lock(data=DATA, name='execucao.lock'):
    """Mesmo bloqueio do projeto Excel: uma execução por vez na pasta dados."""
    data = Path(data)
    data.mkdir(parents=True, exist_ok=True)
    handle = (data / name).open('a+b')
    try:
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise ValueError('Já existe uma execução aberta. Aguarde sua conclusão.') from exc
        yield
    finally:
        handle.close()


def normalize_header(value):
    return ''.join(c for c in unicodedata.normalize('NFD', str(value))
                   if unicodedata.category(c) != 'Mn').strip().lower().replace('_', ' ')


def suggested_mapping(matrix):
    first = [normalize_header(c) for c in (matrix[0] if matrix else [])]
    mapping = {key: next((i for i, v in enumerate(first) if v in names), None)
               for key, names in ALIASES.items()}
    header = mapping['nome'] is not None and mapping['telefone'] is not None
    if not header:
        width = max((len(row) for row in matrix), default=0)
        mapping = {key: i if i < width else None for i, key in enumerate(COLUMNS)}
    return header, mapping


def map_contacts(matrix, mapping, header=True):
    if mapping.get('nome') is None or mapping.get('telefone') is None:
        raise ValueError('Escolha as colunas Nome e Telefone.')
    selected = [i for i in mapping.values() if i is not None]
    if len(selected) != len(set(selected)):
        raise ValueError('Cada campo deve usar uma coluna diferente.')
    result = []
    for source in matrix[1 if header else 0:]:
        row = {key: str(source[i]).strip() if i is not None and i < len(source) else ''
               for key, i in mapping.items()}
        if not any(row.values()):
            continue
        result.append({key: row.get(key, '') for key in COLUMNS})
    if len(result) > 1000:
        raise ValueError('Importe no máximo 1.000 contatos por campanha.')
    return result


def parse_text(text):
    if len(text) > 4_000_000:
        raise ValueError('Conteúdo muito grande. Importe até 1.000 contatos.')
    try:
        dialect = csv.Sniffer().sniff(text[:16000], delimiters='\t;,')
        rows = list(csv.reader(io.StringIO(text), dialect))
    except csv.Error:
        rows = list(csv.reader(io.StringIO(text), delimiter='\t'))
    return [r for r in rows if any(v.strip() for v in r)]


def file_matrix(path, sheet=None):
    path = Path(path)
    if path.suffix.lower() in ('.csv', '.tsv', '.txt'):
        raw = path.read_bytes()
        try: text = raw.decode('utf-8-sig')
        except UnicodeDecodeError: text = raw.decode('cp1252')
        return parse_text(text)
    if path.suffix.lower() not in ('.xlsx', '.xlsm'):
        raise ValueError('Use XLSX, XLSM ou CSV. Para XLS antigo, copie e cole as células.')
    with zipfile.ZipFile(path) as z:
        if sum(i.file_size for i in z.infolist()) > 100 * 1024 * 1024:
            raise ValueError('Planilha muito grande. Copie apenas os contatos necessários.')
        book = ET.fromstring(z.read('xl/workbook.xml'))
        sheets = book.find('s:sheets', NS)
        names = [s.get('name') for s in sheets]
        if sheet is None:
            return names
        target_sheet = next((s for s in sheets if s.get('name') == sheet), None)
        if target_sheet is None:
            raise ValueError('Aba não encontrada.')
        rel_id = target_sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        relations = {e.get('Id'): e.get('Target') for e in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        target = relations[rel_id]
        member = target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/' + target)
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            shared = [''.join(t.text or '' for t in si.findall('.//s:t', NS))
                      for si in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        matrix = []
        for r in ET.fromstring(z.read(member)).findall('s:sheetData/s:row', NS):
            values = {}
            for cell in r.findall('s:c', NS):
                letters = re.match(r'[A-Z]+', cell.get('r', ''))
                if not letters: continue
                col = 0
                for letter in letters[0]: col = col * 26 + ord(letter) - 64
                if col > 100: continue
                raw = cell.findtext('s:v', '', NS)
                typ = cell.get('t')
                if typ == 's': value = shared[int(raw)]
                elif typ == 'inlineStr': value = ''.join(t.text or '' for t in cell.findall('.//s:t', NS))
                else: value = raw
                if cell.find('s:f', NS) is not None and not raw:
                    raise ValueError('Há fórmula sem valor salvo. Copie e cole os valores dessa aba.')
                if typ == 'e': raise ValueError('Há célula com erro na aba. Corrija antes de importar.')
                if value: values[col - 1] = value
            if values:
                matrix.append([values.get(i, '') for i in range(max(values) + 1)])
            if len(matrix) > 1001:
                raise ValueError('A aba tem mais de 1.000 linhas de dados. Copie somente a lista desejada.')
        return matrix


def normalize_phone(raw):
    value = str(raw).strip()
    # Aceita números inteiros salvos com .0, mas nunca notação científica arredondada.
    if re.fullmatch(r'\d{10,15}\.0+', value): value = value.split('.')[0]
    if not value.startswith('+') and re.fullmatch(r'[\d\s().-]+', value):
        digits = re.sub(r'\D', '', value)
        if len(digits) in (10, 11): value = '55' + digits
    return motor.phone(value)


def stage_attachment(source, data=DATA):
    source = Path(source)
    if source.suffix.lower() not in ('.jpg', '.jpeg', '.png', '.pdf'):
        raise ValueError('Escolha JPG, PNG ou PDF.')
    if not source.is_file() or not 0 < source.stat().st_size <= 15 * 1024 * 1024:
        raise ValueError('O arquivo deve existir e ter entre 1 byte e 15 MB.')
    content = source.read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    dest = Path(data) / 'arquivos_painel' / digest / source.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        temp = dest.with_name(uuid.uuid4().hex + '.tmp')
        temp.write_bytes(content); os.replace(temp, dest)
    if hashlib.sha256(dest.read_bytes()).hexdigest() != digest:
        raise ValueError('A cópia do anexo foi alterada. Selecione novamente o arquivo original.')
    return str(dest.resolve())


def prepare(draft):
    campaign = str(draft.get('id', '')).strip()
    if not campaign or len(campaign) > 100:
        raise ValueError('Campanha inválida.')
    interval, timeout = int(draft['intervalo']), int(draft['confirmacao'])
    if not 1 <= interval <= 3600 or not 10 <= timeout <= 180:
        raise ValueError('Intervalo: 1 a 3.600 segundos. Confirmação: 10 a 180 segundos.')
    attachments = draft.get('anexos', [])
    if len(attachments) > 8:
        raise ValueError('Use até oito anexos por campanha.')
    if any('|' in p for p in attachments): raise ValueError('O caminho do anexo não pode conter |.')
    cfg = {'campanha': campaign, 'modelo': str(draft.get('mensagem', '')),
           'anexos_comuns': '|'.join(attachments), 'intervalo_segundos': interval,
           'tempo_confirmacao': timeout, 'limite_contatos': 1000}
    raw_rows = draft.get('contatos', [])
    if not 1 <= len(raw_rows) <= 1000:
        raise ValueError('Adicione de 1 a 1.000 contatos à lista.')
    rows, seen = [], set()
    for i, raw in enumerate(raw_rows, 1):
        row = {key: str(raw.get(key, '')).strip() for key in COLUMNS}
        try:
            if not row['nome']: raise ValueError('Nome vazio.')
            row['telefone'] = normalize_phone(row['telefone'])
            if row['telefone'] in seen: raise ValueError('Telefone duplicado nesta lista.')
            seen.add(row['telefone'])
            # A lista exibida é a lista de destinatários que o operador escolheu enviar.
            row.update({'selecionar': 'SIM', 'autorizado': 'SIM', 'anexos': ''})
            motor.items_for(cfg, row, ROOT)
        except (ValueError, KeyError) as exc:
            raise ValueError(f'Linha {i} ({row["nome"] or "sem nome"}): {exc}') from exc
        rows.append(row)
    return cfg, rows


def result_summary(cfg, rows, report, data, mode):
    counts = Counter(r[6] for r in report)
    planned = sum(len(motor.items_for(cfg, row, ROOT)) for row in rows)
    delivered = sent = uncertain = pending = simulated = 0
    contacts_done = 0
    if mode == 'simular':
        simulated = counts.get('SIMULADO', 0)
    else:
        h = motor.History(Path(data) / 'historico.sqlite3')
        try:
            for row in rows:
                done = True
                for i, (kind, _) in enumerate(motor.items_for(cfg, row, ROOT)):
                    state = h.state(cfg['campanha'], row['telefone'], f'{i:02d}-{kind}')
                    status = state[0] if state else ''
                    if status == 'ENTREGUE': delivered += 1
                    elif status == 'ENVIADO': sent += 1
                    elif status == 'INCERTO': uncertain += 1; done = False
                    else: pending += 1; done = False
                contacts_done += int(done)
        finally: h.db.close()
    return {'modo': mode, 'contatos': len(rows), 'itens_previstos': planned,
            'entregues_no_historico': delivered, 'enviados_no_historico': sent,
            'incertos': uncertain, 'pendentes': pending, 'simulados': simulated,
            'contatos_processados': contacts_done, 'ocorrencias_desta_execucao': dict(counts),
            'parado': (Path(data) / 'PARAR').exists()}


def execute(draft, mode, data=DATA, transport_factory=motor.WhatsApp, reset_stop=True):
    if mode not in ('simular', 'enviar'): raise ValueError('Modo inválido.')
    cfg, rows = prepare(draft)  # Valida o lote inteiro antes de qualquer envio.
    with execution_lock(data):
        if reset_stop:
            (Path(data) / 'PARAR').unlink(missing_ok=True)
        print(f'Campanha: {draft.get("nome", "")} | Código: {cfg["campanha"]}', flush=True)
        print(f'Contatos: {len(rows)} | Modo: {mode} | Intervalo: {cfg["intervalo_segundos"]}s', flush=True)
        print('Todos os contatos da lista entram no lote. Não há confirmação por teclado.', flush=True)
        report = motor.run(cfg, rows, Path(data), mode, transport_factory=transport_factory, manual_review=False)
        summary = result_summary(cfg, rows, report, data, mode)
        print('\n========== RESULTADO FINAL ==========', flush=True)
        for key, label in [('contatos', 'Contatos da lista'), ('itens_previstos', 'Itens previstos'),
                           ('simulados', 'Itens simulados'), ('entregues_no_historico', 'Itens entregues na campanha'),
                           ('enviados_no_historico', 'Itens enviados, entrega ainda não confirmada'),
                           ('incertos', 'Itens incertos'), ('pendentes', 'Itens pendentes')]:
            print(f'{label}: {summary[key]}', flush=True)
        print('Ocorrências desta execução: ' + str(summary['ocorrencias_desta_execucao']), flush=True)
        if summary['parado']: print('Parada solicitada pelo operador.', flush=True)
        if summary['incertos']: print('Resultado incerto: confira a conversa. Use Revisar pendências no painel.', flush=True)
        print('Histórico preservado em dados/historico.csv.', flush=True)
        return summary


def uncertain_items(campaign, data=DATA):
    path = Path(data) / 'historico.sqlite3'
    if not path.exists(): return []
    with sqlite3.connect(path) as db:
        rows = db.execute('SELECT phone,item,time,reason FROM items WHERE campaign=? AND status=?',
                          (campaign, 'INCERTO')).fetchall()
        wanted = {(r[0], r[1]) for r in rows}
        contents = {}
        for (data_json,) in db.execute('SELECT data FROM events ORDER BY rowid DESC'):
            record = json.loads(data_json)
            key = (record[4], record[5])
            if record[1] == campaign and key in wanted and key not in contents and record[6] == 'INCERTO':
                contents[key] = record[8]
            if len(contents) == len(wanted): break
        return [(*r, contents.get((r[0], r[1]), 'Consulte o histórico da tentativa.')) for r in rows]


def review_item(campaign, phone, item, action, data=DATA):
    with execution_lock(data):
        h = motor.History(Path(data) / 'historico.sqlite3')
        try:
            if action == 'recebido': h.confirm_received(campaign, phone, item)
            elif action == 'retomar': h.release_before_send(campaign, phone, item)
            else: raise ValueError('Ação inválida.')
            motor.export_csv(Path(data) / 'historico.csv', [json.loads(r[0]) for r in h.db.execute('SELECT data FROM events')])
        finally: h.db.close()
