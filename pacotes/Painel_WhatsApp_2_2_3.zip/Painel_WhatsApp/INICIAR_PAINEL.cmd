@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Coloque os arquivos do painel na pasta original do projeto,
  echo junto da pasta .venv, app.py e dados.
  echo Nao precisa reinstalar o projeto.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" "%~dp0painel.py"
if errorlevel 1 pause
