"""Painel WhatsApp. IA opcional usa PyJWT/cryptography para validar identidade."""
from __future__ import annotations
import csv
import base64
import subprocess
import sys
import hashlib
import io
import json
import os
import posixpath
import re
import sqlite3
import unicodedata
import uuid
import zipfile
from collections import Counter
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET

import motor_whatsapp as motor

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'dados'
COLUMNS = ('nome', 'telefone')


NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
ALIASES = {
    'nome': {'nome', 'nome completo', 'contato', 'cliente', 'name'},
    'telefone': {'telefone', 'celular', 'whatsapp', 'numero', 'phone', 'telefone 1'},
}


def stamp():
    return datetime.now().astimezone().isoformat(timespec='seconds')


def new_draft():
    return {'id': 'PAINEL-' + uuid.uuid4().hex[:16].upper(), 'nome': 'Minha campanha',
            'mensagem': '', 'intervalo': 5, 'confirmacao': 60, 'contatos': [], 'anexos': []}


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
        # Windows may briefly deny replacement while another process reads the
        # destination. Keep the previous complete JSON until replacement succeeds.
        for attempt in range(9):
            try:
                os.replace(tmp, path)
                break
            except OSError as exc:
                if not (isinstance(exc, PermissionError) or
                        getattr(exc, 'winerror', None) in (5, 32, 33)):
                    raise
                if attempt == 8:
                    raise PermissionError(
                        f'Não foi possível atualizar {path.name}: o arquivo continua '
                        'bloqueado ou sem permissão de escrita após várias tentativas. '
                        'Feche outras janelas do painel e tente novamente.'
                    ) from exc
                time.sleep(min(0.1 * 2 ** attempt, 0.8))
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            # A cleanup failure must not hide the actual write error.
            pass


@contextmanager
def execution_lock(data=DATA, name='execucao.lock'):
    """Mesmo bloqueio do projeto Excel: uma execução por vez na pasta dados."""
    data = Path(data)
    data.mkdir(parents=True, exist_ok=True)
    handle = (data / name).open('a+b')
    try:
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise ValueError('Já existe uma execução aberta. Aguarde sua conclusão.') from exc
        yield
    finally:
        handle.close()


def normalize_header(value):
    return ''.join(c for c in unicodedata.normalize('NFD', str(value))
                   if unicodedata.category(c) != 'Mn').strip().lower().replace('_', ' ')


def suggested_mapping(matrix):
    first = [normalize_header(c) for c in (matrix[0] if matrix else [])]
    mapping = {key: next((i for i, v in enumerate(first) if v in names), None)
               for key, names in ALIASES.items()}
    header = mapping['nome'] is not None and mapping['telefone'] is not None
    if not header:
        width = max((len(row) for row in matrix), default=0)
        mapping = {key: i if i < width else None for i, key in enumerate(COLUMNS)}
    return header, mapping


def map_contacts(matrix, mapping, header=True):
    if mapping.get('nome') is None or mapping.get('telefone') is None:
        raise ValueError('Escolha as colunas Nome e Telefone.')
    selected = [i for i in mapping.values() if i is not None]
    if len(selected) != len(set(selected)):
        raise ValueError('Cada campo deve usar uma coluna diferente.')
    result = []
    for source in matrix[1 if header else 0:]:
        row = {key: str(source[i]).strip() if i is not None and i < len(source) else ''
               for key, i in mapping.items()}
        if not any(row.values()):
            continue
        result.append({key: row.get(key, '') for key in COLUMNS})
    if len(result) > 1000:
        raise ValueError('Importe no máximo 1.000 contatos por campanha.')
    return result


def parse_text(text):
    if len(text) > 4_000_000:
        raise ValueError('Conteúdo muito grande. Importe até 1.000 contatos.')
    try:
        dialect = csv.Sniffer().sniff(text[:16000], delimiters='\t;,')
        rows = list(csv.reader(io.StringIO(text), dialect))
    except csv.Error:
        rows = list(csv.reader(io.StringIO(text), delimiter='\t'))
    return [r for r in rows if any(v.strip() for v in r)]


def file_matrix(path, sheet=None):
    path = Path(path)
    if path.suffix.lower() in ('.csv', '.tsv', '.txt'):
        raw = path.read_bytes()
        try: text = raw.decode('utf-8-sig')
        except UnicodeDecodeError: text = raw.decode('cp1252')
        return parse_text(text)
    if path.suffix.lower() not in ('.xlsx', '.xlsm'):
        raise ValueError('Use XLSX, XLSM ou CSV. Para XLS antigo, copie e cole as células.')
    with zipfile.ZipFile(path) as z:
        if sum(i.file_size for i in z.infolist()) > 100 * 1024 * 1024:
            raise ValueError('Planilha muito grande. Copie apenas os contatos necessários.')
        book = ET.fromstring(z.read('xl/workbook.xml'))
        sheets = book.find('s:sheets', NS)
        names = [s.get('name') for s in sheets]
        if sheet is None:
            return names
        target_sheet = next((s for s in sheets if s.get('name') == sheet), None)
        if target_sheet is None:
            raise ValueError('Aba não encontrada.')
        rel_id = target_sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        relations = {e.get('Id'): e.get('Target') for e in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        target = relations[rel_id]
        member = target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/' + target)
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            shared = [''.join(t.text or '' for t in si.findall('.//s:t', NS))
                      for si in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        matrix = []
        for r in ET.fromstring(z.read(member)).findall('s:sheetData/s:row', NS):
            values = {}
            for cell in r.findall('s:c', NS):
                letters = re.match(r'[A-Z]+', cell.get('r', ''))
                if not letters: continue
                col = 0
                for letter in letters[0]: col = col * 26 + ord(letter) - 64
                if col > 100: continue
                raw = cell.findtext('s:v', '', NS)
                typ = cell.get('t')
                if typ == 's': value = shared[int(raw)]
                elif typ == 'inlineStr': value = ''.join(t.text or '' for t in cell.findall('.//s:t', NS))
                else: value = raw
                if cell.find('s:f', NS) is not None and not raw:
                    raise ValueError('Há fórmula sem valor salvo. Copie e cole os valores dessa aba.')
                if typ == 'e': raise ValueError('Há célula com erro na aba. Corrija antes de importar.')
                if value: values[col - 1] = value
            if values:
                matrix.append([values.get(i, '') for i in range(max(values) + 1)])
            if len(matrix) > 1001:
                raise ValueError('A aba tem mais de 1.000 linhas de dados. Copie somente a lista desejada.')
        return matrix


def normalize_phone(raw):
    value = str(raw).strip()
    # Aceita números inteiros salvos com .0, mas nunca notação científica arredondada.
    if re.fullmatch(r'\d{10,15}\.0+', value): value = value.split('.')[0]
    if not value.startswith('+') and re.fullmatch(r'[\d\s().-]+', value):
        digits = re.sub(r'\D', '', value)
        if len(digits) in (10, 11): value = '55' + digits
    return motor.phone(value)


def stage_attachment(source, data=DATA):
    source = Path(source)
    if source.suffix.lower() not in ('.jpg', '.jpeg', '.png', '.pdf'):
        raise ValueError('Escolha JPG, PNG ou PDF.')
    if not source.is_file() or not 0 < source.stat().st_size <= 15 * 1024 * 1024:
        raise ValueError('O arquivo deve existir e ter entre 1 byte e 15 MB.')
    content = source.read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    dest = Path(data) / 'arquivos_painel' / digest / source.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        temp = dest.with_name(uuid.uuid4().hex + '.tmp')
        temp.write_bytes(content); os.replace(temp, dest)
    if hashlib.sha256(dest.read_bytes()).hexdigest() != digest:
        raise ValueError('A cópia do anexo foi alterada. Selecione novamente o arquivo original.')
    return str(dest.resolve())


def prepare(draft):
    campaign = str(draft.get('id', '')).strip()
    if not campaign or len(campaign) > 100:
        raise ValueError('Campanha inválida.')
    interval, timeout = int(draft['intervalo']), int(draft['confirmacao'])
    if not 1 <= interval <= 3600 or not 10 <= timeout <= 180:
        raise ValueError('Intervalo: 1 a 3.600 segundos. Confirmação: 10 a 180 segundos.')
    attachments = draft.get('anexos', [])
    if len(attachments) > 8:
        raise ValueError('Use até oito anexos por campanha.')
    if any('|' in p for p in attachments): raise ValueError('O caminho do anexo não pode conter |.')
    cfg = {'campanha': campaign, 'modelo': str(draft.get('mensagem', '')),
           'anexos_comuns': '|'.join(attachments), 'intervalo_segundos': interval,
           'tempo_confirmacao': timeout, 'limite_contatos': 1000}
    raw_rows = draft.get('contatos', [])
    if not 1 <= len(raw_rows) <= 1000:
        raise ValueError('Adicione de 1 a 1.000 contatos à lista.')
    rows, seen = [], set()
    for i, raw in enumerate(raw_rows, 1):
        row = {key: str(raw.get(key, '')).strip() for key in COLUMNS}
        try:
            if not row['nome']: raise ValueError('Nome vazio.')
            row['telefone'] = normalize_phone(row['telefone'])
            if row['telefone'] in seen: raise ValueError('Telefone duplicado nesta lista.')
            seen.add(row['telefone'])
            # A lista exibida é a lista de destinatários que o operador escolheu enviar.
            row.update({'selecionar': 'SIM', 'autorizado': 'SIM', 'anexos': ''})
            motor.items_for(cfg, row, ROOT)
        except (ValueError, KeyError) as exc:
            raise ValueError(f'Linha {i} ({row["nome"] or "sem nome"}): {exc}') from exc
        rows.append(row)
    return cfg, rows


def result_summary(cfg, rows, report, data, mode):
    counts = Counter(r[6] for r in report)
    planned = sum(len(motor.items_for(cfg, row, ROOT)) for row in rows)
    delivered = sent = uncertain = pending = simulated = 0
    contacts_done = 0
    if mode == 'simular':
        simulated = counts.get('SIMULADO', 0)
    else:
        h = motor.History(Path(data) / 'historico.sqlite3')
        try:
            for row in rows:
                done = True
                for i, (kind, _) in enumerate(motor.items_for(cfg, row, ROOT)):
                    state = h.state(cfg['campanha'], row['telefone'], f'{i:02d}-{kind}')
                    status = state[0] if state else ''
                    if status == 'ENTREGUE': delivered += 1
                    elif status == 'ENVIADO': sent += 1
                    elif status == 'INCERTO': uncertain += 1; done = False
                    else: pending += 1; done = False
                contacts_done += int(done)
        finally: h.db.close()
    return {'modo': mode, 'contatos': len(rows), 'itens_previstos': planned,
            'entregues_no_historico': delivered, 'enviados_no_historico': sent,
            'incertos': uncertain, 'pendentes': pending, 'simulados': simulated,
            'contatos_processados': contacts_done, 'ocorrencias_desta_execucao': dict(counts),
            'parado': (Path(data) / 'PARAR').exists()}


def execute(draft, mode, data=DATA, transport_factory=motor.WhatsApp, reset_stop=True):
    if mode not in ('simular', 'enviar'): raise ValueError('Modo inválido.')
    cfg, rows = prepare(draft)  # Valida o lote inteiro antes de qualquer envio.
    with execution_lock(data):
        if reset_stop:
            (Path(data) / 'PARAR').unlink(missing_ok=True)
        print(f'Campanha: {draft.get("nome", "")} | Código: {cfg["campanha"]}', flush=True)
        print(f'Contatos: {len(rows)} | Modo: {mode} | Intervalo: {cfg["intervalo_segundos"]}s', flush=True)
        print('Todos os contatos da lista entram no lote. Não há confirmação por teclado.', flush=True)
        report = motor.run(cfg, rows, Path(data), mode, transport_factory=transport_factory, manual_review=False)
        summary = result_summary(cfg, rows, report, data, mode)
        print('\n========== RESULTADO FINAL ==========', flush=True)
        for key, label in [('contatos', 'Contatos da lista'), ('itens_previstos', 'Itens previstos'),
                           ('simulados', 'Itens simulados'), ('entregues_no_historico', 'Itens entregues na campanha'),
                           ('enviados_no_historico', 'Itens enviados, entrega ainda não confirmada'),
                           ('incertos', 'Itens incertos'), ('pendentes', 'Itens pendentes')]:
            print(f'{label}: {summary[key]}', flush=True)
        print('Ocorrências desta execução: ' + str(summary['ocorrencias_desta_execucao']), flush=True)
        if summary['parado']: print('Parada solicitada pelo operador.', flush=True)
        if summary['incertos']: print('Resultado incerto: confira a conversa. Use Revisar pendências no painel.', flush=True)
        print('Histórico preservado em dados/historico.csv.', flush=True)
        return summary


def uncertain_items(campaign, data=DATA):
    path = Path(data) / 'historico.sqlite3'
    if not path.exists(): return []
    with sqlite3.connect(path) as db:
        rows = db.execute('SELECT phone,item,time,reason FROM items WHERE campaign=? AND status=?',
                          (campaign, 'INCERTO')).fetchall()
        wanted = {(r[0], r[1]) for r in rows}
        contents = {}
        for (data_json,) in db.execute('SELECT data FROM events ORDER BY rowid DESC'):
            record = json.loads(data_json)
            key = (record[4], record[5])
            if record[1] == campaign and key in wanted and key not in contents and record[6] == 'INCERTO':
                contents[key] = record[8]
            if len(contents) == len(wanted): break
        return [(*r, contents.get((r[0], r[1]), 'Consulte o histórico da tentativa.')) for r in rows]


def review_item(campaign, phone, item, action, data=DATA):
    with execution_lock(data):
        h = motor.History(Path(data) / 'historico.sqlite3')
        try:
            if action == 'recebido': h.confirm_received(campaign, phone, item)
            elif action == 'retomar': h.release_before_send(campaign, phone, item)
            else: raise ValueError('Ação inválida.')
            motor.export_csv(Path(data) / 'historico.csv', [json.loads(r[0]) for r in h.db.execute('SELECT data FROM events')])
        finally: h.db.close()

# Integração opcional: OAuth oficial com uso do plano ChatGPT, sem chave de API.
# Tokens ficam apenas na memória desta janela. Registros persistem apenas IDs.
import secrets
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlencode, urlsplit, parse_qs
from urllib.request import Request, urlopen
from urllib.error import HTTPError

AI_AUTH = 'https://auth.openai.com'
AI_RESOURCE = 'https://api.openai.com/v1'
AI_SCOPES = 'openid profile email resource.invoke chatgpt.tokens.use.direct'


def ai_dependencies(install=False):
    try:
        import jwt
        from cryptography.hazmat.primitives.asymmetric import rsa
        return
    except ImportError:
        if not install:
            raise RuntimeError('Clique em Preparar conexão para instalar o componente de autenticação.')
    python = Path(sys.executable)
    if python.name.lower() == 'pythonw.exe':
        python = python.with_name('python.exe')
    result = subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check',
                             'PyJWT[crypto]==2.10.1'], capture_output=True, timeout=240,
                            creationflags=0x08000000 if sys.platform == 'win32' else 0)
    if result.returncode:
        raise RuntimeError('Não foi possível instalar o componente de autenticação. Confira a conexão com a internet.')
    import importlib
    importlib.invalidate_caches()
    ai_dependencies()


def ai_error(code):
    messages = {
        'subscription_sharing_usage_limit_exceeded': 'Limite do plano atingido. Confira o uso nas configurações do ChatGPT.',
        'subscription_sharing_usage_unavailable': 'Uso do plano indisponível. Confira a autorização e os limites no ChatGPT.',
        'subscription_sharing_unsupported_capability': 'Este recurso ou modelo não está disponível para esta integração.',
        'access_denied': 'Você não autorizou o uso do plano. Nenhuma análise foi feita.',
        'invalid_grant': 'A autorização expirou. Clique em Continuar com ChatGPT novamente.',
    }
    return messages.get(code, 'A OpenAI não concluiu a solicitação. Verifique a conexão, a autorização e os limites do plano.')


def ai_http(url, payload=None, token=None, form=False, stream=False):
    # Endpoints fixos; nunca aceita um endereço fornecido pelo modelo.
    parts = urlsplit(url)
    if parts.scheme != 'https' or parts.hostname not in ('auth.openai.com', 'api.openai.com'):
        raise ValueError('Endereço de autenticação não permitido.')
    headers = {'Accept': 'text/event-stream' if stream else 'application/json'}
    if token: headers['Authorization'] = 'Bearer ' + token
    data = None
    if payload is not None:
        data = (urlencode(payload) if form else json.dumps(payload)).encode()
        headers['Content-Type'] = 'application/x-www-form-urlencoded' if form else 'application/json'
    try:
        # Sem redirecionamento de credenciais para outros destinos.
        from urllib.request import build_opener, HTTPRedirectHandler
        class NoRedirect(HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs): return None
        response = build_opener(NoRedirect).open(Request(url, data=data, headers=headers), timeout=60)
        if stream: return response
        with response:
            return json.loads(response.read(4 * 1024 * 1024))
    except HTTPError as exc:
        try:
            value = json.loads(exc.read(8192)); error = value.get('error', {})
            code = error.get('code') if isinstance(error, dict) else error
        except Exception: code = ''
        raise RuntimeError(ai_error(code)) from None
    except (OSError, ValueError):
        raise RuntimeError('Não foi possível comunicar com a OpenAI. Confira a conexão e tente novamente.') from None


def ai_validate_identity(encoded, client_id, nonce, subject=None):
    ai_dependencies()
    import jwt
    try:
        key = jwt.PyJWKClient(AI_AUTH + '/.well-known/jwks.json', timeout=20).get_signing_key_from_jwt(encoded)
        claims = jwt.decode(encoded, key.key, algorithms=['RS256'], audience=client_id,
                            issuer=AI_AUTH, options={'require': ['exp', 'iss', 'aud', 'sub', 'nonce']})
        if not secrets.compare_digest(str(claims.get('nonce', '')), nonce):
            raise ValueError('nonce')
        if subject and claims['sub'] != subject: raise ValueError('subject')
        if claims.get('azp') and claims['azp'] != client_id: raise ValueError('azp')
        return claims
    except Exception:
        raise RuntimeError('Não foi possível validar a identidade da conta. A conexão não foi salva.') from None


def ai_callback_values(query, state, selected=None):
    values = parse_qs(query, keep_blank_values=True)
    if any(len(v) != 1 for v in values.values()): raise ValueError('Callback duplicado.')
    values = {k:v[0] for k,v in values.items()}
    if not secrets.compare_digest(values.get('state', ''), state): raise ValueError('Callback inválido.')
    if values.get('error'): raise RuntimeError(ai_error(values['error']))
    client = values.get('client_id') or selected
    if not client or client == 'dynamic_agent_client' or (selected and client != selected):
        raise ValueError('Registro de aplicativo inválido.')
    if not values.get('code'): raise ValueError('Código de autorização ausente.')
    return values['code'], client


def ai_stream_text(response):
    parts = []; data = []; size = 0; deadline = time.monotonic()+300
    def event(lines):
        if not lines: return None
        raw = '\n'.join(lines)
        if raw == '[DONE]': return None
        return json.loads(raw)
    with response:
        while True:
            if time.monotonic()>deadline: raise RuntimeError('A resposta demorou além do prazo. Tente novamente.')
            line = response.readline(1024 * 1024)
            if not line: break
            size += len(line)
            if size > 8 * 1024 * 1024: raise RuntimeError('Resposta excedeu o limite de leitura do painel.')
            line = line.decode('utf-8').rstrip('\r\n')
            if line.startswith('data:'): data.append(line[5:].lstrip())
            elif not line and data:
                value = event(data); data = []
                if not value: continue
                kind = value.get('type')
                if kind == 'response.output_text.delta': parts.append(value.get('delta', ''))
                elif kind == 'response.completed':
                    text = ''.join(parts).strip()
                    if not text: raise RuntimeError('A IA concluiu sem devolver texto.')
                    return text
                elif kind in ('response.failed', 'response.incomplete', 'error'):
                    error = value.get('response', {}).get('error') or value.get('error') or {}
                    raise RuntimeError(ai_error(error.get('code') if isinstance(error, dict) else ''))
    raise RuntimeError('Resposta interrompida. O painel não aplicou o texto parcial; tente novamente.')


class ChatGPTConnection:
    def __init__(self, data=DATA):
        self.path = Path(data)/'chatgpt_registros.json'
        self.saved = json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {
            'host_id': 'urn:uuid:'+str(uuid.uuid4()), 'accounts': []}
        self.credentials = None
        self.models = []
        # Sem tokens, emails, histórico de conversa ou contatos neste arquivo.
        atomic_json(self.path, self.saved)

    def login(self, selected=None, cancel=None):
        ai_dependencies()
        previous = next((a for a in self.saved['accounts'] if a['client_id']==selected), None)
        if selected and not previous: raise ValueError('Selecione uma conta registrada.')
        state = secrets.token_urlsafe(32); nonce = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
        result = {}; expires = time.monotonic()+240
        class Callback(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_GET(handler):
                parsed = urlsplit(handler.path)
                if parsed.path != '/auth/callback':
                    handler.send_error(404); return
                try:
                    result['value'] = ai_callback_values(parsed.query, state, selected)
                    status = 200; message = 'Autorizacao recebida. Volte ao Painel WhatsApp para conferir a conexao.'
                except ValueError:
                    status = 400; message = 'Retorno invalido. Continue pelo navegador usado para entrar.'
                except RuntimeError as exc:
                    result['error'] = str(exc); status = 400; message = 'Autorizacao nao concluida. Volte ao painel.'
                body = message.encode()
                handler.send_response(status); handler.send_header('Content-Type','text/plain; charset=utf-8')
                handler.send_header('Cache-Control','no-store'); handler.send_header('Content-Length',str(len(body)))
                handler.end_headers(); handler.wfile.write(body)
        with HTTPServer(('127.0.0.1',0),Callback) as server:
            server.timeout = .5
            # Limita clientes locais lentos que conectem sem terminar a requisição.
            original_get_request = server.get_request
            def get_request():
                sock, addr = original_get_request(); sock.settimeout(2); return sock, addr
            server.get_request = get_request
            redirect = f'http://127.0.0.1:{server.server_port}/auth/callback'
            query = {'client_id': selected or 'dynamic_agent_client', 'ext_agent_host_id':self.saved['host_id'],
                     'response_type':'code','redirect_uri':redirect,'scope':AI_SCOPES,'resource':AI_RESOURCE,
                     'state':state,'nonce':nonce,'code_challenge_method':'S256','code_challenge':challenge}
            if not selected: query['agent_name_hint']='Painel WhatsApp'
            if not webbrowser.open(AI_AUTH+'/api/accounts/authorize?'+urlencode(query)):
                raise RuntimeError('Não foi possível abrir o navegador para entrar no ChatGPT.')
            while not result and time.monotonic()<expires:
                if cancel and cancel.is_set(): raise RuntimeError('Conexão cancelada.')
                server.handle_request()
        if cancel and cancel.is_set(): raise RuntimeError('Conexão cancelada.')
        if not result: raise RuntimeError('O prazo para entrar terminou. Clique em Continuar com ChatGPT novamente.')
        if 'error' in result: raise RuntimeError(result['error'])
        code, client = result['value']
        tokens = ai_http(AI_AUTH+'/api/accounts/oauth/token', {
            'grant_type':'authorization_code','client_id':client,'code':code,
            'code_verifier':verifier,'redirect_uri':redirect,'resource':AI_RESOURCE}, form=True)
        claims = ai_validate_identity(tokens.get('id_token',''),client,nonce,previous['subject'] if previous else None)
        scopes = tokens.get('scope','').split()
        if not {'resource.invoke','chatgpt.tokens.use.direct'}.issubset(scopes):
            raise RuntimeError('O uso do plano não foi autorizado. Confira as permissões no ChatGPT e tente novamente.')
        if tokens.get('token_type','').lower()!='bearer' or not tokens.get('access_token'):
            raise RuntimeError('A OpenAI não retornou uma autorização utilizável.')
        record = {'client_id':client,'subject':claims['sub'], 'label':f'Conta {len(self.saved["accounts"])+1}'}
        if previous: record = previous
        else: self.saved['accounts'].append(record)
        atomic_json(self.path,self.saved)
        # Sem offline_access: exige novo login quando expira; não guarda tokens no disco.
        self.credentials = {'access_token':tokens['access_token'],'client_id':client,
                            'expires':time.time()+float(tokens.get('expires_in',3600)),
                            'label':record['label']}
        self.models=[]
        return record['label']

    def disconnect(self):
        self.credentials=None; self.models=[]

    def token(self):
        if not self.credentials or time.time()>=self.credentials['expires']-30:
            self.disconnect()
            raise RuntimeError('Clique em Continuar com ChatGPT para autorizar esta sessão.')
        return self.credentials['access_token']

    def list_models(self):
        catalog = ai_http(AI_RESOURCE+'/models', token=self.token())
        self.models = [m for m in catalog.get('models',[]) if m.get('visibility')=='list' and m.get('slug')]
        if not self.models: raise RuntimeError('Sua conta não retornou modelos disponíveis para esta integração.')
        return self.models

    def ask(self, model, instructions, prompt):
        if model not in {m['slug'] for m in self.models}: raise ValueError('Selecione um modelo disponível na sua conta.')
        if not prompt.strip() or len(prompt)>30000: raise ValueError('Use um pedido de até 30.000 caracteres.')
        response = ai_http(AI_RESOURCE+'/responses', token=self.token(), stream=True, payload={
            'model':model, 'instructions':instructions,
            'input':[{'role':'user','content':prompt}], 'store':False,'stream':True})
        return ai_stream_text(response)


def ai_campaign_diagnostic(campaign, data=DATA):
    # Só contagens e categorias pré-definidas. Nunca envia CSV, nomes, números,
    # mensagens, caminhos locais, anexos ou credenciais para a IA.
    path=Path(data)/'historico.csv'; states=Counter(); categories=Counter(); total=0
    if path.exists():
        with path.open(encoding='utf-8-sig',newline='') as handle:
            sample=handle.read(4096);handle.seek(0)
            try: dialect=csv.Sniffer().sniff(sample,delimiters=';,\t')
            except csv.Error: dialect=csv.excel
            for row in csv.DictReader(handle,dialect=dialect):
                if row.get('campanha')!=campaign: continue
                total+=1
                status=row.get('status','')
                states[status if status in {'ENTREGUE','ENVIADO','FALHA','INCERTO','SIMULADO','JA_PROCESSADO','BLOQUEADO','INVALIDO','CONFLITO','RETOMADA_AUTORIZADA'} else 'OUTRO']+=1
                if status not in ('FALHA','INCERTO','INVALIDO','BLOQUEADO','CONFLITO'): continue
                reason=row.get('motivo','').lower()
                if 'inválido' in reason or 'sem conta' in reason: category='numero_recusado'
                elif 'sessão' in reason or 'sessao' in reason: category='sessao'
                elif 'conversa' in reason: category='abertura_conversa'
                elif 'antes_do_envio' in reason: category='falha_antes_envio'
                elif 'tique' in reason or 'confirmação' in reason: category='confirmacao_incerta'
                elif 'timeout' in reason: category='prazo_esgotado'
                else: category='outra_falha'
                categories[category]+=1
    return json.dumps({'registros_da_campanha':total,'eventos_por_status':dict(states),
                       'categorias_de_falha':dict(categories),
                       'observacao':'Contagens de eventos históricos, não de pessoas ou de situação atual. Envios manuais não são detectados.'},ensure_ascii=False,indent=2)

# Exportação de grupo: somente DOM visível selecionado pelo operador.
GROUP_SELECT_JS = r"""() => {
  if(window.__painelGrupo?.cleanup) window.__painelGrupo.cleanup();
  const state={selected:false,error:'',root:null,scroll:null,selector:null};
  window.__painelGrupo=state;
  const banner=document.createElement('div');
  banner.textContent='PAINEL: clique em um participante da lista aberta. Nenhuma mensagem será enviada.';
  Object.assign(banner.style,{position:'fixed',bottom:'8px',left:'15%',width:'70%',padding:'14px',background:'#123f32',color:'white',zIndex:2147483647,font:'16px sans-serif',borderRadius:'8px',pointerEvents:'none'});
  document.body.appendChild(banner);
  const selectors=['[role="listitem"]','[role="row"]','[data-testid="contact-list-item"]'];
  const visible=n=>{const r=n.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(n).visibility!=='hidden'};
  const select=e=>{
    if(!(e.target instanceof Element))return;
    const dialog=e.target.closest('[role="dialog"][aria-label="Pesquisar membros"]');
    if(dialog&&dialog.querySelector('input')?.value.trim()){
      state.error='Apague o texto da pesquisa para ler a lista completa de membros.';return;
    }
    let memberList=null;
    for(let n=e.target,i=0;n&&i<24;n=n.parentElement,i++){
      if(/^(lista de membros|lista de participantes|member list|members list|participants list)\s*:/i.test(n.getAttribute('aria-label')||'')){memberList=n;break;}
    }
    if(e.target.closest('[data-id],.message-in,.message-out')||(!memberList&&!dialog&&e.target.closest('#side,#pane-side'))){state.error='Abra os dados do grupo e a lista de participantes. Não marque uma conversa nem uma mensagem.';return;}
    if(e.target.closest('header,input,textarea,button,[role=\"textbox\"]'))return;
    const label=(e.target.closest('[role=\"button\"]')?.innerText||'').trim();
    if(/^(ver todos|ver tudo|mostrar todos|view all|see all|pesquisar|search|adicionar|add participants)/i.test(label))return;
    let row=null,selector=null;
    for(const s of selectors){const candidate=e.target.closest(s);if(candidate&&visible(candidate)){row=candidate;selector=s;break;}}
    if(!row){state.error='Linha de participante não reconhecida. Abra a lista completa de participantes e tente novamente.';return;}
    if(!row.querySelector('[data-testid="cell-frame-title"]')){
      state.error='A linha selecionada não tem o título de um participante.';return;
    }
    // Group details can be inside #main. Require group-specific visible markers,
    // instead of rejecting the whole main area or accepting its message list.
    let panel=dialog|| (memberList ? (memberList.closest('[role="dialog"]')||memberList.closest('[data-testid="drawer-right"]')||memberList.closest('[role="complementary"]')||memberList.closest('[data-testid="chat-info-drawer"]')||memberList.closest('#pane-side')||memberList.parentElement) : null);
    let markers=dialog ? [dialog] : memberList ? [memberList] : null;
    for(let p=row.parentElement,i=0;!panel&&p&&i<24;p=p.parentElement,i++){
      if(p===document.body||p===document.documentElement||p.id==='app'||p.querySelector('#side,#pane-side'))break;
      const nodes=Array.from(p.querySelectorAll('header,h1,h2,h3,[role="heading"],span,div'))
        .filter(n=>visible(n)&&!n.closest('[role="listitem"],[role="row"],[data-id],.message-in,.message-out'));
      const heading=nodes.find(n=>/^(dados do grupo|group info|group information)$/i.test((n.textContent||'').trim()));
      const count=nodes.find(n=>/^\d[\d., ]*\s+(membros|participantes|members|participants)$/i.test((n.textContent||'').trim()));
      if(heading&&count){panel=p;markers=[heading,count];break;}
    }
    if(!panel){state.error='Não reconheci os dados do grupo e a contagem de membros junto desta lista. Deixe ambos visíveis e tente novamente.';return;}
    const rr=row.getBoundingClientRect();
    if(rr.width<160||rr.height<25||rr.height>200){state.error='Selecione uma única linha de participante.';return;}
    // A list wrapper may have overflow:auto but no scroll range. The actual
    // viewport may be an ancestor outside #pane-side, inside the group drawer.
    let scroll=null,p=row.parentElement;
    for(let i=0;p&&i<24;i++,p=p.parentElement){
      if(!panel.contains(p))break;
      if(p.id==='side'||p===document.body||p===document.documentElement)break;
      const style=getComputedStyle(p);
      if(p.clientHeight>30&&p.scrollHeight>p.clientHeight+3&&/(auto|scroll)/.test(style.overflowY)){
        scroll=p;break;
      }
    }
    if(!scroll)scroll=memberList||row.closest('[role="list"],[role="grid"]')||row.parentElement;
    // A verified group drawer may contain the inner #pane-side member wrapper.
    if(scroll.querySelector('#side')||scroll.querySelector('.message-in,.message-out')){state.error='Seleção muito ampla. Abra somente a lista de participantes.';return;}
    e.preventDefault();e.stopImmediatePropagation();
    state.panel=panel;state.markers=markers;
    state.root=memberList||scroll;state.scroll=scroll;state.selector=selector;state.selected=true;state.error='';
    state.cleanup();scroll.scrollTop=0;
  };
  state.cleanup=()=>{document.removeEventListener('click',select,true);banner.remove()};
  document.addEventListener('click',select,true);
  return true;
}"""

GROUP_READ_JS = r"""(advance) => {
  const s=window.__painelGrupo;
  if(!s)return {error:'A seleção da lista foi perdida. Abra novamente a exportação.'};
  if(!s.selected)return {selected:false,error:s.error};
  if(!s.root?.isConnected)return {error:'A lista foi fechada ou substituída. Abra novamente a exportação.'};
  if(!s.panel?.isConnected||!s.markers?.every(n=>n.isConnected&&s.panel.contains(n)))return {error:'Os dados do grupo foram fechados. Abra novamente a exportação.'};
  if(s.panel.matches('[role="dialog"][aria-label="Pesquisar membros"]')&&s.panel.querySelector('input')?.value.trim())return {error:'A pesquisa foi alterada durante a leitura. Apague a pesquisa e reinicie.'};
  const cr=s.scroll.getBoundingClientRect();
  const visible=n=>{const r=n.getBoundingClientRect();return r.width>0&&r.height>0&&r.bottom>Math.max(0,cr.top)&&r.top<Math.min(innerHeight,cr.bottom)&&getComputedStyle(n).visibility!=='hidden'};
  const rows=[];
  for(const n of s.root.querySelectorAll(s.selector)){
    if(!visible(n)||n.parentElement?.closest(s.selector)||!n.querySelector('[data-testid="cell-frame-title"]'))continue;
    const r=n.getBoundingClientRect();if(r.width<160||r.height<25||r.height>200)continue;
    if(n.querySelector('[data-testid="section-header"]'))continue;
    const title=n.querySelector('[data-testid="cell-frame-title"]');
    // Only the participant title and primary detail identify the member.
    // Status/about text and image tooltips are not names or phone fields.
    const titleValues=Array.from(title.querySelectorAll('[title]')).map(x=>x.getAttribute('title'));
    const nameText=(title.innerText||'').trim();
    const detail=(n.querySelector('[data-testid="cell-frame-primary-detail"]')?.innerText||'').trim();
    rows.push({key:n.getAttribute('data-testid'),structured:true,
      lines:[nameText,detail].filter(Boolean),titles:titleValues,
      position:Math.round((s.scroll.scrollTop+r.top-cr.top)/5)*5});
  }
  const top=s.scroll.scrollTop,max=Math.max(0,s.scroll.scrollHeight-s.scroll.clientHeight);
  if(advance)s.scroll.scrollTop=Math.min(max,top+Math.max(40,s.scroll.clientHeight*0.65));
  const label=s.root.getAttribute('aria-label')||'';
  const match=label.match(/:\s*([\d., ]+)/);
  const expected=match?Number(match[1].replace(/\D/g,'')):null;
  return {selected:true,rows,top,max,bottom:top>=max-3,expected};
}"""


# Read only rendered contact details. No WhatsApp stores or private APIs.
GROUP_PROFILE_JS = r"""(args) => {
  const s=window.__painelGrupo, op=args.op;
  const norm=x=>(x||'').normalize('NFC').replace(/\s+/g,' ').trim();
  const visible=n=>{const r=n.getBoundingClientRect();return n.isConnected&&r.width>0&&r.height>0&&getComputedStyle(n).visibility!=='hidden'&&getComputedStyle(n).display!=='none'};
  const profiles=()=>Array.from(document.querySelectorAll('[data-testid~="contact-info-subtitle"]')).filter(visible);
  if(!s?.selected)return {error:'Seleção do grupo perdida.'};
  if(op==='open'){
    if(profiles().length)return {error:'Já existe um contato aberto. Reinicie a leitura na lista completa.'};
    if(!s.root?.isConnected||!s.scroll?.isConnected)return {error:'A lista foi substituída antes da consulta.'};
    const cr=s.scroll.getBoundingClientRect();
    const matches=Array.from(s.root.querySelectorAll(s.selector)).filter(n=>{
      const r=n.getBoundingClientRect(),title=n.querySelector('[data-testid="cell-frame-title"]');
      const name=title?.querySelector('[title]')?.getAttribute('title')||title?.innerText;
      return visible(n)&&r.bottom>cr.top&&r.top<cr.bottom&&n.getAttribute('data-testid')===args.key&&norm(name)===norm(args.name);
    });
    if(matches.length!==1)return {error:'Participante não identificado de forma única na posição atual.'};
    const target=matches[0].querySelector('[role="button"]');
    if(!target)return {error:'A linha do participante não tem botão reconhecido.'};
    s.profileLookup={name:norm(args.name),top:s.scroll.scrollTop,modal:s.panel.matches('[role="dialog"][aria-label="Pesquisar membros"]')};
    // Keep only an existing group expansion button; never choose a new arbitrary action.
    s.profileLookup.expand=Array.from(document.querySelectorAll('[role="button"],button')).find(n=>
      /^Ver tudo \(mais \d+\)$/.test(norm(n.textContent))&&n.closest('[data-testid="chat-info-drawer"],[data-testid="drawer-right"],[role="complementary"]'));
    target.click();return {opened:true};
  }
  const lookup=s.profileLookup;
  if(!lookup)return {error:'Nenhuma consulta de contato iniciada.'};
  if(op==='read'){
    const names=profiles();
    if(!names.length)return {pending:true};
    if(names.length!==1||norm(names[0].textContent)!==lookup.name)return {error:'O nome do contato aberto não corresponde ao participante; telefone não associado.'};
    let node=names[0];
    for(let i=0;node&&i<5;i++,node=node.parentElement){
      if(node.querySelectorAll('[data-testid~="contact-info-subtitle"]').length>1)break;
      const numbers=Array.from(node.querySelectorAll('[data-testid="selectable-text"]')).filter(visible)
        .map(n=>norm(n.textContent)).filter(t=>/^\+[\d\s().-]{8,24}$/.test(t));
      if(numbers.length===1)return {name:lookup.name,phone:numbers[0]};
      if(numbers.length>1)return {error:'Mais de um telefone no bloco do contato; conferir manualmente.'};
    }
    return {pending:true};
  }
  if(op==='back'){
    const names=profiles();if(names.length!==1)return {error:'Não foi possível reconhecer a tela de contato para voltar.'};
    for(let p=names[0].parentElement,i=0;p&&p!==document.body&&i<20;p=p.parentElement,i++){
      const heading=Array.from(p.querySelectorAll('header,h1,h2,h3,span,div')).some(n=>visible(n)&&norm(n.textContent)==='Dados do contato');
      const buttons=Array.from(p.querySelectorAll('button[aria-label="Voltar"]')).filter(visible);
      if(heading&&buttons.length===1){buttons[0].click();return {back:true};}
    }
    return {error:'Botão Voltar dos dados do contato não reconhecido.'};
  }
  if(op==='restore'){
    if(profiles().length)return {pending:true};
    if(lookup.modal){
      const dialogs=Array.from(document.querySelectorAll('[role="dialog"][aria-label="Pesquisar membros"]')).filter(visible);
      if(!dialogs.length){
        if(!lookup.expanded&&lookup.expand&&visible(lookup.expand)){lookup.expanded=true;lookup.expand.click();}
        return {pending:true};
      }
      if(dialogs.length!==1||dialogs[0].querySelector('input')?.value.trim())return {error:'Lista completa ausente ou com pesquisa ativa.'};
      const panel=dialogs[0],row=panel.querySelector('[role="listitem"] [data-testid="cell-frame-title"]');
      if(!row)return {pending:true};
      let scroll=null;
      for(let p=row.parentElement;p&&panel.contains(p);p=p.parentElement){
        if(p.clientHeight>30&&p.scrollHeight>p.clientHeight+3&&/(auto|scroll)/.test(getComputedStyle(p).overflowY)){scroll=p;break;}
      }
      if(!scroll)return {error:'Rolagem da lista não reconhecida após voltar.'};
      s.panel=panel;s.markers=[panel];s.root=scroll;s.scroll=scroll;
    } else if(!s.root.isConnected||!s.scroll.isConnected||!s.markers.every(n=>n.isConnected)){
      return {error:'A lista inicial foi substituída. Reabra a lista completa em Ver tudo.'};
    }
    s.scroll.scrollTop=lookup.top;delete s.profileLookup;return {restored:true};
  }
  return {error:'Operação de consulta desconhecida.'};
}"""


def read_group_phone(page, raw, cancelled):
    """Returns a copied row only after identity validation and successful return."""
    row=group_row(raw)
    if not row or row['telefone']:return raw
    if cancelled():raise RuntimeError('Leitura interrompida pelo operador.')
    status=page.evaluate(GROUP_PROFILE_JS,{'op':'open','key':raw.get('key'),'name':row['nome']})
    if status.get('error'):raise RuntimeError(status['error'])
    found=None;failure=None
    for _ in range(32):
        if cancelled():failure='Leitura interrompida pelo operador.';break
        status=page.evaluate(GROUP_PROFILE_JS,{'op':'read'})
        if status.get('error'):failure=status['error'];break
        if status.get('phone'):found=status;break
        page.wait_for_timeout(250)
    status=page.evaluate(GROUP_PROFILE_JS,{'op':'back'})
    if status.get('error'):raise RuntimeError(status['error'])
    for _ in range(32):
        status=page.evaluate(GROUP_PROFILE_JS,{'op':'restore'})
        if status.get('error'):raise RuntimeError(status['error'])
        if status.get('restored'):break
        page.wait_for_timeout(250)
    else:raise RuntimeError('Não foi possível retornar à lista completa; leitura parcial preservada.')
    page.wait_for_timeout(350)
    if failure:raise RuntimeError(failure)
    if found:
        candidate={**raw,'lines':[row['nome'],found['phone']],'titles':[row['nome']]}
        parsed=group_row(candidate)
        if parsed and parsed['telefone']:return candidate
    return raw


def group_row(raw):
    """Só reconhece telefone que ocupe uma linha inteira; não usa números de recados."""
    lines=[str(v).strip() for v in raw.get('lines',[]) if str(v).strip()]
    titles=[str(v).strip() for v in raw.get('titles',[]) if str(v).strip()]
    values=list(dict.fromkeys(lines+titles))
    numbers=[]
    for value in values:
        if not re.fullmatch(r'\+?[\d\s().-]{8,24}',value):continue
        digits=re.sub(r'\D','',value)
        # Não inventa DDI para números sem prefixo internacional.
        if 8<=len(digits)<=15 and (value.startswith('+') or (digits.startswith('55') and len(digits) in (12,13))):
            number='+'+digits
            if number not in numbers:numbers.append(number)
    ignored={'admin do grupo','administrador do grupo','group admin','voce','you','adicionar participante',
             'adicionar membros','adicionar membro','adicionar etiqueta de membro','add member label','add member','add participant','convidar via link','invite via link',
             'ver todos','ver tudo','view all','see all','pesquisar','search','foto do perfil','profile picture'}
    candidates=[v.lstrip('~').strip() for v in values if normalize_header(v) not in ignored and
                not re.fullmatch(r'\+?[\d\s().-]+',v) and (raw.get('structured') or len(v)<=150)]
    # Títulos normalmente correspondem ao nome exibido; nunca usa dados internos do WhatsApp.
    named=[v.lstrip('~').strip() for v in titles if v.lstrip('~').strip() in candidates]
    primary=[lines[0].lstrip('~').strip()] if lines and lines[0].lstrip('~').strip() in candidates else []
    explicit=[v.lstrip('~').strip() for v in lines if v.startswith('~') and v.lstrip('~').strip() in candidates]
    name=(named or primary or explicit or ['Não identificado'])[0]
    if not numbers and name=='Não identificado':return None
    if len(numbers)>1:return {'nome':name,'telefone':'','observacao':'Mais de um número na linha; conferir manualmente.'}
    return {'nome':name,'telefone':numbers[0] if numbers else '',
            'observacao':('Nome não exibido.' if name=='Não identificado' else 'Nome exibido no WhatsApp; conferir.') if numbers else 'Telefone não exibido ou sem DDI; conferir manualmente.'}


class GroupRows:
    def __init__(self):self.rows=[];self.phones={};self.unavailable=set();self.ignored=0
    def add(self,raw):
        row=group_row(raw)
        if row is None:self.ignored+=1;return
        phone=row['telefone']
        if phone:
            if phone in self.phones:
                old=self.rows[self.phones[phone]]
                if old['nome']=='Não identificado' and row['nome']!='Não identificado':old.update(row)
                elif old['nome']!=row['nome'] and row['nome']!='Não identificado':old['observacao']='Mesmo telefone apareceu com nomes diferentes; conferir.'
                return
            self.phones[phone]=len(self.rows)
        else:
            # Índice da linha permanece estável durante a rolagem; posição é fallback.
            # Não combina homônimos que ocupam linhas diferentes.
            key=(raw.get('key') or raw.get('position'),row['nome'])
            if key in self.unavailable:return
            self.unavailable.add(key)
        self.rows.append(row)


def collect_group(page, cancelled, progress, max_steps=500, lookup_phones=False):
    result=GroupRows();stable_bottom=0;last_bottom=None;reason='Limite de rolagens atingido; leitura parcial.'
    seen=set();last_motion=None;stalled=0;expected=None;consulted={};lookup_error=None
    for step in range(max_steps):
        if cancelled():reason='Leitura interrompida pelo operador; resultado parcial.';break
        snapshot=page.evaluate(GROUP_READ_JS,False)
        if snapshot.get('error'):raise RuntimeError(snapshot['error'])
        if not snapshot.get('selected'):raise RuntimeError('Marque um participante antes de coletar.')
        expected=snapshot.get('expected') or expected
        for row in snapshot.get('rows',[]):
            identity=(row.get('key') or row.get('position'),tuple(row.get('titles',[])))
            if lookup_phones and identity not in consulted and not lookup_error:
                progress(len(result.rows))
                try:consulted[identity]=read_group_phone(page,row,cancelled)
                except RuntimeError as exc:lookup_error=str(exc)
            result.add(consulted.get(identity,row))
            seen.add((row.get('key') or row.get('position'),tuple(row.get('titles',[]))))
        if lookup_error:
            reason='Leitura parcial: '+lookup_error;break
        motion=(snapshot.get('top'),snapshot.get('max'),len(seen))
        stalled=stalled+1 if motion==last_motion else 0;last_motion=motion
        if stalled>=6:
            reason='Leitura parcial: a área de participantes não avançou. A lista completa não foi percorrida.';break
        progress(len(result.rows))
        if snapshot.get('bottom'):
            signature=(snapshot.get('max'),len(result.rows))
            stable_bottom=stable_bottom+1 if signature==last_bottom else 1;last_bottom=signature
            if stable_bottom>=4:
                if expected and len(seen)<expected:
                    reason=f'Leitura parcial: somente {len(seen)} de {expected} linhas de membros foram vistas. A rolagem terminou antes da contagem do grupo; confira se a lista completa está aberta.'
                else:
                    reason='Fim da área de participantes alcançado. Isso não confirma que todos os membros foram exibidos; confira a contagem e os telefones ausentes antes de salvar.'
                break
        else:stable_bottom=0;last_bottom=None
        page.evaluate(GROUP_READ_JS,True)
        page.wait_for_timeout(650)
    return {'contatos':result.rows,'observacao':reason,'sem_telefone':sum(not r['telefone'] for r in result.rows),
            'total_linhas':len(result.rows),'linhas_ignoradas':result.ignored,'coletado_em':stamp()}


def group_export_worker(job_path, config, data=DATA, transport_factory=motor.WhatsApp):
    job_path=Path(job_path);state=job_path.with_suffix('.estado.json');command=job_path.with_suffix('.comando.json')
    stop=job_path.with_suffix('.parar');adapter=None
    last_update = None
    def update(status,**kwargs):
        nonlocal last_update
        payload = {'estado':status,**kwargs}
        if payload != last_update:
            atomic_json(state,payload)
            last_update = payload
    def stopped():return stop.exists()
    with execution_lock(data):
        try:
            (Path(data)/'PARAR').unlink(missing_ok=True)
            update('abrindo',mensagem='Abrindo WhatsApp. Aguarde a conexão.')
            adapter=transport_factory(Path(data),30)
            page=adapter.page
            update('aguardando_lista',mensagem='Abra o grupo, clique no nome e abra a lista completa de participantes. Depois clique em Selecionar lista no painel.')
            deadline=time.monotonic()+600
            while not command.exists():
                if stopped():raise RuntimeError('Exportação cancelada.')
                if page.is_closed():raise RuntimeError('Navegador fechado.')
                if time.monotonic()>deadline:raise RuntimeError('Prazo esgotado para selecionar a lista. Abra novamente a exportação.')
                page.wait_for_timeout(250)
            if json.loads(command.read_text()).get('acao')!='selecionar':raise ValueError('Comando inválido.')
            page.evaluate(GROUP_SELECT_JS)
            update('selecionando',mensagem='No navegador, clique em uma linha da lista de participantes. O clique apenas marca a lista.')
            deadline=time.monotonic()+240
            last_error=''
            while True:
                if stopped():raise RuntimeError('Exportação cancelada.')
                if page.is_closed():raise RuntimeError('Navegador fechado.')
                if time.monotonic()>deadline:raise RuntimeError('Nenhuma lista selecionada no prazo.' + (' Última informação: '+last_error if last_error else ' Nenhuma linha foi reconhecida pelo clique.'))
                status=page.evaluate(GROUP_READ_JS,False)
                if status.get('selected'):break
                if status.get('error'):
                    last_error=status['error']
                    update('selecionando',mensagem=last_error)
                page.wait_for_timeout(300)
            page.wait_for_timeout(800)
            result=collect_group(page,stopped,lambda n:update('coletando',mensagem=f'Lendo participantes e consultando telefones: {n} linhas. Não mexa no navegador durante a leitura.'),lookup_phones=True)
            result['grupo']=str(config.get('grupo','')).strip()
            result['total_informado']=config.get('total_informado')
            return result
        finally:
            if adapter:adapter.close()


def save_group_xlsx(path, result):
    """Exportador OOXML local do aplicativo: textos literais, telefones preservados."""
    path=Path(path)
    if path.suffix.lower()!='.xlsx':raise ValueError('Salve a planilha com extensão .xlsx.')
    rows=result.get('contatos',[])
    if not rows:raise ValueError('Não há participantes na prévia para salvar.')
    ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    def clean(value):return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]','',str(value))[:32767]
    def sheet(matrix,widths,filter_rows=False):
        root=ET.Element('worksheet',xmlns=ns)
        views=ET.SubElement(root,'sheetViews');view=ET.SubElement(views,'sheetView',workbookViewId='0')
        ET.SubElement(view,'pane',ySplit='1',topLeftCell='A2',activePane='bottomLeft',state='frozen')
        cols=ET.SubElement(root,'cols')
        for i,w in enumerate(widths,1):ET.SubElement(cols,'col',min=str(i),max=str(i),width=str(w),customWidth='1')
        data=ET.SubElement(root,'sheetData')
        for i,values in enumerate(matrix,1):
            row=ET.SubElement(data,'row',r=str(i))
            for j,value in enumerate(values):
                cell=ET.SubElement(row,'c',r=f'{chr(65+j)}{i}',t='inlineStr',s='1' if i==1 else '0')
                text=ET.SubElement(ET.SubElement(cell,'is'),'t',{'{http://www.w3.org/XML/1998/namespace}space':'preserve'});text.text=clean(value)
        if filter_rows:ET.SubElement(root,'autoFilter',ref=f'A1:C{len(matrix)}')
        return ET.tostring(root,encoding='utf-8',xml_declaration=True)
    matrix=[['Nome','Telefone','Observação']]+[[r['nome'],r['telefone'],r['observacao']] for r in rows]
    info=[['Informação','Valor'],['Grupo informado pelo operador',result.get('grupo','')],['Coletado em',result.get('coletado_em','')],
          ['Linhas na prévia',len(rows)],['Sem telefone',sum(not r['telefone'] for r in rows)],['Total do grupo informado pelo operador',result.get('total_informado') or 'Não informado'],
          ['Leitura',result.get('observacao','')],['Fonte','Lista de participantes e dados do contato exibidos no WhatsApp Web.'],
          ['Limitações','Nomes são os exibidos, não identidades verificadas. Números ocultos não são recuperados. Homônimos sem telefone precisam de conferência.'],
          ['Envios','Exportar não adiciona contatos à campanha nem envia mensagens.']]
    parts={
        '[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>',
        '_rels/.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
        'xl/workbook.xml':'<workbook xmlns="'+ns+'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Participantes" sheetId="1" r:id="rId1"/><sheet name="Sobre a coleta" sheetId="2" r:id="rId2"/></sheets></workbook>',
        'xl/_rels/workbook.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
        'xl/styles.xml':'<styleSheet xmlns="'+ns+'"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF137B4B"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="49" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyNumberFormat="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>',
        'xl/worksheets/sheet1.xml':sheet(matrix,[38,24,62],True),
        'xl/worksheets/sheet2.xml':sheet(info,[42,95])}
    path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
            for name,content in parts.items():z.writestr(name,content)
        os.replace(temp,path)
    finally:temp.unlink(missing_ok=True)
